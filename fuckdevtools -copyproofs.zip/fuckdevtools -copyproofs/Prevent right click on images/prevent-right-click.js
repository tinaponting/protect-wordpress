<script>
{
  const isMobile = window.navigator.userAgent.match(/mobi/i);
  if (!isMobile) {
      document.addEventListener("contextmenu", function(event) {
        var notInput = (event.target || event.srcElement).tagName.toLowerCase() !== "input" && (event.target || event.srcElement).tagName.toLowerCase() !== "textarea";
        if (notInput) {
          event.preventDefault();
        }
      });
    // disable_right_click_text
        document.addEventListener("contextmenu", function(event) {
          var notInput = (event.target || event.srcElement).tagName.toLowerCase() !== "input" && (event.target || event.srcElement).tagName.toLowerCase() !== "textarea";
          if (notInput && (event.target || event.srcElement).innerText) {
            event.preventDefault();
          }
        });
        const textProtectionStyle = document.createElement("style");
        textProtectionStyle.type = "text/css";
        textProtectionStyle.innerHTML = 'body {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
          '}' +
          '.powr-countdown-timer iframe {' +
            'pointer-events: none;' +
          '}';
        document.head.appendChild(textProtectionStyle);
    // disable_right_click_img
        document.addEventListener("mousedown", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            // Middle-click to open in new tab
            if (event.which == 2) {
              event.preventDefault();
            }
          }
        });
        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            event.preventDefault();
          }
        });
        // Drag and drop <img> elements
        const imageDragStyle = document.createElement("style");
        imageDragStyle.type = "text/css";
        imageDragStyle.innerHTML = 'img {' +
            '-webkit-user-drag: none;' +
            'user-drag: none;' +
          '}';
        document.head.appendChild(imageDragStyle);
        const disableDragAndDrop = function(){
          document.body.setAttribute("ondragstart", "return false;");
          document.body.setAttribute("ondrop", "return false;");
        };
        if (document.readyState === "complete" || document.readyState === "interactive") {
          disableDragAndDrop();
        } else {
          document.addEventListener("DOMContentLoaded", disableDragAndDrop);
        }
    // disable_right_click_bg_img
        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).style.backgroundImage) {
            event.preventDefault();
          }
        });
    // disable_cut_copy
        document.addEventListener("copy", function(event) {
          if (
            (event.target || event.srcElement).tagName.toLowerCase() !== "input" &&
            (event.target || event.srcElement).tagName.toLowerCase() !== "textarea"
          ) {
            event.preventDefault();
          }
        });
        document.addEventListener("cut", function(event) {
          if (
            (event.target || event.srcElement).tagName.toLowerCase() != "input" &&
            (event.target || event.srcElement).tagName.toLowerCase() != "textarea"
          ) {
            event.preventDefault();
          }
        });
  } else {
    // disable_select_mobile
        const bodySelectStyle = document.createElement("style");
        bodySelectStyle.type = "text/css";
        bodySelectStyle.innerHTML = 'body {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
          '}';
        document.head.appendChild(bodySelectStyle);
    // disable_image_select_mobile
        const imageSelectStyle = document.createElement("style");
        imageSelectStyle.type = "text/css";
        imageSelectStyle.innerHTML = 'img {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
            'pointer-events: none;' +
          '}' +
          /* In the case: <a href=''><img /></a>, pointer-events: none will
          break links.
          'a > img {' +
            'pointer-events: auto;' +
          '}' +
          /* Specific fix for FlexSlider */
          '.flex-control-thumbs li > img {' +
            'pointer-events: auto;' +
          '}' +
          /* Specific fix for ryviu, to make product review thumbnails tappable on mobile. Used on e.g.*/
          'ryviu-widget li > img {' +
            'pointer-events: auto;' +
          '}';
        document.head.appendChild(imageSelectStyle);

        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            event.preventDefault();
          }
        });
  }
}
</script>