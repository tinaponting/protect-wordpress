/*
FuckDevTools.Js
By @ghalbeyou on GitHub
https://github.com/GhalbeYou
Forked by: https://teskedsgumman.se
---------------------------------------
*/
// The CONFIG:
var disable_right_click = /* If this was true, the user cannot right click and if they do, they see alert DevTools? */ true;
var disable_f12 = /* If this was true, users cannot do f12 */ true;
var disable_csi = /* if this was true, users cannot do control shift i */ true;
var disable_CtrlJ = /*If this was true, users cannot do CtrJ */ true;
var disable_CtrlC = /*If this was true, users cannot do f12 */ true;
var disable_CtrlA = /*If this was true, users cannot do Ctrl+A */ true; 
var disable_CtrlC = /*If this was true, users cannot do Ctrl+C */ true;
var disable_CtrlV = /*If this was true, users cannot do Ctrl+V */ true;
document.onkeydown = function(event) {
    if (disable_f12 == true){
        if (event.keyCode == 123) {
            event.preventDefault();

        }
    }
    if (disable_csi == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
        }
    }
    if (disable_CtrlJ == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 74) {
            event.preventDefault();
        }
    }
    if (disable_CtrlA == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 65) {
            event.preventDefault();
        }
    }
    if (disable_CtrlC == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 67) {
            event.preventDefault();
        }
   }
    if (disable_CtrlV == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 86) {
            event.preventDefault();
        }
    }
}
if (disable_right_click == true){  
    document.oncontextmenu = function() {
        event.preventDefault();
        alert("Devtools?");
    }
}
function killCopy(e){
    return false;
}
function reEnable(){
    return true;
}
document.onselectstart=new Function ("return false");
if (window.sidebar){
    document.onmousedown=killCopy;
    document.onclick=reEnable;
}