/*
FuckDevTools.JS
By @ghalbeyou on GitHub
https://github.com/GhalbeYou
Forked by: https://teskedsgumman.se
---------------------------------------
*/
// The CONFIG:
var disable_right_click = true;
var disable_F3 = true;
var disable_f12 = true;
var disable_csi = true;
var disable_J = true;
var disable_C = true;
var disable_A = true; 
var disable_C = true;
var disable_U = true;
var disable_S = true;
var disable_A = true;
var disable_P = true;
var disable_f = true;
var disable_x = true;
var disable_V = true;
var disable_F = true;
var disable_K = true;
var disable_I = true;
var disable_J = true;
var disable_X = true;
document.onkeydown = function(event) {
    if (disable_f12 == true){
        if (event.keyCode == 123) {
              event.preventDefault();
        }
    }
    if (disable_csi == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
        }
    }	
document.onkeydown = function(event) {
    if (event.keyCode == 123) {
        event.preventDefault();
        alert("Devtools?");
        location.replace("about:blank");
		
    if (disable_f12 == true){
        if (event.keyCode == 123) {
            event.preventDefault();
            alert("Devtools?");
            location.replace("about:blank");
        }
    }
    else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
    if (disable_csi == true){  
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
´           alert("Devtools?");
            location.replace("about:blank");
        }
    }
}	
	if (disable_f3 == true){
       if (event.keyCode == 53) {
           event.preventDefault();
        }
    }
    if (disable_CtrlJ == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 74) {
            event.preventDefault();
        }
    }
    if (disable_CtrlA == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 65) {
            event.preventDefault();
        }
    }
    if (disable_CtrlC == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 67) {
            event.preventDefault();
        }
   }
   if (disable_CtrlU == true){     
       if (event.ctrlKey && event.shiftKey && event.keyCode == 85) {
           event.preventDefault();
        }
   }
   if (disable_CtrlS == true){     
      if (event.ctrlKey && event.shiftKey && event.keyCode == 65) {
          event.preventDefault();
        }
   } 
    if (disable_CtrlA == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 65) {
           event.preventDefault();
        }
    }
    if (disable_CtrlP == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 80) {
            event.preventDefault();
        }
    }
    if (disable_Ctrlf == true){  
       if (event.ctrlKey && event.shiftKey && event.keyCode == 13) {
           event.preventDefault();
        }
    } 
    if (disable_Ctrlx == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 88) {
           event.preventDefault();
        }
    }   
    if (disable_CtrlV == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 86) {
           event.preventDefault();
	    }
    }   
    if (disable_CtrlF == true){     
        if (event.ctrlKey && event.shiftKey && event.keyCode == 70) {
           event.preventDefault();
	  }
   }  
   if (disable_K == true){
       if (event.keyCode == 75) {
           event.preventDefault();
        }
    }
    if (disable_I == true){
        if (event.keyCode == 73) {
           event.preventDefault();
        }
    }
	    if (disable_I == true){
        if (event.keyCode == 73) {
           event.preventDefault();
        }
    }
	if (disable_J == true){
       if (event.keyCode == 88) {
           event.preventDefault();
        }
    }
if (disable_right_click == true){   
    document.oncontextmenu = function() {
        event.preventDefault();
        alert("Devtools?");
        location.replace("about:blank");
    }
}
document.onselectstart=new Function ("return false");
if (window.sidebar){
    document.onmousedown=killCopy;
    document.onclick=reEnable;
	
}
function killCopy(e){
    return false;
}
function reEnable(){
    return true;
}
document.onselectstart=new Function ("return false");
if (window.sidebar){
    document.onmousedown=killCopy;
    document.onclick=reEnable;
}
// Disable View Source
if (ccpdrc_settings && ccpdrc_settings.view_source) {
  document.onmousedown = function (event) {
    event = (event || window.event);
    if (event.keyCode === 67) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
// Disable View Source
if (ccpdrc_settings && ccpdrc_settings.view_source) {
  document.onmousedown = function (event) {
    event = (event || window.event);
    if (event.keyCode === 85) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
// Disable View Source
if (ccpdrc_settings && ccpdrc_settings.view_source) {
  document.onmousedown = function (event) {
    event = (event || window.event);
    if (event.keyCode === 86) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
// Disable View Source
if (ccpdrc_settings && ccpdrc_settings.view_source) {
  document.onmousedown = function (event) {
    event = (event || window.event);
    if (event.keyCode === 1117) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
// Disable View Source
if (ccpdrc_settings && ccpdrc_settings.view_source) {
  document.onmousedown = function (event) {
    event = (event || window.event);
    if (event.keyCode === 123) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
  document.onkeydown = function (event) {
    event = (event || window.event);
    if (event.keyCode === 123 ||
      event.ctrlKey && event.shiftKey && event.keyCode === 73 ||
      event.ctrlKey && event.shiftKey && event.keyCode === 75) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
    if (event.ctrlKey && event.keyCode === 85) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
    if (event.ctrlKey && event.altKey && event.keyCode === 73) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
    if (event.metaKey && event.altKey && event.keyCode === 73) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
    if (event.metaKey && event.altKey && event.keyCode === 85) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
  document.onkeypress = function (event) {
    event = (event || window.event);
    if (event.keyCode === 123) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
}

// Disable Mobilde view
{
  const isMobile = window.navigator.userAgent.match(/mobi/i);
  if (!isMobile) {
      document.addEventListener("contextmenu", function(event) {
        var notInput = (event.target || event.srcElement).tagName.toLowerCase() !== "input" && (event.target || event.srcElement).tagName.toLowerCase() !== "textarea";
        if (notInput) {
          event.preventDefault();
        }
      });
        document.addEventListener("contextmenu", function(event) {
          var notInput = (event.target || event.srcElement).tagName.toLowerCase() !== "input" && (event.target || event.srcElement).tagName.toLowerCase() !== "textarea";
          if (notInput && (event.target || event.srcElement).innerText) {
            event.preventDefault();
          }
        });
        const textProtectionStyle = document.createElement("style");
        textProtectionStyle.type = "text/css";
        textProtectionStyle.innerHTML = 'body {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
          '}' +
          '.powr-countdown-timer iframe {' +
            'pointer-events: none;' +
          '}';
        document.head.appendChild(textProtectionStyle);
        document.addEventListener("mousedown", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            if (event.which == 2) {
              event.preventDefault();
            }
          }
        });
        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            event.preventDefault();
          }
        });
        const imageDragStyle = document.createElement("style");
        imageDragStyle.type = "text/css";
        imageDragStyle.innerHTML = 'img {' +
            '-webkit-user-drag: none;' +
            'user-drag: none;' +
          '}';
        document.head.appendChild(imageDragStyle);
        const disableDragAndDrop = function(){
          document.body.setAttribute("ondragstart", "return false;");
          document.body.setAttribute("ondrop", "return false;");
        };
        if (document.readyState === "complete" || document.readyState === "interactive") {
          disableDragAndDrop();
        } else {
          document.addEventListener("DOMContentLoaded", disableDragAndDrop);
        }
        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).style.backgroundImage) {
            event.preventDefault();
          }
        });
        document.addEventListener("copy", function(event) {
          if (
            (event.target || event.srcElement).tagName.toLowerCase() !== "input" &&
            (event.target || event.srcElement).tagName.toLowerCase() !== "textarea"
          ) {
            event.preventDefault();
          }
        });
        document.addEventListener("cut", function(event) {
          if (
            (event.target || event.srcElement).tagName.toLowerCase() != "input" &&
            (event.target || event.srcElement).tagName.toLowerCase() != "textarea"
          ) {
            event.preventDefault();
          }
        });
  } else {
        const bodySelectStyle = document.createElement("style");
        bodySelectStyle.type = "text/css";
        bodySelectStyle.innerHTML = 'body {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
          '}';
        document.head.appendChild(bodySelectStyle);
        const imageSelectStyle = document.createElement("style");
        imageSelectStyle.type = "text/css";
        imageSelectStyle.innerHTML = 'img {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
            'pointer-events: none;' +
          '}' +
          /* In the case: <a href=''><img /></a>, pointer-events: none will
          break links.
          'a > img {' +
            'pointer-events: auto;' +
          '}' +
          /* Specific fix for FlexSlider */
          '.flex-control-thumbs li > img {' +
            'pointer-events: auto;' +
          '}' +
          'ryviu-widget li > img {' +
            'pointer-events: auto;' +
          '}';
        document.head.appendChild(imageSelectStyle);
        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            event.preventDefault();
          }
        });
  }
}