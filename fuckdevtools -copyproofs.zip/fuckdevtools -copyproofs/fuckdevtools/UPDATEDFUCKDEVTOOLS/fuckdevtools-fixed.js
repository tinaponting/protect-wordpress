/**
 * FuckDevTools.JS
 * A comprehensive browser dev tools and content protection script
 * By @ghalbeyou on GitHub
 * https://github.com/GhalbeYou
 * Forked by: https://teskedsgumman.se
 * ---------------------------------------
 */

(function() {
    'use strict';

    // ============================================
    // CONFIG - Enable/disable features
    // ============================================
    const config = {
        disableRightClick: true,
        disableF12: true,
        disableCtrlShiftI: true,  // Ctrl+Shift+I (DevTools)
        disableCtrlShiftJ: true,  // Ctrl+Shift+J (Console)
        disableCtrlShiftC: true,  // Ctrl+Shift+C (Inspector)
        disableCtrlU: true,       // View Source
        disableCtrlS: true,       // Save page
        disableCtrlP: true,       // Print
        disableCtrlA: true,       // Select All
        disableCtrlF: true,       // Find
        disableCtrlX: true,       // Cut
        disableCtrlV: true,       // Paste
        disableCtrlK: true,       // Ctrl+K (Chrome search)
        disablePrintScreen: true,
        disableTextSelection: true,
        disableImageDrag: true,
        alertOnViolation: true,
        redirectOnViolation: false,
        alertMessage: 'Devtools disabled!',
        isMobile: /mobi/i.test(navigator.userAgent)
    };

    // ============================================
    // KEY CODE CONSTANTS
    // ============================================
    const KeyCodes = {
        F12: 123,
        CTRL_SHIFT_I: 73,
        CTRL_SHIFT_J: 74,
        CTRL_SHIFT_C: 67,
        CTRL_U: 85,
        CTRL_S: 83,
        CTRL_P: 80,
        CTRL_A: 65,
        CTRL_F: 70,
        CTRL_X: 88,
        CTRL_V: 86,
        CTRL_K: 75,
        CTRL_J: 74,
        CTRL_I: 73,
        CTRL_E: 69
    };

    // ============================================
    // MAIN KEYBOARD HANDLER
    // ============================================
    document.onkeydown = function(event) {
        event = event || window.event;
        const keyCode = event.keyCode || event.which;
        const ctrl = event.ctrlKey;
        const shift = event.shiftKey;
        const alt = event.altKey;
        const meta = event.metaKey;

        let shouldBlock = false;

        // F12 - DevTools
        if (config.disableF12 && keyCode === KeyCodes.F12) {
            shouldBlock = true;
        }

        // Ctrl+Shift+I - DevTools
        if (config.disableCtrlShiftI && ctrl && shift && keyCode === KeyCodes.CTRL_SHIFT_I) {
            shouldBlock = true;
        }

        // Ctrl+Shift+J - Console
        if (config.disableCtrlShiftJ && ctrl && shift && keyCode === KeyCodes.CTRL_SHIFT_J) {
            shouldBlock = true;
        }

        // Ctrl+Shift+C - Inspector
        if (config.disableCtrlShiftC && ctrl && shift && keyCode === KeyCodes.CTRL_SHIFT_C) {
            shouldBlock = true;
        }

        // Ctrl+U - View Source
        if (config.disableCtrlU && ctrl && keyCode === KeyCodes.CTRL_U) {
            shouldBlock = true;
        }

        // Ctrl+S - Save
        if (config.disableCtrlS && ctrl && keyCode === KeyCodes.CTRL_S) {
            shouldBlock = true;
        }

        // Ctrl+P - Print
        if (config.disableCtrlP && ctrl && keyCode === KeyCodes.CTRL_P) {
            shouldBlock = true;
        }

        // Ctrl+A - Select All
        if (config.disableCtrlA && ctrl && keyCode === KeyCodes.CTRL_A) {
            shouldBlock = true;
        }

        // Ctrl+F - Find
        if (config.disableCtrlF && ctrl && keyCode === KeyCodes.CTRL_F) {
            shouldBlock = true;
        }

        // Ctrl+X - Cut
        if (config.disableCtrlX && ctrl && keyCode === KeyCodes.CTRL_X) {
            shouldBlock = true;
        }

        // Ctrl+V - Paste
        if (config.disableCtrlV && ctrl && keyCode === KeyCodes.CTRL_V) {
            shouldBlock = true;
        }

        // Ctrl+Shift+K - Chrome search
        if (config.disableCtrlK && ctrl && shift && keyCode === KeyCodes.CTRL_K) {
            shouldBlock = true;
        }

        // Ctrl+Alt+I - Inspect (some browsers)
        if (alt && ctrl && keyCode === KeyCodes.CTRL_I) {
            shouldBlock = true;
        }

        // Meta+Alt+I - Inspect (Mac)
        if (meta && alt && keyCode === KeyCodes.CTRL_I) {
            shouldBlock = true;
        }

        // Meta+Alt+U - View Source (Mac)
        if (meta && alt && keyCode === KeyCodes.CTRL_U) {
            shouldBlock = true;
        }

        if (shouldBlock) {
            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();

            if (config.alertOnViolation) {
                alert(config.alertMessage);
            }

            if (config.redirectOnViolation) {
                location.replace('about:blank');
            }
        }
    };

    // ============================================
    // RIGHT CLICK / CONTEXT MENU
    // ============================================
    if (config.disableRightClick) {
        document.oncontextmenu = function(event) {
            event = event || window.event;
            const target = event.target || event.srcElement;
            const isInput = target.tagName &&
                (target.tagName.toLowerCase() === 'input' ||
                 target.tagName.toLowerCase() === 'textarea');

            if (!isInput) {
                event.preventDefault();
                if (config.alertOnViolation) {
                    alert(config.alertMessage);
                }
                if (config.redirectOnViolation) {
                    location.replace('about:blank');
                }
            }
        };
    }

    // ============================================
    // TEXT SELECTION DISABLE
    // ============================================
    if (config.disableTextSelection) {
        // CSS method
        const styleTag = document.createElement('style');
        styleTag.type = 'text/css';
        styleTag.innerHTML = [
            'body {',
            '  -webkit-touch-callout: none;',
            '  -webkit-user-select: none;',
            '  -khtml-user-select: none;',
            '  -moz-user-select: none;',
            '  -ms-user-select: none;',
            '  user-select: none;',
            '}',
            'input, textarea {',
            '  -webkit-user-select: text;',
            '  -moz-user-select: text;',
            '  -ms-user-select: text;',
            '  user-select: text;',
            '}'
        ].join('\n');
        document.head.appendChild(styleTag);

        // JavaScript fallback
        document.onselectstart = function(event) {
            const target = event.target || event.srcElement;
            if (target.tagName &&
                (target.tagName.toLowerCase() !== 'input' &&
                 target.tagName.toLowerCase() !== 'textarea')) {
                return false;
            }
        };

        // Additional drag prevention
        document.addEventListener('dragstart', function(event) {
            event.preventDefault();
            return false;
        });
    }

    // ============================================
    // IMAGE DRAG PREVENTION
    // ============================================
    if (config.disableImageDrag) {
        const imageDragStyle = document.createElement('style');
        imageDragStyle.type = 'text/css';
        imageDragStyle.innerHTML = [
            'img {',
            '  -webkit-user-drag: none;',
            '  user-drag: none;',
            '}'
        ].join('\n');
        document.head.appendChild(imageDragStyle);

        // Prevent middle-click image load
        document.addEventListener('mousedown', function(event) {
            if (event.button === 1) {
                event.preventDefault();
                return false;
            }
        });

        // Prevent drag-drop
        document.body.setAttribute('ondragstart', 'return false');
        document.body.setAttribute('ondrop', 'return false');
    }

    // ============================================
    // COPY/CUT PREVENTION
    // ============================================
    document.addEventListener('copy', function(event) {
        const target = event.target || event.srcElement;
        if (target.tagName &&
            (target.tagName.toLowerCase() !== 'input' &&
             target.tagName.toLowerCase() !== 'textarea')) {
            event.preventDefault();
        }
    });

    document.addEventListener('cut', function(event) {
        const target = event.target || event.srcElement;
        if (target.tagName &&
            (target.tagName.toLowerCase() !== 'input' &&
             target.tagName.toLowerCase() !== 'textarea')) {
            event.preventDefault();
        }
    });

    // ============================================
    // PRINT SCREEN / SCREENSHOT PREVENTION
    // ============================================
    if (config.disablePrintScreen) {
        document.addEventListener('keyup', function(event) {
            if (event.key === 'PrintScreen') {
                navigator.clipboard.writeText('');
                if (config.alertOnViolation) {
                    alert('Screenshots are disabled!');
                }
            }
        });
    }

    // ============================================
    // PRINT PREVENTION (Ctrl+P)
    // ============================================
    document.addEventListener('keydown', function(event) {
        if (event.ctrlKey && event.key === 'p') {
            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();
            if (config.alertOnViolation) {
                alert('Printing is not allowed!');
            }
        }
    });

    // ============================================
    // MOBILE-SPECIFIC HANDLING
    // ============================================
    if (config.isMobile) {
        // Additional protection for mobile devices
        document.addEventListener('touchstart', function(event) {
            const target = event.target || event.srcElement;
            if (target.tagName &&
                target.tagName.toLowerCase() === 'img') {
                event.preventDefault();
            }
        }, { passive: false });
    }

    // ============================================
    // CONSOLE INTERCEPT (Basic)
    // ============================================
    // Note: This cannot fully block DevTools console but provides basic deterrent
    console.log('%cStop!', 'color: red; font-size: 50px; font-weight: bold;');
    console.log('%cThis feature is disabled.', 'font-size: 20px;');

})();
