READ ME:

Sometimes it doesn´t work! BUT: Try! Not always doesn´t work on some themes with strong js. 

ALTERINTIVES: or the other alternatives, witch works for you, TEST: also
se so you could write posts:)

Alternative, try witch works for you
Do not forget: 444 to all .htaccess!