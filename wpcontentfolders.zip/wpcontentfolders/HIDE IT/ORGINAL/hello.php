<?php
add_filter(
	'all_plugins',
	function ( $plugins ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenPlugins = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenPlugins as $hiddenPlugin ) {
				unset( $plugins[ $hiddenPlugin ] );
			}
		}
		return $plugins;
	}
);