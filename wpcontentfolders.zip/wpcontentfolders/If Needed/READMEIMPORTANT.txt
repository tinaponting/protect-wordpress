NR3: Do not Download my fonts!


# AlTERNATINE:

<IfModule mod_rewrite.c>
RewriteEngine On
RewriteCond %{HTTP_REFERER} !^http://(www\.)?yourdomain\.com/.* [NC]
RewriteCond %{REQUEST_URI} !hotlink\.(woff|woff2|ttf|eot) [NC]
RewriteRule .*\.(woff|woff2|ttf|eot)$ http://yourdomain.com/ [NC,F,L]
Header set Cache-Control "max-age=0, private, must-revalidate"
ErrorDocument 404 http://www.yourdomain.com/404.html



#### IMAGE PROTECTION ####

#protect images from hotlinking
RewriteEngine on
RewriteCond %{HTTP_REFERER} !^http(s)?://(www\.)?domainname.com [NC]
RewriteRule \.(jpg|jpeg|png|gif|bmp|tiff|svg)$ - [NC,F,L]

#protect images from hotlinking send new image
RewriteEngine on
RewriteCond %{HTTP_REFERER} !^http(s)?://(www\.)?domainname.com [NC]
RewriteRule \.(jpg|jpeg|png|gif|bmp|tiff|svg)$ http://www.domainname.com/donthotlink.png [NC,R,L]

#protect images from hotlinking but allow blank referrers and send new image
RewriteEngine on
RewriteCond %{HTTP_REFERER} !^$
RewriteCond %{HTTP_REFERER} !^http(s)?://(www\.)?domainname.com [NC]
RewriteRule \.(jpg|jpeg|png|gif|bmp|tiff|svg)$ http://www.domainname.com/donthotlink.png [NC,R,L]


#### AUDIO PROTECTION ####

RewriteEngine on
RewriteCond %{HTTP_REFERER} !^$
RewriteCond %{HTTP_REFERER} !^http(s)?://(www\.)?domainname.com [NC]
RewriteRule \.(mp3|oog|wav)$ - [NC,F,L]


#### VIDEO PROTECTION ####

RewriteEngine on
RewriteCond %{HTTP_REFERER} !^$
RewriteCond %{HTTP_REFERER} !^http(s)?://(www\.)?domainname.com [NC]
RewriteRule \.(mp4|mpg|avi|flv|mpeg|mov|wmv|mts)$ - [NC,F,L]


#### FONT PROTECTION ####

RewriteEngine on
RewriteCond %{HTTP_REFERER} !^$
RewriteCond %{HTTP_REFERER} !^http(s)?://(www\.)?domainname.com [NC]
RewriteRule \.(eot|woff|otf|ttf|ttc|svg)$ - [NC,F,L]

...........................................................

IF they do not give up:

SSLOptions +StrictRequire
SSLRequireSSL
SSLRequire %{HTTP_HOST} eq "example.com"
ErrorDocument 403 https://example.com