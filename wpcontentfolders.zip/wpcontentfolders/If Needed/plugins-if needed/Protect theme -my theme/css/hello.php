<?php
add_filter(
	'all_css',
	function ( $css ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenPlugins = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddencss as $hiddencss ) {
				unset( $css[ $hiddencss ] );
			}

		}
		return $css;
	}
);