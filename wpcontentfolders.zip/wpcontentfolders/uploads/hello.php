<?php
add_filter(
	'all_wp-content/uploads',
	function ( $wp-content/uploads ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/uploads = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenwp-content/uploads as $hiddenwp-content/uploads ) {
				unset( $wp-content/uploads[ $hiddenwp-content/uploads ] );
			}
		}
		return $wp-content/uploads;
	}
);