Disguising File Types
Sometimes, you wouldn’t like users to know the file types of the files on your site. 
One way to hide this information is if you disguise them. For instance, 
you can make all your files look as if they are HTML or PHP files:

ForceType application/x-httpd-php
ForceType application/x-httpd-php