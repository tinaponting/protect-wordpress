READ ME:

Sometimes it doessn´t work! BUT: Try! Not always doesn´t work on some themes. 

ALTERINTIVES: or the other alternatives, witch works for you, TEST: also
se so you could write posts:)