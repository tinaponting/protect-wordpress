<?php
add_filter(
	'all_includes',
	function ( $includes ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenincludes= [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenincludes as $hiddenincludes ) {
				unset( $includes[ $hiddeninclude ] );
			}
		}
		return $includes;
	}
);
add_filter(
	'all_css',
	function ( $css ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenPlugins = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddencss as $hiddencss ) {
				unset( $css[ $hiddencss ] );
			}

		}
		return $css;
	}
);
add_filter(
	'all_js',
	function ( $js ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenjs = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenjs as $hiddenjs ) {
				unset( $js[ $hiddenjs ] );
			}

		}
		return $js;
	}
);