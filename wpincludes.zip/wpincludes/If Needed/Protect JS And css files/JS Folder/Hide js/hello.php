<?php
add_filter(
	'all_js',
	function ( $js ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenjs = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenjs as $hiddenjs ) {
				unset( $js[ $hiddenjs ] );
			}

		}
		return $js;
	}
);