<?php
add_filter(
	'all_wp-includes',
	function ( $wp-includes ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenWp-includes = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenWp-includes as $hiddenWp-includes ) {
				unset( $Wp-includes[ $hiddenWp-includesn ] );
			}
		}
		return $wp-includes;
	}
);