READ ME:

Sometimes alt.1 doesn´t work on some themes, you can take take. ALT.2 or the other alternatives, witch works for you, also
se so you could write posts:)