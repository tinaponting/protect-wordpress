READ ME:

Sometimes alt.1 doesn´t work on some themes, you ca ntake take. ALT.2