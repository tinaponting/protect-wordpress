Read me:

Set .htaccess to rights 444 or if it possible. 440

Protects all files:)

If you got trouble people wants to get in by all your,Emojis .js files?
Kompress them! And you do not use them: Set right 444! 