Read me:

Set .htaccess to rights: 444 or if it possible. 440

Protects all files:)

If you got trouble people wants to get in by all your,Emojis .js files?
Compress them! IF you do not use them: Set right 444! 

If they try to hack you, they got: 505 or 403, service not found!!


Alternative:

<IfModule mod_rewrite.c>
RewriteEngine On
RewriteCond %{HTTP:Origin} !^$|http(s)?://(www\.)?exemple.com\.(com|local)$ [NC]
RewriteRule \.(js|min.js|php|css|min.css|json|xml|.json|.svg,.png,.gif)$ - [NC,L]
RewriteCond %{HTTP_REFERER} !.
RewriteRule \.(js|min.js|php|css|min.css|json|xml|.json|.svg,.png,.gif)$ - [F,NC,L]
<IfModule mod_rewrite.c>

