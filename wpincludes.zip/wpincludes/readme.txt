Read me:

Set .htaccess to rights 444 or if it possible. 440

Protects all files:)

If you got trouble people wants to get in by all your,Emojis .js files?
Compress them! IF you do not use them: Set right 444! 

If theey try to hack you, they got: 505 service not found!!

