

* If you have problems with not being able to write or reach the Customizer, 
remove .htaccess and then see it update, then leave the cookies on, or use one of the others