

* If you have problems with not being able to write or reach the Customizer, 
remove .htaccess and then see it update, then leave the cookies on, or use one of the others


Hide important files:

RewriteRule ^wp-includes/(.*)$ /wp-includes/$1 [L]
RewriteRule ^css/(.*)$ /wp-includes/$1 [L]
RewriteRule ^js/(.*)$ /wp-includes/$1 [L]