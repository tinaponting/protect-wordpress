IF NEEDED:  Last of the .htaccess:

You could also set witch domailn that makes hell for you,jusr change it!

SetEnvIfNoCase Referer "hetzner.com" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer
SetEnvIfNoCase Referer "ovh.com" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer
SetEnvIfNoCase Referer "hetzner.de" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer
SetEnvIfNoCase Referer "seokicks.de" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer
SetEnvIfNoCase Referer "twingly.com" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer
SetEnvIfNoCase Referer "amazonaws.com" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer
SetEnvIfNoCase Referer "bc.googleusercontent.com" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer
SetEnvIfNoCase Referer "chinaunicom.com" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer
SetEnvIfNoCase Referer "vultrusercontent.com" bad_referer Order Allow,Deny Allow from ALL Deny from env=bad_referer