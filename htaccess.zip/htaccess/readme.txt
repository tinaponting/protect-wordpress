IF NEEDED:  Last of the .htaccess:

* you got more. if maybe.txt to add:)