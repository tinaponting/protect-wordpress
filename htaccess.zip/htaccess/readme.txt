IF NEEDED:  Last of the .htaccess:

* you got more. if maybe.txt to add:)
GZIP. you find more on maybe.txt