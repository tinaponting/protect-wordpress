IF NEEDED:  Last of the .htaccess:

* you got more. if maybe.txt to add:)
GZIP. you find more on maybe.txt


Extra:

php_value memory_limit 1024M

OR:
<IfModule mod_php7.c>
    php_value memory_limit 64M
</IfModule>


RewriteEngine On RewriteCond %{REQUEST_FILENAME}!-f RewriteRule ^([^.]+)$ $1.php [NC,L] 