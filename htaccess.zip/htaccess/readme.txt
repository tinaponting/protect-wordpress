IF NEEDED:  Last of the .htaccess:

* you got more. if maybe.txt to add:)
GZIP. you find more on maybe.txt


Extra:

php_value memory_limit 1024M or; 514M

OR:
<IfModule mod_php7.c>
php_value memory_limit 64M
</IfModule>

<IfModule mod_php8.c>

::::::::::::::::::::::::::::::::


### Test and see:

<IfModule mod_deflate.c>
<filesMatch "\.(js|css|html|php|svg)$">
SetOutputFilter DEFLATE
</filesMatch>
</IfModule>

<IfModule mod_mime.c>
AddType application/javascript js
AddType application/vnd.ms-fontobject eot
AddType application/x-font-ttf ttf ttc
AddType font/opentype otf
AddType application/x-font-woff woff
AddType image/svg+xml svg svgz 
AddEncoding gzip svgz
</Ifmodule>

<IfModule mod_deflate.c>
SetEnvIfNoCase Request_URI \.(?:gif|jpe?g|png)$ no-gzip dont-vary
SetEnvIfNoCase Request_URI \.(?:exe|t?gz|zip|bz2|sit|rar)$ no-gzip dont-vary
SetEnvIfNoCase Request_URI \.pdf$ no-gzip dont-vary
Header append Vary User-Agent env=!dont-vary
</IfModule>

::::::::::::::::::::::::::::::::

</IfModule>
<IfModule mod_headers.c>
Header append Vary: Accept-Encoding
</IfModule>
</IfModule>
<IfModule mod_mime.c>
AddType text/html .html_gzip
AddEncoding gzip .html_gzip
</IfModule>
<IfModule mod_setenvif.c>
SetEnvIfNoCase Request_URI \.html_gzip$ no-gzip
</IfModule>

Alternative:

</IfModule>
<IfModule mod_headers.c>
Header append Vary: Accept-Encoding
</IfModule>
<IfModule mod_mime.c>
AddType text/html .html_gzip
AddEncoding gzip .html_gzip
</IfModule>
<IfModule mod_setenvif.c>
SetEnvIfNoCase Request_URI \.html_gzip$ no-gzip
</IfModule>


::::::::::::::::::::::::::::::::::::::::::::::::::

# SUBSTITUTE WEBP IF POSSIBLE
# IF VISITOR'S BROWSER SUPPORTS WEBP IMAGES, AND A WEBP IMAGE EXISTS NEXT TO THE JPG, SERVE THE WEBP IMAGE INSTEAD.
OBS! not always working!

<IfModule mod_setenvif.c>
SetEnvIf Request_URI "\.(jpe?g|png)$" REQUEST_image
</IfModule>
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteCond %{HTTP_ACCEPT} image/webp
RewriteCond %{DOCUMENT_ROOT}/$1.webp -f
RewriteRule (.+)\.(jpe?g|png)$ $1.webp [T=image/webp]
</IfModule>
<IfModule mod_headers.c>
Header append Vary Accept env=REQUEST_image
</IfModule>
<IfModule mod_mime.c>
AddType image/webp .webp
</IfModule>

....

# WEBP SUBSTITUTION CODE FOR THE "EWWW IMAGE OPTIMIZER" PLUGIN
# Used with: https://en-ca.wordpress.org/plugins/ewww-image-optimizer/

<IfModule mod_rewrite.c>
RewriteEngine On
RewriteCond %{HTTP_ACCEPT} image/webp
RewriteCond %{REQUEST_FILENAME} (.*)\.(jpe?g|png)$
RewriteCond %{REQUEST_FILENAME}\.webp -f
RewriteCond %{QUERY_STRING} !type=original
RewriteRule (.+)\.(jpe?g|png)$ %{REQUEST_FILENAME}.webp [T=image/webp,E=accept:1,L]
</IfModule>
<IfModule mod_headers.c>
Header append Vary Accept env=REDIRECT_accept
</IfModule>
AddType image/webp .webp


# Alternative:
<IfModule pagespeed_module>
ModPagespeed on
ModPagespeedEnableFilters rewrite_css,combine_css
ModPagespeedEnableFilters rewrite_js,combine_js
ModPagespeedEnableFilters recompress_images
ModPagespeedEnableFilters convert_png_to_jpeg,convert_jpeg_to_webp
ModPagespeedEnableFilters collapse_whitespace,remove_comments
</IfModule>

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

# BROTOLI COMPRESSION:  Better than GZIP, but not on every webhotell.

<IfModule mod_brotli.c>
<IfModule mod_filter.c>
AddOutputFilterByType BROTLI_COMPRESS text/html text/xml text/plain
AddOutputFilterByType BROTLI_COMPRESS application/rss+xml application/xml application/xhtml+xml
AddOutputFilterByType BROTLI_COMPRESS text/css
AddOutputFilterByType BROTLI_COMPRESS text/javascript application/javascript application/x-javascript
AddOutputFilterByType BROTLI_COMPRESS image/x-icon image/svg+xml
AddOutputFilterByType BROTLI_COMPRESS application/rss+xml
AddOutputFilterByType BROTLI_COMPRESS application/font application/font-truetype application/font-ttf
AddOutputFilterByType BROTLI_COMPRESS application/font-otf application/font-opentype
AddOutputFilterByType BROTLI_COMPRESS application/font-woff application/font-woff2
AddOutputFilterByType BROTLI_COMPRESS application/vnd.ms-fontobject
AddOutputFilterByType BROTLI_COMPRESS font/ttf font/otf font/opentype font/woff font/woff2
</IfModule>
</IfModule>
<IfModule mod_deflate.c>
<IfModule mod_filter.c>
AddOutputFilterByType DEFLATE text/html text/xml text/plain
AddOutputFilterByType DEFLATE application/rss+xml application/xml application/xhtml+xml
AddOutputFilterByType DEFLATE text/css
AddOutputFilterByType DEFLATE text/javascript application/javascript application/x-javascript
AddOutputFilterByType DEFLATE image/x-icon image/svg+xml
AddOutputFilterByType DEFLATE application/rss+xml
AddOutputFilterByType DEFLATE application/font application/font-truetype application/font-ttf
AddOutputFilterByType DEFLATE application/font-otf application/font-opentype
AddOutputFilterByType DEFLATE application/font-woff application/font-woff2
AddOutputFilterByType DEFLATE application/vnd.ms-fontobject
AddOutputFilterByType DEFLATE font/ttf font/otf font/opentype font/woff font/woff2
</IfModule>
</IfModule>
<IfModule mod_rewrite.c>
RewriteRule "\.(gz|br)$" "-" [E=no-gzip:1,E=no-brotli:1]
</IfModule>
<IfModule !mod_rewrite.c>
<IfModule mod_setenvif.c>
SetEnvIfNoCase Request_URI \.(gz|br)$ no-gzip no-brotli
</IfModule>
</IfModule>

........................................................................................
........................................................................................ 
# Alternative GZIP DEFLATE: Compression:
 
<IfModule !mod_filter.c>
AddOutputFilterByType DEFLATE text/html text/css text/plain
AddOutputFilterByType DEFLATE text/xml application/xml text/x-component
AddOutputFilterByType DEFLATE application/xhtml+xml application/xslt+xml application/rss+xml application/atom+xml
AddOutputFilterByType DEFLATE image/svg+xml
AddOutputFilterByType DEFLATE application/javascript application/json application/x-javascript text/ecmascript text/javascript
AddOutputFilterByType DEFLATE image/vnd.microsoft.icon image/x-icon image/bmp image/tiff
AddOutputFilterByType DEFLATE application/pdf
AddOutputFilterByType DEFLATE font/opentype application/x-font-ttf application/vnd.ms-fontobject
</IfModule>
</IfModule>

<IfModule mod_deflate.c>
<IfModule mod_setenvif.c>
<IfModule mod_headers.c>
SetEnvIfNoCase ^(Accept-EncodXng|X-cept-Encoding|X{15}|~{15}|-{15})$ ^((gzip|deflate)\s,?\s(gzip|deflate)?|X{4,13}|~{4,13}|-{4,13})$ HAVE_Accept-Encoding
RequestHeader append Accept-Encoding "gzip,deflate" env=HAVE_Accept-Encoding
</IfModule>
</IfModule>
<IfModule filter_module>
FilterDeclare   COMPRESS
FilterProvider  COMPRESS  DEFLATE resp=Content-Type /text/(html|css|javascript|plain|x(ml|-component))/
FilterProvider  COMPRESS  DEFLATE resp=Content-Type /application/(javascript|json|xml|x-javascript)/
FilterChain     COMPRESS
FilterProtocol  COMPRESS  change=yes;byteranges=no
</IfModule>
<IfModule !mod_filter.c>
AddOutputFilterByType DEFLATE text/text text/html text/plain text/css application/json
AddOutputFilterByType DEFLATE text/javascript application/javascript application/x-javascript 
AddOutputFilterByType DEFLATE text/xml application/xml text/x-component
</IfModule>
<FilesMatch "\.(ttf|otf|eot|svg|php)$" >
SetOutputFilter DEFLATE
</FilesMatch>
</IfModule>

# More compression, if needed:

<ifModule mod_deflate.c>
<filesMatch "\.(css|js|x?html?|php)$">
SetOutputFilter DEFLATE
</filesMatch>
</ifModule>

# Try this:

<IfModule mod_deflate.c>
AddOutputFilterByType DEFLATE application/javascript text/css
</IfModule>

#  COMBINE CSS, COMPRESS IMAGES, REMOVE HTML WHITE SPACE AND COMMENTS

<IfModule pagespeed_module>
ModPagespeed on
ModPagespeedEnableFilters rewrite_css,combine_css
ModPagespeedEnableFilters recompress_images
ModPagespeedEnableFilters convert_png_to_jpeg,convert_jpeg_to_webp
ModPagespeedEnableFilters collapse_whitespace,remove_comments
</IfModule>


# FONTS:

<IfModule mod_deflate.c>
SetOutputFilter DEFLATE
<IfModule mod_filter.c>
AddOutputFilterByType DEFLATE application/font-otf application/font-ttf application/font-woff application/javascript application/json application/manifest+json application/rss+xml application/vnd.ms-fontobject application/xhtml+xml application/xml application/x-javascript image/svg+xml text/css text/csv text/html text/javascript text/plain text/xml
</IfModule>
</IfModule>

# OR:

RewriteRule ^.*.(?:css|js)$ $0.gz [L,QSA]

# Compress js/css:

files *.js.gz>
AddType "text/javascript" .gz
AddEncoding gzip .gz
</files>
<files *.css.gz>
AddType "text/css" .gz
AddEncoding gzip .gz
</files>

#:

<FilesMatch *.(html|css|jpg|jpeg|png|gif|js|ico)>
SetOutputFilter DEFLATE
</FilesMatch>

# OR:

<IfModule mod_headers.c>
RewriteCond "%{HTTP:Accept-encoding}" "gzip"
RewriteCond "%{REQUEST_FILENAME}\.gz" -s
RewriteRule "^(.*)\.(css|js)" "$1\.$2\.gz" [QSA]
RewriteRule "\.css\.gz$" "-" [T=text/css,E=no-gzip:1]
RewriteRule "\.js\.gz$"  "-" [T=text/javascript,E=no-gzip:1]
<FilesMatch "(\.js\.gz|\.css\.gz)$">
Header append Content-Encoding gzip
Header append Vary Accept-Encoding
</FilesMatch>
</IfModule>

# OR:

<IfModule mod_headers.c>
<FilesMatch ".(js|css|xml|gz|html)$">
Header append Vary: Accept-Encoding
</FilesMatch>
</IfModule>

# OR:

<IfModule mod_headers.c>
<FilesMatch "\.(js|css|xml|gz)$">
Header append Vary: Accept-Encoding
</FilesMatch>
</IfModule>


# OR:

</IfModule>
<FilesMatch "\.js$">
RewriteEngine On
RewriteCond %{HTTP:Accept-Encoding} gzip
RewriteCond %{REQUEST_FILENAME}.gz -f
RewriteRule (.*)\.js$ $1\.js.gz [L]
ForceType text/javascript
</FilesMatch>
<FilesMatch "\.js\.gz$">
ForceType text/javascript
Header set Content-Encoding gzip
Header set Vary Accept-Encoding
</FilesMatch>


# FONTS:
<IfModule mod_mime.c>
AddType application/vnd.ms-fontobject  eot
AddType application/x-font-ttf   ttf ttc
AddType font/opentype  otf
AddType application/x-font-woff  woff woff2
AddType image/svg+xml  svg svgz
AddEncoding gzip  svgz
</IfModule>


# Headers.
<IfModule mod_headers.c>
RewriteCond "%{HTTP:Accept-encoding}" "gzip"
RewriteCond "%{REQUEST_FILENAME}\.gz" -s
<FilesMatch "(\.js\.gz|\.css\.gz)$">
Header append Content-Encoding gzip
Header append Vary Accept-Encoding
</FilesMatch>
</IfModule>

::::::::::::::::::::::::::::::::::::::::::::::::::::::::

## Audio files expiration: 1 month after request:

ExpiresByType audio/wav A31536000
ExpiresByType audio/wma A31536000
ExpiresByType audio/midi A31536000
ExpiresByType video/quicktime A31536000
ExpiresByType audio/mpeg A31536000
ExpiresByType audio/x-realaudio A31536000
ExpiresByType audio/ogg A31536000

## Movie files expiration: 1 month after request:

ExpiresByType video/webm A31536000
ExpiresByType video/ogg A31536000
ExpiresByType video/mp4 A31536000
ExpiresByType video/asf A31536000
ExpiresByType video/avi A31536000
ExpiresByType video/divx A31536000
ExpiresByType video/mp4 A31536000
ExpiresByType video/mpeg A31536000
ExpiresByType video/webm A31536000
ExpiresByType video/ogg A31536000


# Turn off the Last Modified header except for html docs:

<FilesMatch ".(ico|pdf|flv|jpg|jpeg|png|gif|js|css)$">
Header unset Last-Modified
</FilesMatch>

Opendatabase:
ExpiresByType application/vnd.oasis.opendocument.database A31536000
ExpiresByType application/vnd.oasis.opendocument.chart A31536000
ExpiresByType application/vnd.oasis.opendocument.formula A31536000
ExpiresByType application/vnd.oasis.opendocument.graphics A31536000
ExpiresByType application/vnd.oasis.opendocument.presentation A31536000
ExpiresByType application/vnd.oasis.opendocument.spreadsheet A31536000
ExpiresByType application/vnd.oasis.opendocument.text A31536000


:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::