
Not allowed!  Deny access to folder!
If you got an folder or private folder, this stops noosy people!
but maybe can break the funktion, try and  see!!

Set rights to: 444! for security!

..................................................
# If not want it to been seen for every noosy ones:

Options -Indexes
