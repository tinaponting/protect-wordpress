
Not allowed!  Deny access to folder!
If you got an folder or private folder, this stops noosy people!

Set rights to: 444! for security!
