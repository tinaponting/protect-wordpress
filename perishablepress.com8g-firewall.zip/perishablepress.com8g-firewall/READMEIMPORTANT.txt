READ ME

perishablepress.com8g-firewall

Without logging, tested on my bloga - Works very well:)


Rename it to: htaccess - If this the only one you use,
htaccess2 if you use one of my htaccess firewalls.