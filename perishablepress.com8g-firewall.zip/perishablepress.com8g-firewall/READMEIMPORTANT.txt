READ ME

perishablepress.com8g-firewall
Without logging, tested on my bloga - Works very well:)


Rename it to: htaccess - If this the only one you use,
* htaccess2?* if you use one of my htaccess firewalls.


EXTRA TO ADD, if needed:

<IfModule mod_rewrite.c>
RewriteCond%{REQUEST_URI} /php(unit)?/ [NC,OR]
RewriteCond%{REQUEST_URI}\.(aspx?|env|git(ignore)?|phtml|rar|well-known)[NC,OR]
RewriteCond%{REQUEST_URI}/(cms|control_panel|dashboard|home_url=|lr-admin|manager|panel|staff|webadmin)[NC,OR]
RewriteCond%{REQUEST_URI}/(adm(in)?|blog|cache|checkout|controlpanel|ecommerce|export|magento(-1|web)?|market(place)?|mg|onli(n|k)e|orders?|shop|tmplconnector|uxm|web?store)/[NC,OR]	
RewriteCond%{REQUEST_URI}(_timthumb_|timthumb.php)[NC,OR]
RewriteCond%{REQUEST_URI}/(install|wp-config|xmlrpc)\.php[NC,OR]
RewriteCond%{REQUEST_URI}/(uploadify|uploadbg|up__uzegp)\.php[NC,OR]
RewriteCond%{REQUEST_URI}/(comm\.js|mysql-date-function|simplebootadmin|vuln\.htm|www\.root\.)[NC,OR]
RewriteCond%{REQUEST_URI}/(admin-uploadify|fileupload|jquery-file-upload|upload_file|upload|uploadify|webforms)/[NC,OR]
RewriteCond%{REQUEST_URI}/(ajax_pluginconf|apikey|connector(.minimal)?|eval-stdin|f0x|login|router|setup-config|sssp|vuln|xattacker)\.php[NC]	
RewriteRule .* - [F,L]	
</IfModule>


 404 Fix: Block Nuisance Requests for Non-Existent Files - New in 2018  
#   https://perishablepress.com/block-nuisance-requests
# -----------------------------------------------------------------------
# Comment it out, if you don't use Let's Encrypt, because Let's Encrypt is using .well-known

<IfModule mod_alias.c>
 RedirectMatch 403 (?i)\.php\.suspected
 RedirectMatch 403 (?i)\.(git|well-known)
 RedirectMatch 403 (?i)apple-app-site-association
 RedirectMatch 403 (?i)/autodiscover/autodiscover.xml
</IfModule>




# Maybe:

<IfModule mod_rewrite.c>RewriteCond%{HTTP_USER_AGENT}([a-z0-9]{2000[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(ahrefs|alexibot|majestic|mj12bot|rogerbot [NC,OR]
RewriteCond%{HTTP_USER_AGENT}(&lt;|%0a|%0d|%27|%3c|%3e|%00|0x00|\\\x22)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(oppo\sa33|(c99|php|web)shell|site((.){0,2})copier)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(base64_decode|bin/bash|disconnect|eval|unserializ)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(ahrefs|archiver|curl|libwww-perl|pycurl|scan|wget)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}((c99|php|web)shell|remoteview|site((.){0,2})copier)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(acapbot|attackbot|acoonbot|alexibot|asterias|attackbot|backdorbot|becomebot|binlar|blackwidow|blekkobot|blexbot|blowfish|bullseye|bunnys|butterfly|careerbot|casper)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(checkpriv|cheesebot|cherrypick|chinaclaw|choppy|clshttp|cmsworld|copernic|copyrightcheck|cosmos|crescent|cy_cho|datacha|demon|diavol|discobot|dittospyder)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(dotbot|dotnetdotcom|dumbot|econtext|emailcollector|emailsiphon|emailwolf|eolasbot|eventures|extract|eyenetie|feedfinder|flaming|flashget|flicky|foobot|fuck)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(g00g1e|getright|gigabot|go-ahead-got|gozilla|grabnet|grafula|harvest|heritrix|httracks?|icarus6j|jetbot|jetcar|jikespider|kmccrew|leechftp|libweb|liebaofast)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(linkscan|linkwalker|loader|lwp-download|majestic|masscan|miner|mechanize|mj12bot|morfeus|moveoverbot|netmechanic|netspider|nicerspro|nikto|ninja|nominet|nutch)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(octopus|pagegrabber|petalbot|planetwork|postrank|proximic|purebot|queryn|queryseeker|radian6|radiation|realdownload|remoteview|rogerbot|scan|scooter|seekerspid)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(semalt|siclab|sindice|sistrix|sitebot|siteexplorer|sitesnagger|skygrid|smartdownload|snoopy|sosospider|spankbot|spbot|sqlmap|stackrambler|stripper|sucker|surftbot)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(sux0r|suzukacz|suzuran|takeout|teleport|telesoft|true_robots|turingos|turnit|vampire|vikspider|voideye|webleacher|webreaper|webstripper|webvac|webviewer|webwhacker)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(winhttp|wwwoffle|woxbot|xaldon|xxxyy|yamanalab|yioopbot|youda|zeus|zmeu|zune|zyborg)[NC]RewriteRule .* - [F]</IfModule>


#Maybe:

<IfModule mod_rewrite.c>RewriteCond%{HTTP_REFERER}(@unlink|assert\(|print_r\(|x00|xbshell|shell)[NC,OR]
RewriteCond%{QUERY_STRING PHP[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}[NC]
RewriteCond%{REQUEST_URI}/(_0-load|00|00212|007|00x69|01|05623ecdddd|07|08_45_27_loggo|0803|0|0aa1883c|0byte|0day|0m|0wn3d|1|2|10|100|404|911|1050804k|a|b|d|g|k|abc|admin1|adminer|ajaxcommandshell|akismet|alf4|alfa|alfa2|alfa5|alfashell|alfx|alfa4|alfav4|amad|anasslost|anassgmr|ancvxia|ande|andre|andr3a|angel|angelwhitehat|angie|anonghost|anonghostshell|an0n)\.php [NC,OR]
RewriteCond%{REQUEST_URI}/(an0nym0us|anoncol7|anongt|anonym0us|anonymous|anzost|ars|as|b374k|beez|black|bloodsecv4|bump|byp|byp4ss|bypas|bypass|c|c22|c99|c100|cgi|changeall|cmd|con|config|configuration|cp|cpanel|cpn|css|cyber|d0mains|d4rk|dam|db|disqus|dom|drm|dz|dz0|egy|egyshell|eval|exp|exploit|exploits|f0x|file|filemanager|fm|fox|foxx|func|fx|fx0|gaza|golge)\.php [NC,OR]
RewriteCond%{REQUEST_URI}/(h4ck|h4cked|h4ntu|h4x|h4x0r|hack|hax|index1|indoxploit|info|inj3ct0r|ironshell|isko|islam|j3|jackal|jacker|jaguar|ja|jaja|jajaja|jar|java|javacpl|killer|king|ksa|l3b|ls|m1n1|madspot|madspotshell|m4r0c|marvins|mini|minishell|modules|mysql|network|newshell|newup|nkr|offline|olux|pr1v|press-this|priv|priv8|r1z|r0k|r00t|r57|readme|root)\.php [NC,OR]
RewriteCond%{REQUEST_URI}/(s|sa|sa2|sado|sh3ll|shel|shell|sm|smevk|sniper|sok|sql|sql-new|ss|sym|sym403|sym404|symbpass|syml1nk|symlink|symlinkbypass|syrian_shell|system|system_log|t00|think|tmp|up|uploader|uploads|uploadfile|uploadfile1|user|v4team|vuln)\.php [NC,OR]
RewriteCond%{REQUEST_URI}/(w|w3br00t|webadmin|webr00t|webroot|whmcrack|whmcracker|whmcs|wp-|ws|ws0|wso|wsoshell|ws0shell|wso25|wsoshell|up|x|xa|xccc|xd|xx|xxx|zdz|zone-h)\.php [NC,OR]
RewriteCond%{REQUEST_URI}/(admin2\.asp|alfa-shell-v4(.*)|blindshell\.c|cgishell\.pl|controller\.ashx|jaguar\.izri|perl\.alfa|xx\.pl)[NC]RewriteRule .* - [F,L]</IfModule>


....................





