READ ME

perishablepress.com8g-firewall
Without logging, tested on my bloga - Works very well:)


Rename it to: htaccess - If this the only one you use,
* htaccess2?* if you use one of my htaccess firewalls.


EXTRA TO ADD, if needed:

<IfModule mod_rewrite.c>
RewriteCond%{REQUEST_URI} /php(unit)?/ [NC,OR]
RewriteCond%{REQUEST_URI}\.(aspx?|env|git(ignore)?|phtml|rar|well-known)[NC,OR]
RewriteCond%{REQUEST_URI}/(cms|control_panel|dashboard|home_url=|lr-admin|manager|panel|staff|webadmin)[NC,OR]
RewriteCond%{REQUEST_URI}/(adm(in)?|blog|cache|checkout|controlpanel|ecommerce|export|magento(-1|web)?|market(place)?|mg|onli(n|k)e|orders?|shop|tmplconnector|uxm|web?store)/[NC,OR]	
RewriteCond%{REQUEST_URI}(_timthumb_|timthumb.php)[NC,OR]
RewriteCond%{REQUEST_URI}/(install|wp-config|xmlrpc)\.php[NC,OR]
RewriteCond%{REQUEST_URI}/(uploadify|uploadbg|up__uzegp)\.php[NC,OR]
RewriteCond%{REQUEST_URI}/(comm\.js|mysql-date-function|simplebootadmin|vuln\.htm|www\.root\.)[NC,OR]
RewriteCond%{REQUEST_URI}/(admin-uploadify|fileupload|jquery-file-upload|upload_file|upload|uploadify|webforms)/[NC,OR]
RewriteCond%{REQUEST_URI}/(ajax_pluginconf|apikey|connector(.minimal)?|eval-stdin|f0x|login|router|setup-config|sssp|vuln|xattacker)\.php[NC]	
RewriteRule .* - [F,L]	
</IfModule>




