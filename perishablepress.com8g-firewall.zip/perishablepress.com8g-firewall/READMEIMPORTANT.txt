READ ME

perishablepress.com8g-firewall
Without logging, tested on my bloga - Works very well:)


Rename it to: htaccess - If this the only one you use,
* htaccess2?* if you use one of my htaccess firewalls.


EXTRA TO ADD, if needed:

<IfModule mod_rewrite.c>
RewriteCond%{REQUEST_URI} /php(unit)?/ [NC,OR]
RewriteCond%{REQUEST_URI}\.(aspx?|env|git(ignore)?|phtml|rar|well-known)[NC,OR]
RewriteCond%{REQUEST_URI}/(cms|control_panel|dashboard|home_url=|lr-admin|manager|panel|staff|webadmin)[NC,OR]
RewriteCond%{REQUEST_URI}/(adm(in)?|blog|cache|checkout|controlpanel|ecommerce|export|magento(-1|web)?|market(place)?|mg|onli(n|k)e|orders?|shop|tmplconnector|uxm|web?store)/[NC,OR]	
RewriteCond%{REQUEST_URI}(_timthumb_|timthumb.php)[NC,OR]
RewriteCond%{REQUEST_URI}/(install|wp-config|xmlrpc)\.php[NC,OR]
RewriteCond%{REQUEST_URI}/(uploadify|uploadbg|up__uzegp)\.php[NC,OR]
RewriteCond%{REQUEST_URI}/(comm\.js|mysql-date-function|simplebootadmin|vuln\.htm|www\.root\.)[NC,OR]
RewriteCond%{REQUEST_URI}/(admin-uploadify|fileupload|jquery-file-upload|upload_file|upload|uploadify|webforms)/[NC,OR]
RewriteCond%{REQUEST_URI}/(ajax_pluginconf|apikey|connector(.minimal)?|eval-stdin|f0x|login|router|setup-config|sssp|vuln|xattacker)\.php[NC]	
RewriteRule .* - [F,L]	
</IfModule>


 404 Fix: Block Nuisance Requests for Non-Existent Files - New in 2018  
#   https://perishablepress.com/block-nuisance-requests
# -----------------------------------------------------------------------
# Comment it out, if you don't use Let's Encrypt, because Let's Encrypt is using .well-known

<IfModule mod_alias.c>
 RedirectMatch 403 (?i)\.php\.suspected
 RedirectMatch 403 (?i)\.(git|well-known)
 RedirectMatch 403 (?i)apple-app-site-association
 RedirectMatch 403 (?i)/autodiscover/autodiscover.xml
</IfModule>




# Maybe:

<IfModule mod_rewrite.c>RewriteCond%{HTTP_USER_AGENT}([a-z0-9]{2000[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(ahrefs|alexibot|majestic|mj12bot|rogerbot [NC,OR]
RewriteCond%{HTTP_USER_AGENT}(&lt;|%0a|%0d|%27|%3c|%3e|%00|0x00|\\\x22)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(oppo\sa33|(c99|php|web)shell|site((.){0,2})copier)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(base64_decode|bin/bash|disconnect|eval|unserializ)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(ahrefs|archiver|curl|libwww-perl|pycurl|scan|wget)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}((c99|php|web)shell|remoteview|site((.){0,2})copier)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(acapbot|attackbot|acoonbot|alexibot|asterias|attackbot|backdorbot|becomebot|binlar|blackwidow|blekkobot|blexbot|blowfish|bullseye|bunnys|butterfly|careerbot|casper)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(checkpriv|cheesebot|cherrypick|chinaclaw|choppy|clshttp|cmsworld|copernic|copyrightcheck|cosmos|crescent|cy_cho|datacha|demon|diavol|discobot|dittospyder)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(dotbot|dotnetdotcom|dumbot|econtext|emailcollector|emailsiphon|emailwolf|eolasbot|eventures|extract|eyenetie|feedfinder|flaming|flashget|flicky|foobot|fuck)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(g00g1e|getright|gigabot|go-ahead-got|gozilla|grabnet|grafula|harvest|heritrix|httracks?|icarus6j|jetbot|jetcar|jikespider|kmccrew|leechftp|libweb|liebaofast)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(linkscan|linkwalker|loader|lwp-download|majestic|masscan|miner|mechanize|mj12bot|morfeus|moveoverbot|netmechanic|netspider|nicerspro|nikto|ninja|nominet|nutch)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(octopus|pagegrabber|petalbot|planetwork|postrank|proximic|purebot|queryn|queryseeker|radian6|radiation|realdownload|remoteview|rogerbot|scan|scooter|seekerspid)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(semalt|siclab|sindice|sistrix|sitebot|siteexplorer|sitesnagger|skygrid|smartdownload|snoopy|sosospider|spankbot|spbot|sqlmap|stackrambler|stripper|sucker|surftbot)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(sux0r|suzukacz|suzuran|takeout|teleport|telesoft|true_robots|turingos|turnit|vampire|vikspider|voideye|webleacher|webreaper|webstripper|webvac|webviewer|webwhacker)[NC,OR]
RewriteCond%{HTTP_USER_AGENT}(winhttp|wwwoffle|woxbot|xaldon|xxxyy|yamanalab|yioopbot|youda|zeus|zmeu|zune|zyborg)[NC]RewriteRule .* - [F]</IfModule>


....................





