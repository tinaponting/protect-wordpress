<?php
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"facebookexternalhit")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FacebookBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FacebookBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"facebookexternalhit")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"facebookexternalhit/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"meta-externalfetcher/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"MetaAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta Llama 3")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta-AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta.AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"meta-ai")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"metaai")){	
exit(0);
}?>