Small Extra layer protection for Ai bots HELL!

Choose the one you want,
Upload it to your core, sett right; 644 or, 444.

There is room for your own in ai bots.

# No guarantee it works, but very hard copy for ai hell:)  


KP Sweden
