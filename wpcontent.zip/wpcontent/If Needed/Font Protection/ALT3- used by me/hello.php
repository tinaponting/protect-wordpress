<?php
add_filter(
	'all_wp-content/fonts',
	function ( $wp-content/fonts) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/fonts = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenwp-content/fonts as $hiddenwp-content/fonts ) {
				unset( $wp-content/fonts[$hiddenwp-content/fonts] );
			}
		}
		return $wp-content/fonts;
	}
);