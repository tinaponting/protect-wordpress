
Change plugins name/folder, you want to protect,
exemple: missed-schedule-post-publisher

Seets Rights to: 444.


ALTERNATIVE: (if ou hate false useragents):

RewriteRule ^403.html - [L]RewriteCond %{HTTP_USER_AGENT}RewriteRule .* - [F]
