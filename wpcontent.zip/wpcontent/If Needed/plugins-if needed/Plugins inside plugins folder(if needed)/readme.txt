# Change plugins name/folder, you want to protect,
exemple: missed-schedule-post-publisher

Sets Rights to: 444.


ALTERNATIVE: (if ou hate false useragents):

RewriteRule ^403.plugins - [L]RewriteCond %{HTTP_USER_AGENT}RewriteRule .* - [F]
