<?php
if(! defined('wp-content/themes')){die;
}