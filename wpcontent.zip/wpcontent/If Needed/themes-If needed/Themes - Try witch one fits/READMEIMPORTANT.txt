
# Alternative.

<IfModule mod_rewrite.c>
RewriteCond “%{HTTP_HOST}_%{HTTP_REFERER}” "!.?([^.]+.[^.]+?)_https?://.\1/.$"
RewriteRule .(style.css|min.style.css)$ - [F,NC,L]
</IfModule>


#Alt 4
Not always working, see if it works:)