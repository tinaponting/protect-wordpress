
# Alternative.

<IfModule mod_rewrite.c>
RewriteCond “%{HTTP_HOST}_%{HTTP_REFERER}” "!.?([^.]+.[^.]+?)_https?://.\2/.$"
RewriteRule .(style.css|min.style.css)$ - [F,NC,L]
</IfModule>


#Alt.
Not always working, see if it works:)



ALTERNATIVE:

Options -Indexes -Multiviews
RewriteEngine On
RewriteBase /
<IfModule mod_rewrite.c>
RewriteCond %{HTTP:Origin} !^$|http(s)?://(www\.)?exempel\.(com|local)$1 [NC]
RewriteRule \.(style.css|style.min.css|php|js|min.js|js|min.css|min.css|css|min.css|php|txt|html|json|pot|png|gif|jpg)$ - [NC,L]
RewriteCond %{HTTP_REFERER} !.
RewriteRule \.(style.css|style.min.css|php|js|min.js|js|min.css|min.css|css|min.css|php|txt|html|json|pot|png|gif|jpg)$ - [F,NC,L]
</IfModule>
