<?php
if(! defined('wp-contet-uploads')){die;
}