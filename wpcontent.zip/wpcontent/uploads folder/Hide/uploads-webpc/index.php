<?php
if(! defined('wp-contet-uploads-webpc')){die;
}