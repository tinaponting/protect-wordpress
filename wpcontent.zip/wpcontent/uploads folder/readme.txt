READ ME!

Not always working on some blogs, test it!