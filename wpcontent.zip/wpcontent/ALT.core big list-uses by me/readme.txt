RewriteRule wp-content/themes/nameof the theme/js/(.*\.js)$ – [R=404,L]
RewriteRule ^(.*)wp-content/themes/(.*)name of the theme\.js$ - [R=404,L]

RewriteRule wp-content/themes/nameof the theme/js/(.*\.css)$ – [R=404,L]
RewriteRule ^(.*)wp-content/themes/(.*)name of the theme\.css$ - [R=404,L]

RewriteRule ^(.*)wp-content/themes/(.*)style\.css$ - [R=404,L]
RewriteRule ^(.*)wp-content/themes/(.*)style\.min.css$ - [R=404,L]