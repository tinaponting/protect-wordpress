
Change plugins name/folder, you want to protect,
exemple: missed-schedule-post-publisher

Seets Rights to: 444.
