
RedirectMatch 403 ^/wp-content/plugins/dir/$

Byt ut plugins namn/som du vill skydda

Change plugins name/folder, you want to protect,
exemple: missed-schedule-post-publisher
