<?php
if(! defined('wp-content')){die;
}