READ ME - Important!

Set all .htaccess to rights: 444.
(so noone can write to files!

And set your right domain adress where it is needed:)

Happy Blogging:)  KP sweden


If you have in wp-content:
RewriteCond %{REQUEST_URI} ^(.*?/?)wp-content/mu-plugins/.* [NC]
RewriteCond %{REQUEST_URI} ^(.*?/?)wp-content/cache/.* [NC]

Use inside plugins(/ plugins where it is needed, if someone looks to mutch On / in a plugins, to keep them out!
Add these too:)