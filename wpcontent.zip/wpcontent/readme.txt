READ ME - Important!

Set all .htaccess to rights: 444.
(so noone can write to files!

And set your right domain adress where it is needed:)

Happy Blogging:)  KP sweden


If you have in wp-content (multisite):

RewriteCond %{REQUEST_URI} ^(.*?/?)wp-content/mu-plugins/.* [NC]

OR: cache:
RewriteCond %{REQUEST_URI} ^(.*?/?)wp-content/cache/.* [NC]

Use inside plugins(/ plugins where it is needed, if someone looks to mutch On / in a plugins, to keep them out!
Add these too:)

Try witch one aho works: plugins .htaccess and DO NOT FORGET TO set rights: 444


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

* If you want extra security like me, you can add the following:


* Down Under this line:  RewriteRule wp-content/plugins/(.*\.css)$ – [R=404,L]:

* ADD this: 
RewriteRule wp-content/plugins//wp-content/plugins/name of the sensitive plugin/(.*\.js)$ – [R=404,L] (MU)
RewriteRule wp-content/plugins/name of the sensitive plugin/php/(.*\.js)$ – [R=404,L]

::::::::::::::::::

* Down Under this line: RewriteRule wp-content/themes/(.*\.php)$ – [R=404,L]

* Add this:
RewriteRule wp-content/themes/theme name/(.*\.js)$ – [R=404,L]
RewriteRule wp-content/themes/theme name/(.*\.css)$ – [R=404,L]


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Alternative wp-content folder: add  folder/plugins/themes to protect:

RewriteCond %{REQUEST_URI} !^/wp-content/plugins/file/to/exclude\.php
RewriteCond %{REQUEST_URI} !^/wp-content/plugins/directory/to/exclude/
RewriteRule wp-content/plugins/(.*\.php)$ - [R=404,L]
RewriteCond %{REQUEST_URI} !^/wp-content/themes/file/to/exclude\.php
RewriteCond %{REQUEST_URI} !^/wp-content/themes/directory/to/exclude/
RewriteRule wp-content/themes/(.*\.php)$ - [R=404,L]

Simple:

RewriteRule wp-content/plugins/(.*\.php)$ - [R=404,L]
RewriteRule wp-content/themes/(.*\.php)$ - [R=404,L]
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


Images and or fonts:
RewriteRule ^images/(.*)$ wp-content/themes/standard/images/$1 [L]

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
IF needed:

RewriteRule ^wp-content/plugins/readme\.html$ - [R=404,L,NC]
RewriteRule ^wp-content/plugins/readme\.txt$ - [R=404,L,NC]
RewriteRule ^wp-content/plugins/changelog\.txt$ - [R=404,L,NC]