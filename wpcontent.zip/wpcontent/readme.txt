READ ME - Important!

Set all .htaccess to rights: 444.
(so noone can write to files!

And set your right domain adress where it is needed:)

Happy Blogging:)  KP sweden

............................................................................
# If you have in wp-content (multisite):

RewriteCond %{REQUEST_URI} ^(.*?/?)wp-content/mu-plugins/.* [NC]

RewriteRule wp-content/plugins//wp-content/plugins/name of the sensitive plugin/(.*\.js)$ – [R=404,L] (MU)

............................................................................
# OR: cache:
RewriteCond %{REQUEST_URI} ^(.*?/?)wp-content/cache/.* [NC]

Use inside plugins(/ plugins where it is needed, if someone looks to mutch On / in a plugins, to keep them out!
Add these too:)

Try witch one aho works: plugins .htaccess and DO NOT FORGET TO set rights: 444

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

* If you want extra security like me, you can add the following:

* Down Under this line: RewriteRule wp-content/plugins/(.*\.css)$ – [R=404,L]

# ADD this: 

RewriteRule wp-content/plugins/name of the sensitive plugin/php/(.*\.php)$ – [R=404,L]

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
* Down Under this line: RewriteRule wp-content/themes/(.*\.php)$ – [R=404,L]

* Add this:
RewriteRule wp-content/themes/theme name/(.*\.js)$ – [R=404,L]

RewriteRule wp-content/themes/theme name/(.*\.style.css)$ – [R=404,L]

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Alternative wp-content folder: add  folder/plugins/themes to protect:  

RewriteRule wp-content/plugins/(.*\.php)$ - [R=404,L]
RewriteRule wp-content/themes/(.*\.php)$ - [R=404,L]

RewriteRule ^wp-content/themes/style\.css$ - [R=404,L,NC]
RewriteRule ^wp-content/themes/style\.min.css - [R=404,L,NC]

# HIDE IT:
RewriteRule ^wp-content/themes/mytheme/$ /the/page/not-found [L]

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Images and or fonts:

RewriteRule ^images/(.*)$ wp-content/themes/name of the theme/images/$1 [L]

RewriteRule ^images/(.*)$ wp-content/themes/fonts/$1 [L]

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# IF needed:

RewriteRule ^wp-content/plugins/readme\.html$ - [R=404,L,NC]
RewriteRule ^wp-content/plugins/readme\.txt$ - [R=404,L,NC]
RewriteRule ^wp-content/plugins/changelog\.txt$ - [R=404,L,NC]

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

# Hide uploads folder:

RewriteRule ^wp-content/uploads/$ /the/page/not-found [L]

.

# Hide Whole content folder:

RewriteRule ^wp-content/$ /the/page/not-found [L]

.............................................................
# Alternative:

<IfModule mod_rewrite.c>
RewriteRule wp-content/plugins/(.*\.php)$ - [R=404,L]
RewriteRule wp-content/plugins/(.*\.txt)$ - [R=404,L]
RewriteRule wp-content/plugins/(.*\.js)$ - [R=404,L]
RewriteRule wp-content/plugins/(.*\.min.js)$ - [R=404,L]

RewriteRule wp-content/themes/(.*\.js)$ - [R=404,L]
RewriteRule wp-content/themes/(.*\.min.js)$ - [R=404,L]
RewriteRule wp-content/themes/(.*\.style.css)$ - [R=404,L]
RewriteRule wp-content/themes/(.*\.style.min.css)$ - [R=404,L]
RewriteRule wp-content/themes/(.*\.html)$ - [R=404,L]
</ifModule>

.......................................................................
# Protect:

RewriteRule ^files/(.+\.pdf)$ file_access/$1 [L]
RewriteRule ^files/(.+\.doc)$ file_access/$1 [L]
RewriteRule ^files/(.+\.docx)$ file_access/$1 [L]

.......................................................................
##More alternative on maybee t.xt in protect wordpress/github###

Another way:
RewriteRule ^assets* - [F]
RewriteRule ^/?cache/ - [F]
RewriteRule ^/?fonts/ - [F]
RewriteRule ^/?themes/ - [F]
RewriteRule ^/?themes/fonts/ - [F]
RewriteRule /?uploads - [F]
RewriteRule ^/?plugins/ - [F]

........................................................


# hide paths to wordpress dirs:

RewriteRule ^theme/(.*)$ /wp-content/themes/<yourtheme>/$1 [L]
RewriteRule ^upload/(.*)$ /wp-content/uploads/$1 [L]
RewriteRule ^plugin/(.*)$ /wp-content/plugins/$1 [L]

...........................................................