<?php
/**
 * The early blocker.
 *
 * Runs on wp_loaded, which is late enough that pluggable functions and the
 * current user exist, and early enough that `wp()` has not run yet — so no
 * REST route has been dispatched and no query has been parsed.
 *
 * @package DisableJsonRestPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Request blocker.
 */
class DJRP_Blocker {

	/**
	 * Parsed request context, built once per request.
	 *
	 * @var array|null
	 */
	private static $ctx = null;

	/**
	 * Rule that blocked this request, if any.
	 *
	 * @var string|false
	 */
	public static $hit = false;

	/**
	 * Entry point.
	 *
	 * @return void
	 */
	public static function run() {
		// Escape hatch: define DJRP_OFF in wp-config.php to disable entirely.
		if ( defined( 'DJRP_OFF' ) && DJRP_OFF ) {
			return;
		}

		// Never interfere with internal machinery.
		if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
			return;
		}
		if ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
			return;
		}
		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			return;
		}

		$ctx = self::context();

		// Nothing to do on a request that touches neither the REST API nor
		// one of the query signatures we watch. This keeps the plugin off the
		// hot path for ordinary page views.
		if ( ! $ctx['is_rest'] && ! $ctx['query_watched'] ) {
			return;
		}

		// 1. Explicit exclusions always win.
		if ( self::is_excluded() ) {
			return;
		}

		// 2. Master mode.
		$mode = DJRP_Settings::val( 'mode', 'visitors' );

		if ( 'everyone' === $mode ) {
			self::$hit = 'mode';
			self::deny( $ctx );
		}

		if ( 'visitors' === $mode && $ctx['is_rest'] && ! is_user_logged_in() ) {
			self::$hit = 'mode';
			self::deny( $ctx );
		}

		// 3. Block rules.
		$scope = DJRP_Settings::val( 'block_scope', 'everyone' );

		if ( 'visitors' === $scope && is_user_logged_in() ) {
			return;
		}

		$rule = self::match( $ctx );

		if ( $rule ) {
			self::$hit = $rule;
			self::deny( $ctx );
		}
	}

	/**
	 * Test the request against every enabled rule.
	 *
	 * @param array $ctx Request context.
	 * @return string|false Rule id that matched.
	 */
	public static function match( $ctx ) {
		$max_per_page = (int) DJRP_Settings::val( 'max_per_page', 20 );

		foreach ( DJRP_Rules::enabled() as $id => $rule ) {

			// root: the bare index, e.g. /wp-json/ or /wp-json/?context=view
			if ( ! empty( $rule['root'] ) && $ctx['is_rest'] && '/' === $ctx['route'] ) {
				return $id;
			}

			if ( ! empty( $rule['route'] ) && $ctx['is_rest'] && preg_match( $rule['route'], $ctx['route'] ) ) {
				return $id;
			}

			if ( $rule['uri'] ) {
				foreach ( $rule['uri'] as $pattern ) {
					if ( preg_match( $pattern, $ctx['uri'] ) ) {
						return $id;
					}
				}
			}

			if ( $rule['query'] ) {
				foreach ( $rule['query'] as $pattern ) {
					if ( preg_match( $pattern, $ctx['query'] ) ) {
						return $id;
					}
				}
			}

			// perpage: any listing request asking for more than the ceiling.
			if ( ! empty( $rule['perpage'] ) && $max_per_page > 0 && null !== $ctx['per_page'] ) {
				if ( $ctx['per_page'] > $max_per_page ) {
					return $id;
				}
			}
		}

		return false;
	}

	/**
	 * Is this request from an excluded user or IP?
	 *
	 * @return bool
	 */
	public static function is_excluded() {
		$options = DJRP_Settings::get();

		// Administrators. The block editor itself talks to /wp/v2/posts and
		// /wp/v2/types on every keystroke, so locking admins out would break
		// the site. Off means the rule list also applies to admins.
		if ( ! empty( $options['harden']['exempt_admins'] ) && is_user_logged_in() ) {
			if ( current_user_can( 'manage_options' ) ) {
				return true;
			}
		}

		// Explicit user IDs.
		$ids = self::to_list( DJRP_Settings::val( 'exclude_users', '' ) );
		if ( $ids ) {
			$user_id = get_current_user_id();
			if ( $user_id && in_array( (string) $user_id, $ids, true ) ) {
				return true;
			}
		}

		// Explicit IPs, supporting CIDR.
		$ips = self::to_list( DJRP_Settings::val( 'exclude_ips', '' ) );
		if ( $ips ) {
			$ip = self::remote_ip();
			foreach ( $ips as $entry ) {
				if ( false !== strpos( $entry, '/' ) ) {
					if ( self::ip_in_cidr( $ip, $entry ) ) {
						return true;
					}
				} elseif ( $ip === $entry ) {
					return true;
				}
			}
		}

		return false;
	}

	/* ---------------------------------------------------------------------
	 * Request context
	 * ------------------------------------------------------------------ */

	/**
	 * Build (and memoise) the request context.
	 *
	 * @return array
	 */
	public static function context() {
		if ( null !== self::$ctx ) {
			return self::$ctx;
		}

		$raw_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		$uri     = html_entity_decode( $raw_uri, ENT_QUOTES, 'UTF-8' );

		$parts  = wp_parse_url( $uri );
		$path   = isset( $parts['path'] ) ? $parts['path'] : '/';
		$query  = isset( $parts['query'] ) ? $parts['query'] : '';

		// Drop /index.php so pretty and plain permalinks normalise alike.
		$pos = strpos( $path, '/index.php' );
		if ( false !== $pos ) {
			$path = substr( $path, $pos + strlen( '/index.php' ) );
		}
		if ( '' === $path ) {
			$path = '/';
		}

		$prefix = function_exists( 'rest_get_url_prefix' ) ? rest_get_url_prefix() : 'wp-json';
		$needle = '/' . trim( $prefix, '/' );

		/*
		 * Either /wp-json/... or ?rest_route=/...
		 *
		 * The is_scalar() guard matters more than it looks. A request carrying
		 * ?rest_route[]=/batch/v1 sends an ARRAY, and casting that to a string
		 * yields "Array" — which silently made is_rest false and let the whole
		 * request past the master switch and every route rule. A blocking
		 * plugin has to assume anything can be aimed at it, including shapes
		 * WordPress itself would choke on.
		 */
		$route_param     = isset( $_GET['rest_route'] ) ? $_GET['rest_route'] : null; // phpcs:ignore WordPress.Security.NonceVerification
		$has_route_param = null !== $route_param;
		$path_has_prefix = ( $path === $needle || 0 === strpos( $path, $needle . '/' ) );

		$is_rest = $has_route_param || $path_has_prefix;

		$route = '';
		if ( $has_route_param ) {
			// A malformed rest_route is still a REST attempt: keep the request
			// flagged as REST so the master switch and root rule catch it.
			$route = is_scalar( $route_param ) ? (string) wp_unslash( $route_param ) : '';
		} elseif ( $path_has_prefix ) {
			$route = substr( $path, strlen( $needle ) );
		}

		if ( ! is_string( $route ) ) {
			$route = '';
		}

		$route = rawurldecode( $route );
		if ( '' === $route || '/' === $route ) {
			$route = '/';
		} else {
			$route = '/' . ltrim( untrailingslashit( $route ), '/' );
		}

		// per_page, wherever it appears. Arrays and objects are ignored
		// rather than cast, so no warning is ever raised on hostile input.
		$per_page = null;
		if ( isset( $_GET['per_page'] ) && is_scalar( $_GET['per_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$candidate = sanitize_text_field( wp_unslash( $_GET['per_page'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			if ( is_numeric( $candidate ) ) {
				$per_page = (int) $candidate;
			}
		}

		// Does the query string carry any signature we care about? Used to
		// decide whether a non-REST request is worth inspecting at all.
		$query_watched = (bool) preg_match(
			'#(rest_route|per_page|context=edit|oembed=true)#i',
			$query
		);

		self::$ctx = array(
			'raw_uri'       => $raw_uri,
			'uri'           => $uri,
			'path'          => $path,
			'query'         => $query,
			'route'         => $route,
			'is_rest'       => $is_rest,
			'per_page'      => $per_page,
			'query_watched' => $query_watched,
			'method'        => isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET',
		);

		return self::$ctx;
	}

	/* ---------------------------------------------------------------------
	 * Response
	 * ------------------------------------------------------------------ */

	/**
	 * Deny the request and stop.
	 *
	 * @param array $ctx Request context.
	 * @return void
	 */
	private static function deny( $ctx ) {
		$status  = self::status_code();
		$message = self::message();

		self::record_hit();

		if ( ! headers_sent() ) {
			status_header( $status );
			nocache_headers();
			header( 'X-Robots-Tag: noindex', true );
			header( 'Content-Type: application/json; charset=utf-8' );
		}

		echo wp_json_encode(
			array(
				'code'    => 'djrp_rest_forbidden',
				'message' => $message,
				'data'    => array( 'status' => $status ),
			)
		);

		exit;
	}

	/**
	 * Resolve the status code.
	 *
	 * @return int
	 */
	private static function status_code() {
		$code = DJRP_Settings::val( 'status_code', 'default' );

		if ( 'default' === $code || '' === $code ) {
			// 401 tells an anonymous caller to authenticate, 403 tells a known
			// user they still may not. This is the convention REST itself uses.
			return is_user_logged_in() ? 403 : 401;
		}

		$code = (int) $code;
		return in_array( $code, array( 401, 403, 404, 405, 429 ), true ) ? $code : 403;
	}

	/**
	 * Resolve the error message, supporting the %%error%% placeholder.
	 *
	 * @return string
	 */
	private static function message() {
		$message = (string) DJRP_Settings::val( 'error_message', '' );

		if ( '' === trim( $message ) ) {
			$message = __( 'REST API access is not allowed.', 'disable-json-rest-pro' );
		}

		$message = str_replace( '%%error%%', '', $message );

		/**
		 * Filter the message returned to a blocked client.
		 *
		 * @param string $message Message.
		 * @param string $hit     Rule that blocked the request.
		 */
		return (string) apply_filters( 'djrp_error_message', trim( $message ), self::$hit );
	}

	/* ---------------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------------ */

	/**
	 * Split a comma or newline separated field into a clean list.
	 *
	 * @param string $raw Raw value.
	 * @return array
	 */
	private static function to_list( $raw ) {
		$parts = preg_split( '/[\r\n,]+/', (string) $raw );
		$out   = array();

		foreach ( (array) $parts as $part ) {
			$part = trim( $part );
			if ( '' !== $part ) {
				$out[] = $part;
			}
		}

		return $out;
	}

	/**
	 * The client IP.
	 *
	 * Deliberately REMOTE_ADDR only. Trusting X-Forwarded-For on a shared host
	 * would let any client spoof its way into the exclusion list.
	 *
	 * @return string
	 */
	public static function remote_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}

	/**
	 * IPv4/IPv6 CIDR containment test.
	 *
	 * @param string $ip   Address.
	 * @param string $cidr Network, e.g. 10.0.0.0/8.
	 * @return bool
	 */
	public static function ip_in_cidr( $ip, $cidr ) {
		list( $subnet, $bits ) = array_pad( explode( '/', $cidr, 2 ), 2, null );

		$ip_bin    = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$subnet_bin = @inet_pton( $subnet ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		if ( false === $ip_bin || false === $subnet_bin || strlen( $ip_bin ) !== strlen( $subnet_bin ) ) {
			return false;
		}

		$max_bits = strlen( $ip_bin ) * 8;
		$bits     = ( null === $bits ) ? $max_bits : (int) $bits;

		if ( $bits < 0 || $bits > $max_bits ) {
			return false;
		}

		if ( 0 === $bits ) {
			return true;
		}

		$bytes    = intdiv( $bits, 8 );
		$leftover = $bits % 8;

		if ( $bytes > 0 && 0 !== strncmp( $ip_bin, $subnet_bin, $bytes ) ) {
			return false;
		}

		if ( $leftover > 0 ) {
			$mask = chr( 0xFF << ( 8 - $leftover ) & 0xFF );
			if ( ( $ip_bin[ $bytes ] & $mask ) !== ( $subnet_bin[ $bytes ] & $mask ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Count blocks per rule.
	 *
	 * Throttled to one write every few seconds. On shared hosting a scrape
	 * wave can be thousands of requests a minute; writing on each one would
	 * be the most expensive thing on the site. The count is therefore a floor,
	 * not an exact total, and the admin screen says so.
	 */
	private static function record_hit() {
		$stats = get_option( 'djrp_stats', array() );

		if ( ! is_array( $stats ) ) {
			$stats = array();
		}

		$stats = wp_parse_args(
			$stats,
			array(
				'counts'     => array(),
				'last_write' => 0,
				'last_hit'   => 0,
				'total'      => 0,
			)
		);

		$now = time();

		if ( $now - (int) $stats['last_write'] < 5 ) {
			return;
		}

		$key = self::$hit ? self::$hit : 'unknown';

		$stats['counts'][ $key ]   = isset( $stats['counts'][ $key ] ) ? (int) $stats['counts'][ $key ] + 1 : 1;
		$stats['last_write']       = $now;
		$stats['last_hit']         = $now;
		$stats['total']            = (int) $stats['total'] + 1;

		update_option( 'djrp_stats', $stats );
	}
}
