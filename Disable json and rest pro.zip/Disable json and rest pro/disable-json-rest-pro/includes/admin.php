<?php
/**
 * Admin screen.
 *
 * @package DisableJsonRestPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Settings page.
 */
class DJRP_Admin {

	const PAGE_SLUG  = 'disable-json-rest-pro';
	const CAPABILITY = 'manage_options';
	const NONCE      = 'djrp_save_settings';

	/**
	 * Whether init() has run.
	 *
	 * @var bool
	 */
	private static $booted = false;

	/**
	 * Import report, for the one-time notice.
	 *
	 * @var array
	 */
	private static $report = array();

	/**
	 * Boot from init (see DJRP_Plugin::hooks for why not admin_init).
	 *
	 * @return void
	 */
	public static function init() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		self::$report = DJRP_Settings::maybe_import();

		add_action( 'admin_menu', array( __CLASS__, 'add_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_handle_post' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	/**
	 * Register the settings page.
	 *
	 * @return void
	 */
	public static function add_page() {
		add_options_page(
			__( 'Disable JSON and REST Pro', 'disable-json-rest-pro' ),
			__( 'Disable JSON+REST', 'disable-json-rest-pro' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Enqueue admin assets on our screen only.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function assets( $hook ) {
		if ( 'settings_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}

		wp_enqueue_style( 'djrp-admin', DJRP_URL . 'css/admin.css', array(), DJRP_VERSION );
		wp_enqueue_script( 'djrp-admin', DJRP_URL . 'js/admin.js', array(), DJRP_VERSION, true );
	}

	/* ---------------------------------------------------------------------
	 * Save
	 * ------------------------------------------------------------------ */

	/**
	 * Handle the settings form.
	 *
	 * @return void
	 */
	public static function maybe_handle_post() {
		if ( ! isset( $_POST['djrp_action'] ) ) {
			return;
		}

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to change these settings.', 'disable-json-rest-pro' ) );
		}

		check_admin_referer( self::NONCE );

		$options = DJRP_Settings::get();

		// --- Reset ------------------------------------------------------
		if ( 'reset' === $_POST['djrp_action'] ) {
			DJRP_Settings::reset();
			delete_option( 'djrp_stats' );
			self::redirect( array( 'djrp_notice' => 'reset' ) );
		}

		// --- Master mode ------------------------------------------------
		$mode            = sanitize_key( self::post_string( 'mode', 'visitors' ) );
		$options['mode'] = in_array( $mode, array( 'off', 'visitors', 'everyone' ), true ) ? $mode : 'visitors';

		// --- Block rule scope -------------------------------------------
		$scope                 = sanitize_key( self::post_string( 'block_scope', 'everyone' ) );
		$options['block_scope'] = in_array( $scope, array( 'everyone', 'visitors' ), true ) ? $scope : 'everyone';

		// --- Block rules -------------------------------------------------
		$rules    = DJRP_Rules::all();
		$submitted = isset( $_POST['block'] ) && is_array( $_POST['block'] ) ? array_keys( wp_unslash( $_POST['block'] ) ) : array();
		$block     = array();
		foreach ( array_keys( $rules ) as $id ) {
			$block[ $id ] = in_array( $id, $submitted, true );
		}
		$options['block'] = $block;

		// --- Harvest ceiling ---------------------------------------------
		$max                     = (int) self::post_string( 'max_per_page', '20' );
		$options['max_per_page'] = ( $max > 0 ) ? min( 100, $max ) : 20;

		// --- Response ----------------------------------------------------
		$options['error_message'] = sanitize_text_field( self::post_string( 'error_message' ) );
		$options['error_message'] = substr( $options['error_message'], 0, 300 );

		$status                  = sanitize_text_field( self::post_string( 'status_code', 'default' ) );
		$options['status_code']  = in_array( $status, array( 'default', '401', '403', '404', '405', '429' ), true ) ? $status : 'default';

		// --- Exclusions ---------------------------------------------------
		$options['exclude_users'] = preg_replace( '/[^0-9,\s]/', '', sanitize_text_field( self::post_string( 'exclude_users' ) ) );
		$options['exclude_ips']   = substr( sanitize_text_field( self::post_string( 'exclude_ips' ) ), 0, 500 );

		// --- Hardening ------------------------------------------------------
		$harden = isset( $_POST['harden'] ) && is_array( $_POST['harden'] ) ? array_keys( wp_unslash( $_POST['harden'] ) ) : array();
		foreach ( array_keys( DJRP_Settings::defaults()['harden'] ) as $key ) {
			$options['harden'][ $key ] = in_array( $key, $harden, true );
		}

		// --- Per-role access --------------------------------------------------
		$options['default_allow'] = isset( $_POST['default_allow'] );

		// Only the role shown on screen is submitted, so the others are safe.
		$role = sanitize_key( self::post_string( 'role' ) );

		if ( $role && self::valid_role( $role ) ) {
			$options['roles'][ $role ] = array(
				'default_allow' => isset( $_POST['role_default_allow'] ),
				'allow_list'    => self::split_patterns( isset( $_POST['role_allow'] ) ? wp_unslash( $_POST['role_allow'] ) : '' ),
				'deny_list'     => self::split_patterns( isset( $_POST['role_deny'] ) ? wp_unslash( $_POST['role_deny'] ) : '' ),
			);
		}

		DJRP_Settings::save( $options );

		self::redirect( array( 'djrp_notice' => 'saved' ) );
	}

	/**
	 * Read a scalar POST value as a string.
	 *
	 * The settings form is nonce-protected, but a stray array in a field
	 * would still fatal sanitize_key()/sanitize_text_field() on PHP 8 rather
	 * than reject the value. Cheap to be sure.
	 *
	 * @param string $key     Field name.
	 * @param string $default Fallback.
	 * @return string
	 */
	private static function post_string( $key, $default = '' ) {
		if ( ! isset( $_POST[ $key ] ) || ! is_scalar( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return $default;
		}
		return (string) wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	}

	/**
	 * Split a textarea into a clean pattern list.
	 *
	 * @param string $raw Raw textarea value.
	 * @return array
	 */
	private static function split_patterns( $raw ) {
		if ( ! is_string( $raw ) ) {
			return array();
		}

		$lines = preg_split( '/[\r\n]+/', wp_unslash( $raw ) );
		$out   = array();

		foreach ( (array) $lines as $line ) {
			$line = trim( sanitize_text_field( $line ) );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}

		return array_slice( array_unique( $out ), 0, 200 );
	}

	/**
	 * Is this a real role, or our visitor pseudo-role?
	 *
	 * @param string $role Role slug.
	 * @return bool
	 */
	private static function valid_role( $role ) {
		if ( 'none' === $role ) {
			return true;
		}

		$editable = get_editable_roles();

		return isset( $editable[ $role ] );
	}

	/**
	 * Redirect back to the settings page with a notice flag.
	 *
	 * @param array $args Query args.
	 * @return void
	 */
	private static function redirect( $args ) {
		$args['page'] = self::PAGE_SLUG;
		wp_safe_redirect( add_query_arg( $args, admin_url( 'options-general.php' ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Render
	 * ------------------------------------------------------------------ */

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'disable-json-rest-pro' ) );
		}

		$options = DJRP_Settings::get();
		$rules   = DJRP_Rules::all();
		$stats   = get_option( 'djrp_stats', array() );
		$role    = isset( $_GET['role'] ) ? sanitize_key( wp_unslash( $_GET['role'] ) ) : 'none'; // phpcs:ignore WordPress.Security.NonceVerification
		$notice  = isset( $_GET['djrp_notice'] ) ? sanitize_key( wp_unslash( $_GET['djrp_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

		if ( ! self::valid_role( $role ) ) {
			$role = 'none';
		}

		include DJRP_DIR . 'admin/view.php';
	}
}
