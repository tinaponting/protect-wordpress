<?php
/**
 * Per-role route access and REST hardening.
 *
 * @package DisableJsonRestPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * REST filter and hardening.
 */
class DJRP_Rest {

	/**
	 * Whether harden() has run.
	 *
	 * @var bool
	 */
	private static $hardened = false;

	/**
	 * Per-role allow/deny gate.
	 *
	 * Runs late — after the blocker, after routing — and only sees requests
	 * the blocker let through. The early blocker owns the hard rules; this
	 * owns the softer, per-role allowlist.
	 *
	 * @param WP_Error|null|true $access Current authentication state.
	 * @return WP_Error|null|true
	 */
	public static function filter_auth( $access ) {
		$ctx = self::context();

		// Only meaningful for actual REST requests.
		if ( ! $ctx['is_rest'] ) {
			return $access;
		}

		if ( self::bypass() ) {
			return $access;
		}

		$options = DJRP_Settings::get();
		$route   = $ctx['route'];
		$roles   = self::current_roles();

		foreach ( $roles as $role ) {

			if ( ! isset( $options['roles'][ $role ] ) || ! is_array( $options['roles'][ $role ] ) ) {
				continue;
			}

			$conf = $options['roles'][ $role ];

			// Whole-role opt-in.
			if ( ! empty( $conf['default_allow'] ) ) {
				return $access;
			}

			// Explicit deny wins over explicit allow, so a broad allow can be
			// carved back down without editing the allowlist.
			if ( self::matches( isset( $conf['deny_list'] ) ? $conf['deny_list'] : array(), $route ) ) {
				return self::error( $access );
			}

			if ( self::matches( isset( $conf['allow_list'] ) ? $conf['allow_list'] : array(), $route ) ) {
				return $access;
			}
		}

		// No rule matched. Fall back to the global default for unknown roles.
		return empty( $options['default_allow'] ) ? self::error( $access ) : $access;
	}

	/**
	 * Should this request skip the per-role gate?
	 *
	 * @return bool
	 */
	private static function bypass() {
		$options = DJRP_Settings::get();

		if ( ! empty( $options['harden']['exempt_admins'] ) && is_user_logged_in() ) {
			if ( current_user_can( 'manage_options' ) ) {
				return true;
			}
		}

		if ( DJRP_Blocker::is_excluded() ) {
			return true;
		}

		/**
		 * Filter the per-role gate bypass.
		 *
		 * @param bool $bypass  Whether to bypass.
		 * @param array $ctx    Request context.
		 */
		return (bool) apply_filters( 'djrp_bypass', false, DJRP_Blocker::context() );
	}

	/**
	 * Roles for the current user.
	 *
	 * @return array
	 */
	public static function current_roles() {
		if ( ! is_user_logged_in() ) {
			return array( 'none' );
		}

		$user = wp_get_current_user();

		return (array) $user->roles;
	}

	/**
	 * Test a route against a list of patterns.
	 *
	 * Patterns are anchored, so /wp/v2/posts matches that route and nothing
	 * else. Write /wp/v2/posts/(.*) for a route and everything under it. This
	 * is the semantics both parent plugins used, and it is deliberate: an
	 * allowlist that silently widens is worse than one that needs a wildcard.
	 *
	 * A pattern that opens with a delimiter that cannot begin a route (# ~ %
	 * @) is treated as a full regex and used verbatim, flags and all. That is
	 * the escape hatch for case-insensitive or otherwise custom matching.
	 *
	 * @param array  $patterns Patterns.
	 * @param string $route    Route to test.
	 * @return bool
	 */
	public static function matches( $patterns, $route ) {
		foreach ( (array) $patterns as $pattern ) {

			$pattern = trim( html_entity_decode( (string) $pattern, ENT_QUOTES ) );

			if ( '' === $pattern ) {
				continue;
			}

			$regex = self::compile_pattern( $pattern );

			// Guard against a broken pattern taking the site down.
			if ( false === @preg_match( $regex, '' ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
				continue;
			}

			if ( preg_match( $regex, $route ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Turn a stored pattern into a usable regex.
	 *
	 * A leading slash is never treated as a delimiter, because every route
	 * starts with one and misreading /wp/v2/ as a delimited literal silently
	 * changes what the pattern means.
	 *
	 * @param string $pattern Stored pattern.
	 * @return string
	 */
	private static function compile_pattern( $pattern ) {
		$delimiters = array( '#', '~', '%', '@' );
		$first      = $pattern[0];

		if ( in_array( $first, $delimiters, true ) ) {
			$last = strrpos( $pattern, $first );

			if ( $last > 0 ) {
				$flags = substr( $pattern, $last + 1 );

				// Valid regex modifiers, or none at all.
				if ( '' === $flags || preg_match( '/^[imsxuADSUXJn]*$/', $flags ) ) {
					return substr( $pattern, 0, $last + 1 ) . $flags;
				}
			}
		}

		return '@^' . str_replace( '@', '\@', $pattern ) . '$@i';
	}

	/**
	 * Build the error returned by the per-role gate.
	 *
	 * @param WP_Error|null|true $access Current state.
	 * @return WP_Error
	 */
	private static function error( $access ) {
		$message = (string) DJRP_Settings::val( 'error_message', '' );

		if ( '' === trim( $message ) ) {
			$message = __( 'REST API access is not allowed.', 'disable-json-rest-pro' );
		}

		$message = str_replace( '%%error%%', '', $message );
		$status  = is_user_logged_in() ? 403 : 401;

		$code = DJRP_Settings::val( 'status_code', 'default' );
		if ( 'default' !== $code && '' !== $code ) {
			$code = (int) $code;
			if ( in_array( $code, array( 401, 403, 404, 405, 429 ), true ) ) {
				$status = $code;
			}
		}

		if ( is_wp_error( $access ) ) {
			$access->add( 'djrp_rest_forbidden', $message, array( 'status' => $status ) );
			return $access;
		}

		return new WP_Error( 'djrp_rest_forbidden', $message, array( 'status' => $status ) );
	}

	/* ---------------------------------------------------------------------
	 * Hardening
	 * ------------------------------------------------------------------ */

	/**
	 * Remove REST's self-advertising and tighten the protocol.
	 *
	 * @return void
	 */
	public static function harden() {
		if ( self::$hardened ) {
			return;
		}
		self::$hardened = true;

		// <link rel="https://api.w.org/" ...> in <head>.
		if ( DJRP_Settings::harden( 'strip_head_link' ) ) {
			remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		}

		// RSD / XML-RPC advertisement of the API.
		if ( DJRP_Settings::harden( 'strip_rsd' ) ) {
			remove_action( 'xmlrpc_rsd_apis', 'rest_output_rsd' );
		}

		// The Link: <.../wp-json/> response header.
		if ( DJRP_Settings::harden( 'strip_header_link' ) ) {
			remove_action( 'template_redirect', 'rest_output_link_header', 11 );
		}

		// oEmbed discovery links in <head>.
		if ( DJRP_Settings::harden( 'strip_oembed_head' ) ) {
			remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		}

		// JSONP wraps JSON in a script tag, which turns a read endpoint into
		// a cross-origin read. Off by default in our favour.
		if ( DJRP_Settings::harden( 'disable_jsonp' ) ) {
			add_filter( 'rest_jsonp_enabled', '__return_false', 100 );
		}

		// ?author=1 — the non-REST twin of /wp/v2/users.
		if ( DJRP_Settings::harden( 'remove_user_enum' ) ) {
			add_action( 'template_redirect', array( __CLASS__, 'block_author_enum' ), 0 );
		}

		// Refuse REST over plain HTTP.
		if ( DJRP_Settings::harden( 'enforce_ssl' ) ) {
			add_filter( 'rest_pre_dispatch', array( __CLASS__, 'require_ssl' ), 100, 3 );
		}
	}

	/**
	 * Send ?author=N back to the home page for anonymous visitors.
	 *
	 * @return void
	 */
	public static function block_author_enum() {
		if ( is_user_logged_in() || ! isset( $_GET['author'] ) ) {
			return;
		}

		// ?author[]=1 is a probe too, and an array here would blow up
		// sanitize_text_field() on PHP 8.
		if ( ! is_scalar( $_GET['author'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$author = sanitize_text_field( wp_unslash( $_GET['author'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		if ( ! is_numeric( $author ) ) {
			return;
		}

		// Do not interfere with the REST API's own ?author= handling.
		$ctx = DJRP_Blocker::context();
		if ( $ctx['is_rest'] ) {
			return;
		}

		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}

	/**
	 * Block non-SSL REST requests.
	 *
	 * @param mixed           $result  Pre-dispatch result.
	 * @param WP_REST_Server  $server  Server.
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public static function require_ssl( $result, $server, $request ) {
		if ( is_ssl() ) {
			return $result;
		}

		return new WP_Error(
			'djrp_ssl_required',
			__( 'The REST API requires a secure connection.', 'disable-json-rest-pro' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * Shorthand for the request context.
	 *
	 * @return array
	 */
	private static function context() {
		return DJRP_Blocker::context();
	}
}
