<?php
/**
 * Option storage, defaults and migration.
 *
 * @package DisableJsonRestPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Settings class.
 */
class DJRP_Settings {

	const OPTION = 'djrp_options';

	/**
	 * Cached options for this request.
	 *
	 * @var array|null
	 */
	private static $cache = null;

	/**
	 * Default option set.
	 *
	 * Route allow/deny patterns are shared from Disable REST API. Everything
	 * else is the layer lifted from REST Pro Tools.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'version' => DJRP_VERSION,

			// Per-role route access (from Disable REST API).
			'default_allow' => true,
			'roles'         => array(
				'none' => array(
					'default_allow' => false,
					'allow_list'    => array(),
					'deny_list'     => array(),
				),
			),

			// Master mode (from REST Pro Tools "Priority Tools").
			// 'visitors' blocks all REST for anonymous, 'everyone' for all.
			'mode' => 'visitors',

			// Who the block rules apply to.
			// 'everyone'  - anonymous and logged-in alike (admins exempt above).
			// 'visitors'  - anonymous only.
			'block_scope' => 'everyone',

			// The block list. Each key is a rule id from DJRP_Rules::all().
			'block' => array_fill_keys( array_keys( DJRP_Rules::all() ), true ),

			// Exclusions.
			'exclude_users' => '',
			'exclude_ips'   => '',

			// Harvest limits.
			'max_per_page' => 20,

			// Response shaping.
			'error_message' => 'REST API access is not allowed.',
			'status_code'   => 'default',

			// Hardening toggles.
			'harden' => array(
				'strip_head_link'   => true,
				'strip_rsd'         => true,
				'strip_header_link' => true,
				'disable_jsonp'     => true,
				'strip_oembed_head' => true,
				'remove_user_enum'  => true,
				'enforce_ssl'       => false,
				// Admins are exempt from the rule list. The block editor calls
				// /wp/v2/posts on every keystroke; locking it out breaks the
				// site, and no anonymous scraper benefits from this being off.
				'exempt_admins'     => true,
			),
		);
	}

	/**
	 * Get the full option array, merged over defaults.
	 *
	 * @return array
	 */
	public static function get() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		$defaults = self::defaults();
		$options  = array_merge( $defaults, $stored );

		// Merge nested keys so new toggles appear after an upgrade.
		foreach ( array( 'roles', 'block', 'harden' ) as $key ) {
			$options[ $key ] = array_merge(
				isset( $defaults[ $key ] ) ? $defaults[ $key ] : array(),
				isset( $stored[ $key ] ) && is_array( $stored[ $key ] ) ? $stored[ $key ] : array()
			);
		}

		// A rule added in a later version defaults to ON if we have never
		// stored a value for it. A rule the owner turned off stays off.
		foreach ( DJRP_Rules::all() as $id => $rule ) {
			if ( ! array_key_exists( $id, $options['block'] ) ) {
				$options['block'][ $id ] = ! empty( $rule['default_on'] );
			}
			$options['block'][ $id ] = (bool) $options['block'][ $id ];
		}

		/*
		 * Normalise every role entry. Imported or hand-edited data can be
		 * missing keys, and the settings screen calls implode() on these
		 * without checking — a missing deny_list once fatalled the whole
		 * options page on a fresh install. Cheap to guarantee here.
		 */
		if ( ! is_array( $options['roles'] ) ) {
			$options['roles'] = array();
		}

		foreach ( $options['roles'] as $role => $conf ) {
			if ( ! is_array( $conf ) ) {
				$options['roles'][ $role ] = array(
					'default_allow' => false,
					'allow_list'    => array(),
					'deny_list'     => array(),
				);
				continue;
			}

			foreach ( array( 'allow_list', 'deny_list' ) as $key ) {
				$options['roles'][ $role ][ $key ] = isset( $conf[ $key ] ) && is_array( $conf[ $key ] )
					? array_values( $conf[ $key ] )
					: array();
			}

			$options['roles'][ $role ]['default_allow'] = ! empty( $conf['default_allow'] );
		}

		// Exclusions are strings, never null.
		foreach ( array( 'exclude_users', 'exclude_ips', 'error_message' ) as $key ) {
			if ( ! is_string( $options[ $key ] ) ) {
				$options[ $key ] = '';
			}
		}

		/**
		 * Filter the plugin options after defaults are merged.
		 *
		 * @param array $options Options.
		 */
		$options = apply_filters( 'djrp_options', $options );

		self::$cache = $options;
		return $options;
	}

	/**
	 * Read a single top-level option.
	 *
	 * @param string $key     Key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function val( $key, $default = null ) {
		$options = self::get();
		return array_key_exists( $key, $options ) ? $options[ $key ] : $default;
	}

	/**
	 * Read a hardening toggle.
	 *
	 * @param string $key Key.
	 * @return bool
	 */
	public static function harden( $key ) {
		$options = self::get();
		return ! empty( $options['harden'][ $key ] );
	}

	/**
	 * Persist the full option array.
	 *
	 * @param array $options Options.
	 * @return bool
	 */
	public static function save( $options ) {
		$options['version'] = DJRP_VERSION;
		self::$cache        = null;
		return update_option( self::OPTION, $options );
	}

	/**
	 * Restore factory defaults.
	 *
	 * @return bool
	 */
	public static function reset() {
		self::$cache = null;
		return update_option( self::OPTION, self::defaults() );
	}

	/**
	 * One-time upgrade / import from the two parent plugins.
	 *
	 * Runs on `admin_init` until it has completed once. Imports the parent's
	 * per-role allowlist so the owner does not have to rebuild it, then leaves
	 * the parent options alone (deleting them is the owner's call, not ours).
	 *
	 * @return array Report of what was imported, for the admin notice.
	 */
	public static function maybe_import() {
		$report = array( 'roles' => false, 'rest_pro' => false );

		if ( get_option( 'djrp_import_done' ) ) {
			return $report;
		}

		$options = self::get();

		// --- From Disable REST API: per-role allow/deny lists. -------------
		$old = get_option( 'disable_rest_api_options', null );

		if ( is_array( $old ) && ! empty( $old['roles'] ) ) {
			foreach ( $old['roles'] as $role => $conf ) {
				$allow = ! empty( $conf['default_allow'] );

				// Convert the allow_list (route => bool map) to two pattern lists.
				$allow_patterns = array();
				$deny_patterns  = array();

				if ( ! empty( $conf['allow_list'] ) && is_array( $conf['allow_list'] ) ) {
					foreach ( $conf['allow_list'] as $route => $is_allowed ) {
						$route = html_entity_decode( (string) $route, ENT_QUOTES );
						if ( '' === trim( $route ) ) {
							continue;
						}
						if ( $is_allowed ) {
							$allow_patterns[] = $route;
						} else {
							$deny_patterns[]  = $route;
						}
					}
				}

				$options['roles'][ $role ] = array(
					'default_allow' => $allow,
					'allow_list'    => $allow_patterns,
					'deny_list'     => $deny_patterns,
				);
			}

			if ( array_key_exists( 'default_allow', $old ) ) {
				$options['default_allow'] = (bool) $old['default_allow'];
			}

			$report['roles'] = true;
		}

		// --- From REST Pro Tools: mode, exclusions, message, status. ------
		$priority = get_option( 'restprotools_priority_tools', null );

		if ( is_array( $priority ) ) {
			if ( isset( $priority['disable_rest'] ) ) {
				// REST Pro's three states: 'enable' (allow), 'disable' (all),
				// 'visitors' (anonymous only). Map onto our two.
				if ( 'disable' === $priority['disable_rest'] ) {
					$options['mode'] = 'everyone';
				} elseif ( 'visitors' === $priority['disable_rest'] ) {
					$options['mode'] = 'visitors';
				}
			}

			if ( ! empty( $priority['exclude_users'] ) ) {
				$options['exclude_users'] = $priority['exclude_users'];
			}
			if ( ! empty( $priority['exclude_ips'] ) ) {
				$options['exclude_ips'] = $priority['exclude_ips'];
			}
			if ( ! empty( $priority['error_message'] ) ) {
				$options['error_message'] = $priority['error_message'];
			}
			if ( ! empty( $priority['status_code'] ) ) {
				$options['status_code'] = $priority['status_code'];
			}

			// JSONP hardening.
			if ( ! empty( $priority['disable_jsonp'] ) ) {
				$options['harden']['disable_jsonp'] = true;
			}
			if ( isset( $priority['enforce_ssl'] ) && 'block' === $priority['enforce_ssl'] ) {
				$options['harden']['enforce_ssl'] = true;
			}

			$report['rest_pro'] = true;
		}

		// REST Pro "REST headers" toggles, mapped onto our hardening set.
		$headers = get_option( 'restprotools_rest_headers', null );

		if ( is_array( $headers ) ) {
			$map = array(
				'header_04' => 'strip_rsd',
				'header_05' => 'strip_head_link',
				'header_06' => 'strip_header_link',
				'header_08' => 'strip_oembed_head',
			);
			foreach ( $map as $old_key => $new_key ) {
				if ( isset( $headers[ $old_key ] ) ) {
					// REST Pro's default is 'enable' = the removal is active.
					$is_disabled = in_array( $headers[ $old_key ], array( 'disable', 'visitors' ), true );
					$options['harden'][ $new_key ] = ! $is_disabled;
				}
			}
		}

		self::save( $options );
		update_option( 'djrp_import_done', 1 );

		return $report;
	}
}
