<?php
/**
 * The block rules.
 *
 * Each rule is an independent matcher. A request is blocked if ANY enabled
 * rule matches, so rules stay small and readable instead of one giant regex.
 *
 * Matcher types
 * -------------
 * route   - regex against the REST route (/wp/v2/users), only when the
 *           request is a REST request.
 * uri     - regex against the full decoded request URI.
 * query   - regex against the decoded query string.
 * root    - the request is a REST request for the bare index (/wp-json/).
 * perpage - query asks for more items than the configured maximum.
 *
 * @package DisableJsonRestPro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Rule registry.
 */
class DJRP_Rules {

	/**
	 * Get every rule.
	 *
	 * @return array
	 */
	public static function all() {
		$rules = array(

			// ------------------------------------------------------ users ----
			array(
				'id'         => 'users',
				'label'      => __( 'User enumeration', 'disable-json-rest-pro' ),
				'route'      => '#^/wp/v2/users(/|$)#',
				'uri'        => array( '#/wp-json/wp/v2/users#i', '#rest_route=/?wp/v2/users#i' ),
				'default_on' => true,
				'why'        => __( 'Spits out author names, IDs, slugs and avatars. The single most useful feed for brute-forcing wp-login.php.', 'disable-json-rest-pro' ),
			),

			// ------------------------------------------------------ batch ----
			array(
				'id'         => 'batch',
				'label'      => __( 'Batch endpoint', 'disable-json-rest-pro' ),
				'route'      => '#^/batch(/|$)#',
				'uri'        => array( '#/wp-json/batch#i' ),
				'query'      => array( '#rest_route=/?batch#i' ),
				'default_on' => true,
				'why'        => __( 'Lets one request bundle many writes. Nothing on the front end needs it, so it is pure attack surface.', 'disable-json-rest-pro' ),
			),

			// ---------------------------------------------------- oembed ----
			array(
				'id'         => 'oembed',
				'label'      => __( 'oEmbed endpoint', 'disable-json-rest-pro' ),
				'route'      => '#^/oembed(/|$)#',
				'uri'        => array(),
				'query'      => array( '#rest_route=/?oembed#i', '#(^|&)oembed=true#i' ),
				'default_on' => true,
				'why'        => __( 'Turns your site into a proxy that renders and returns other people\'s pages, and the ?oembed=true variant hands over raw post content.', 'disable-json-rest-pro' ),
			),

			// ---------------------------------------------- index / recon ---
			array(
				'id'         => 'root_index',
				'label'      => __( 'API index / route listing', 'disable-json-rest-pro' ),
				'root'       => true,
				'default_on' => true,
				'why'        => __( 'A bare /wp-json/ (with or without ?context=view) returns every namespace and route on the site. Free reconnaissance.', 'disable-json-rest-pro' ),
			),

			array(
				'id'         => 'context_edit',
				'label'      => __( 'context=edit requests', 'disable-json-rest-pro' ),
				'query'      => array( '#(^|&)context=edit(&|$)#i' ),
				'default_on' => true,
				'why'        => __( 'Editor context leaks the full field schema, including custom fields and meta keys.', 'disable-json-rest-pro' ),
			),

			// -------------------------------------------------- listings ----
			array(
				'id'         => 'content_listings',
				'label'      => __( 'Posts / pages / users listings', 'disable-json-rest-pro' ),
				'route'      => '#^/wp/v2/(posts|pages|users)(/|$)#',
				'default_on' => true,
				'why'        => __( 'Whole-content collection endpoints. Anonymous callers have no business paging through them.', 'disable-json-rest-pro' ),
			),

			array(
				'id'         => 'per_page',
				'label'      => __( 'Oversized ?per_page harvest', 'disable-json-rest-pro' ),
				'perpage'    => true,
				'default_on' => true,
				'why'        => __( 'Catches bulk grabs such as ?per_page=100. The ceiling is configurable below and applies to every listing route, not just the ones named above.', 'disable-json-rest-pro' ),
			),

			// ------------------------------------------------- type schema ---
			array(
				'id'         => 'types_schema',
				'label'      => __( 'Post type & taxonomy schema', 'disable-json-rest-pro' ),
				'route'      => '#^/wp/v2/(types|taxonomies)(/|$)#',
				'default_on' => true,
				'why'        => __( 'Describes every post type, its fields and its edit links. Covers /wp/v2/types/post?context=edit.', 'disable-json-rest-pro' ),
			),

		);

		$out = array();
		foreach ( $rules as $rule ) {
			$rule = wp_parse_args(
				$rule,
				array(
					'uri'        => array(),
					'query'      => array(),
					'route'      => '',
					'root'       => false,
					'perpage'    => false,
					'default_on' => true,
					'why'        => '',
				)
			);
			// Normalise scalar matchers to arrays.
			foreach ( array( 'uri', 'query' ) as $key ) {
				$rule[ $key ] = (array) $rule[ $key ];
			}
			$out[ $rule['id'] ] = $rule;
		}

		/**
		 * Filter the registered block rules.
		 *
		 * @param array $out Rules keyed by id.
		 */
		return apply_filters( 'djrp_rules', $out );
	}

	/**
	 * Rules the owner has switched on.
	 *
	 * @return array
	 */
	public static function enabled() {
		$options  = DJRP_Settings::get();
		$disabled = isset( $options['block'] ) ? $options['block'] : array();
		$enabled  = array();

		foreach ( self::all() as $id => $rule ) {
			if ( ! empty( $disabled[ $id ] ) ) {
				$enabled[ $id ] = $rule;
			}
		}

		return $enabled;
	}
}
