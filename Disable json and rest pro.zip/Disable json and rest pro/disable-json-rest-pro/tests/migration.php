<?php
/**
 * Migration test: does the import carry both parents' settings across?
 *
 * @package DisableJsonRestPro
 */

define( 'ABSPATH', '/tmp/wp/' );
define( 'DJRP_VERSION', '1.0.0-test' );
define( 'DJRP_DIR', __DIR__ . '/../' );
define( 'DJRP_URL', '/' );
define( 'DJRP_BASENAME', 'disable-json-rest-pro/disable-json-rest-pro.php' );

$GLOBALS['djrp_db']     = array();
$GLOBALS['djrp_options'] = array();

function __( $t, $d = '' ) { return $t; }
function apply_filters( $t, $v ) { return $v; }
function wp_parse_args( $a, $d = array() ) { return is_array( $d ) ? array_merge( $d, (array) $a ) : (array) $a; }
function untrailingslashit( $s ) { return rtrim( $s, '/\\' ); }
function sanitize_text_field( $s ) { return trim( strip_tags( $s ) ); }
function get_option( $n, $d = false ) {
	if ( 'djrp_options' === $n ) { return $GLOBALS['djrp_options']; }
	return array_key_exists( $n, $GLOBALS['djrp_db'] ) ? $GLOBALS['djrp_db'][ $n ] : $d;
}
function update_option( $n, $v ) { $GLOBALS['djrp_db'][ $n ] = $v; $GLOBALS['djrp_options'] = ( 'djrp_options' === $n ) ? $v : $GLOBALS['djrp_options']; return true; }
function delete_option( $n ) { unset( $GLOBALS['djrp_db'][ $n ] ); return true; }
function get_editable_roles() { return array( 'administrator' => array( 'name' => 'Administrator' ) ); }

require __DIR__ . '/../includes/settings.php';
require __DIR__ . '/../includes/rules.php';

// A realistic pair of parent option sets.
$GLOBALS['djrp_db']['disable_rest_api_options'] = array(
	'version'       => '1.9',
	'default_allow' => false,
	'roles'         => array(
		'none' => array(
			'default_allow' => false,
			'allow_list'    => array(
				'&#47;wp&#47;v2&#47;posts' => false,
				'&#47;oembed&#47;1.0&#47;embed' => false,
			),
		),
		'administrator' => array(
			'default_allow' => true,
			'allow_list'    => array(),
		),
	),
);

$GLOBALS['djrp_db']['restprotools_priority_tools'] = array(
	'disable_rest'   => 'visitors',
	'disable_users'  => 'enable',
	'exclude_users'  => '1, 4',
	'exclude_ips'    => '83.186.233.112',
	'error_message'  => 'REST API access not allowed',
	'status_code'    => '403',
	'enforce_ssl'    => 'block',
	'disable_jsonp'  => true,
);

$GLOBALS['djrp_db']['restprotools_rest_headers'] = array(
	'header_04' => 'enable',
	'header_05' => 'enable',
	'header_06' => 'enable',
	'header_08' => 'visitors',
);

$report = DJRP_Settings::maybe_import();
$opt    = $GLOBALS['djrp_db']['djrp_options'];

$pass = 0; $fail = 0;
function check( $label, $got, $want ) {
	global $pass, $fail;
	$ok = ( $got === $want );
	if ( $ok ) { $pass++; printf( "  ok    %-42s %s\n", $label, var_export( $got, true ) ); }
	else      { $fail++; printf( "  FAIL  %-42s got %s, want %s\n", $label, var_export( $got, true ), var_export( $want, true ) ); }
}

echo "=== IMPORT REPORT ===\n";
check( 'roles imported',    $report['roles'],    true );
check( 'rest pro imported', $report['rest_pro'], true );
check( 'import ran once',   (bool) get_option( 'djrp_import_done' ), true );

echo "\n=== FROM DISABLE REST API ===\n";
check( 'global default_allow',   $opt['default_allow'], false );
check( 'visitor default_allow',  $opt['roles']['none']['default_allow'], false );
check( 'admin default_allow',    $opt['roles']['administrator']['default_allow'], true );
check(
	'visitor routes decoded',
	$opt['roles']['none']['deny_list'],
	array( '/wp/v2/posts', '/oembed/1.0/embed' )
);
check( 'visitor allow list empty', $opt['roles']['none']['allow_list'], array() );

echo "\n=== FROM REST PRO TOOLS ===\n";
check( 'mode',              $opt['mode'], 'visitors' );
check( 'exclude_users',     $opt['exclude_users'], '1, 4' );
check( 'exclude_ips',       $opt['exclude_ips'], '83.186.233.112' );
check( 'error_message',     $opt['error_message'], 'REST API access not allowed' );
check( 'status_code',       $opt['status_code'], '403' );
check( 'enforce_ssl on',    $opt['harden']['enforce_ssl'], true );
check( 'disable_jsonp on',  $opt['harden']['disable_jsonp'], true );
check( 'strip_rsd on',      $opt['harden']['strip_rsd'], true );
check( 'strip_head_link on',$opt['harden']['strip_head_link'], true );
check( 'strip_header on',   $opt['harden']['strip_header_link'], true );
// header_08 was 'visitors' in REST Pro = removed only for visitors = off for us.
check( 'oembed head left on', $opt['harden']['strip_oembed_head'], false );

echo "\n=== PARENT OPTIONS PRESERVED ===\n";
check(
	'old disable_rest_api_options still there',
	isset( $GLOBALS['djrp_db']['disable_rest_api_options'] ),
	true
);
check(
	'old restprotools_priority_tools still there',
	isset( $GLOBALS['djrp_db']['restprotools_priority_tools'] ),
	true
);

echo "\n=== IMPORT IS IDEMPOTENT ===\n";
$before = $GLOBALS['djrp_db']['djrp_options'];
$report2 = DJRP_Settings::maybe_import();
check( 'second run reports nothing', $report2['roles'], false );
check( 'options unchanged on rerun', $GLOBALS['djrp_db']['djrp_options'] === $before, true );

echo "\n=== NEW RULE DEFAULTS AFTER UPGRADE ===\n";
// Simulate a stored option set that predates a newly added rule.
$GLOBALS['djrp_options'] = array( 'block' => array( 'users' => false ) );
$s = new ReflectionProperty( 'DJRP_Settings', 'cache' );
$s->setAccessible( true );
$s->setValue( null, null );
$after = DJRP_Settings::get();
check( 'toggled-off rule stays off',   $after['block']['users'], false );
check( 'brand new rule defaults on',  $after['block']['batch'], true );
check( 'unrelated option untouched',   $after['block_scope'], 'everyone' );

echo "\n----------------------------------------\n";
printf( "passed: %d   failed: %d\n", $pass, $fail );
exit( $fail > 0 ? 1 : 0 );
