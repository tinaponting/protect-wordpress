<?php
/**
 * End-to-end request probe.
 *
 * Boots the plugin the way WordPress would and lets a single request run all
 * the way through DJRP_Blocker::run(). Because run() calls exit on a block,
 * the driver script invokes this once per URI as a separate process.
 *
 * Usage: php tests/probe.php <uri> [visitor|admin|editor] [off|visitors|everyone]
 *   stdout: the response body WordPress would have sent (empty if allowed)
 *   stderr: STATUS=<code> BLOCKED=<rule|0>
 */

// ------------------------------------------------------------- stubs ------

define( 'ABSPATH', '/tmp/wp/' );
define( 'DJRP_VERSION', '1.0.0-test' );
define( 'DJRP_DIR', __DIR__ . '/../' );
define( 'DJRP_URL', '/' );
define( 'DJRP_BASENAME', 'disable-json-rest-pro/disable-json-rest-pro.php' );

$GLOBALS['djrp_options'] = array();
$GLOBALS['djrp_stored']  = array();

function __( $t, $d = '' ) { return $t; }
function apply_filters( $tag, $value ) { return $value; }
function wp_parse_args( $a, $d = array() ) { return is_array( $d ) ? array_merge( $d, (array) $a ) : (array) $a; }
function wp_parse_url( $u, $c = -1 ) { return parse_url( $u, $c ); }
function untrailingslashit( $s ) { return rtrim( $s, '/\\' ); }
function sanitize_text_field( $s ) { return is_string( $s ) ? trim( strip_tags( $s ) ) : $s; }
function wp_unslash( $s ) { return $s; }
function is_user_logged_in() { return 'visitor' !== $GLOBALS['djrp_who']; }
function current_user_can( $c ) { return 'admin' === $GLOBALS['djrp_who']; }
function get_current_user_id() { return 'visitor' === $GLOBALS['djrp_who'] ? 0 : 1; }
function wp_get_current_user() { return (object) array( 'ID' => 1, 'roles' => array( 'administrator' ) ); }
function rest_get_url_prefix() { return 'wp-json'; }
function wp_doing_cron() { return false; }
function wp_doing_ajax() { return false; }
function nocache_headers() {}
function is_ssl() { return true; }
function update_option( $n, $v ) { $GLOBALS['djrp_stored'][ $n ] = $v; return true; }
function get_option( $n, $d = false ) {
	if ( 'djrp_options' === $n ) { return $GLOBALS['djrp_options']; }
	if ( array_key_exists( $n, $GLOBALS['djrp_stored'] ) ) { return $GLOBALS['djrp_stored'][ $n ]; }
	return $d;
}
function status_header( $c ) { fwrite( STDERR, 'STATUS=' . $c . "\n" ); }
function home_url( $p = '/' ) { return 'https://example.test' . $p; }
function wp_safe_redirect( $u, $s = 302 ) { fwrite( STDERR, "REDIRECT=$u\n" ); }

// Not used before the block fires, but the compiler needs them to exist.
function wp_json_encode( $d ) { return json_encode( $d ); }
function is_wp_error( $t ) { return false; }

$GLOBALS['djrp_who'] = isset( $argv[2] ) ? $argv[2] : 'visitor';
$uri                 = isset( $argv[1] ) ? $argv[1] : '/';

$parts = parse_url( $uri );
$_SERVER['REQUEST_URI']    = $uri;
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REMOTE_ADDR']    = '203.0.113.9';

$_GET = array();
if ( isset( $parts['query'] ) ) {
	parse_str( $parts['query'], $_GET );
}

require __DIR__ . '/../includes/settings.php';
require __DIR__ . '/../includes/rules.php';
require __DIR__ . '/../includes/blocker.php';

// Optional third argument overrides the master mode, so a test can separate
// "the master switch blocked this" from "a block rule blocked this".
if ( isset( $argv[3] ) ) {
	$opts                    = DJRP_Settings::defaults();
	$opts['mode']            = $argv[3];
	$GLOBALS['djrp_options'] = $opts;
	$s                       = new ReflectionProperty( 'DJRP_Settings', 'cache' );
	$s->setAccessible( true );
	$s->setValue( null, null );
}

DJRP_Blocker::run();

// Reached only when the request was allowed.
fwrite( STDERR, 'STATUS=200 BLOCKED=0' . "\n" );
fwrite( STDOUT, "(allowed)\n" );
