#!/usr/bin/env bash
# Run every check: lint, unit matcher, end-to-end requests, migration.
set -uo pipefail

PHP="${PHP:-php}"
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"

rc=0

echo "=== LINT ==="
while IFS= read -r f; do
	if out="$("$PHP" -l "$f" 2>&1)"; then
		printf '  ok    %s\n' "$f"
	else
		printf '  FAIL  %s\n%s\n' "$f" "$out"
		rc=1
	fi
done < <(find . -name '*.php' -not -path './tests/*' | sort)

echo
echo "=== MATCHER ==="
"$PHP" tests/harness.php | tail -3 || rc=1
"$PHP" tests/harness.php >/dev/null 2>&1 || rc=1

echo
echo "=== END TO END ==="
PHP="$PHP" bash tests/e2e.sh | tail -3 || rc=1
PHP="$PHP" bash tests/e2e.sh >/dev/null 2>&1 || rc=1

echo
echo "=== MIGRATION ==="
"$PHP" tests/migration.php | tail -3 || rc=1
"$PHP" tests/migration.php >/dev/null 2>&1 || rc=1

echo
if [[ $rc -eq 0 ]]; then echo "ALL GREEN"; else echo "FAILURES PRESENT"; fi
exit $rc
