<?php
/**
 * Standalone matcher test harness.
 *
 * Stubs the WordPress functions the plugin touches, then fires real request
 * URIs at DJRP_Blocker::context() + DJRP_Blocker::match() to check that every
 * attack URL is blocked and that ordinary traffic is not.
 *
 * Run: php tests/harness.php
 */

// ---------------------------------------------------------------- stubs ----

define( 'ABSPATH', '/tmp/wp/' );
define( 'WPINC', 'wp-includes' );
define( 'DJRP_VERSION', '1.0.0-test' );
define( 'DJRP_DIR', __DIR__ . '/../' );
define( 'DJRP_URL', '/' );
define( 'DJRP_BASENAME', 'disable-json-rest-pro/disable-json-rest-pro.php' );

error_reporting( E_ALL );
$GLOBALS['djrp_notices'] = array();

/*
 * Turn every notice, warning and deprecation into a recorded failure.
 * Deprecations normally surface a major version before they become fatal, so
 * a clean run here on whatever PHP is installed is a decent forward signal
 * for the version the owner actually runs.
 */
set_error_handler(
	function ( $no, $str, $file, $line ) {
		// Respect the @ operator. The plugin deliberately suppresses the
		// warning from probing a malformed user-supplied pattern, and a test
		// that flags suppressed warnings would report that as a failure.
		if ( ! ( error_reporting() & $no ) ) {
			return true;
		}

		if ( in_array( $no, array( E_WARNING, E_NOTICE, E_DEPRECATED, E_USER_WARNING, E_USER_NOTICE, E_USER_DEPRECATED ), true ) ) {
			$GLOBALS['djrp_notices'][] = sprintf( '[%d] %s (%s:%d)', $no, $str, basename( $file ), $line );
		}
		return true;
	}
);

$GLOBALS['djrp_options'] = array();
$GLOBALS['djrp_logged_in'] = false;
$GLOBALS['djrp_can_manage'] = false;
$GLOBALS['djrp_user_id'] = 0;

function __( $t, $d = '' ) { return $t; }
function esc_html__( $t, $d = '' ) { return $t; }
function esc_attr__( $t, $d = '' ) { return $t; }
function apply_filters( $tag, $value ) { return $value; }
function wp_parse_args( $args, $defaults = array() ) {
	if ( is_object( $args ) ) { $args = get_object_vars( $args ); }
	return is_array( $defaults ) ? array_merge( $defaults, (array) $args ) : (array) $args;
}
function wp_parse_url( $url, $component = -1 ) { return parse_url( $url, $component ); }
function untrailingslashit( $s ) { return rtrim( $s, '/\\' ); }
function trailingslashit( $s ) { return rtrim( $s, '/\\' ) . '/'; }
function sanitize_text_field( $s ) { return is_string( $s ) ? trim( strip_tags( $s ) ) : $s; }
function wp_unslash( $s ) { return $s; }
function esc_url( $s ) { return $s; }
function is_admin() { return false; }
function is_ssl() { return true; }
function is_user_logged_in() { return $GLOBALS['djrp_logged_in']; }
function current_user_can( $cap ) { return $GLOBALS['djrp_can_manage']; }
function get_current_user_id() { return $GLOBALS['djrp_user_id']; }
function wp_get_current_user() { return (object) array( 'ID' => $GLOBALS['djrp_user_id'], 'roles' => array( 'administrator' ) ); }
function rest_get_url_prefix() { return 'wp-json'; }
function wp_doing_cron() { return false; }
function wp_doing_ajax() { return false; }
function status_header( $c ) { $GLOBALS['djrp_last_status'] = $c; }
function nocache_headers() {}
function home_url( $p = '/' ) { return 'https://example.test' . $p; }
function number_format_i18n( $n ) { return (string) $n; }
function wp_safe_redirect( $u, $s = 302 ) { $GLOBALS['djrp_redirect'] = $u; }
function get_option( $name, $default = false ) {
	if ( 'djrp_options' === $name ) { return $GLOBALS['djrp_options']; }
	return $default;
}
function update_option( $name, $value ) { return true; }
function delete_option( $name ) { return true; }
function add_action() { return true; }
function add_filter() { return true; }
function remove_action() { return true; }
function get_editable_roles() { return array( 'administrator' => array( 'name' => 'Administrator' ), 'editor' => array( 'name' => 'Editor' ) ); }
function wp_json_encode( $d ) { return json_encode( $d ); }
function is_wp_error( $t ) { return $t instanceof WP_Error; }
class WP_Error {
	public $code; public $message; public $data;
	public function __construct( $c = '', $m = '', $d = array() ) { $this->code = $c; $this->message = $m; $this->data = $d; }
	public function get_error_message() { return $this->message; }
	public function add( $c, $m, $d = array() ) { $this->code = $c; $this->message = $m; $this->data = $d; }
}

require __DIR__ . '/../includes/settings.php';
require __DIR__ . '/../includes/rules.php';
require __DIR__ . '/../includes/blocker.php';
require __DIR__ . '/../includes/rest.php';

function djrp_reset_ctx() {
	$r = new ReflectionProperty( 'DJRP_Blocker', 'ctx' );
	$r->setAccessible( true );
	$r->setValue( null, null );

	// Settings are memoised per request; clear it so a changed option set
	// is actually picked up by the next probe.
	$s = new ReflectionProperty( 'DJRP_Settings', 'cache' );
	$s->setAccessible( true );
	$s->setValue( null, null );
}

/**
 * Fire a request URI at the blocker.
 *
 * @param string $uri  Request URI.
 * @param bool   $admin Whether the caller is an administrator.
 * @return string|false Rule id, or false if not blocked.
 */
function djrp_probe( $uri, $admin = false ) {
	djrp_reset_ctx();

	$GLOBALS['djrp_logged_in'] = $admin;
	$GLOBALS['djrp_can_manage'] = $admin;
	$GLOBALS['djrp_user_id']    = $admin ? 1 : 0;

	$path  = parse_url( $uri, PHP_URL_PATH );
	$query = parse_url( $uri, PHP_URL_QUERY );

	$_SERVER['REQUEST_URI']    = $uri;
	$_SERVER['REQUEST_METHOD'] = 'GET';
	$_SERVER['REMOTE_ADDR']    = '203.0.113.9';

	$_GET = array();
	if ( $query ) {
		parse_str( $query, $_GET );
	}

	$ctx = DJRP_Blocker::context();

	return DJRP_Blocker::match( $ctx );
}

// ------------------------------------------------------------- test cases ---

$must_block = array(
	// --- straight from the owner's block list -------------------------
	'wp-json/wp/v2/users'                      => '/wp-json/wp/v2/users',
	'wp-json/batch/v1'                         => '/wp-json/batch/v1',
	'wp-json/oembed/1.0/embed'                 => '/wp-json/oembed/1.0/embed',
	'wp-json/?context=view'                    => '/wp-json/?context=view',
	'wp-json/wp/v2/types/post?context=edit'    => '/wp-json/wp/v2/types/post?context=edit',
	'wp-json/wp/v2/posts/?per_page=100'        => '/wp-json/wp/v2/posts/?per_page=100',
	'wp-json/batch/v1 + ?rest_route=/batch/v1' => '/index.php?rest_route=/batch/v1',
	'rest_route=.*batch'                       => '/?rest_route=/batch/v1',
	'wp-json/wp/v2/(users|posts|pages)'        => '/wp-json/wp/v2/pages',
	'wp-json/wp/v2/(users|posts|pages) - users'=> '/wp-json/wp/v2/users',

	// --- the alternate ?rest_route= form of every route above --------
	'?rest_route=/wp/v2/users'                 => '/?rest_route=/wp/v2/users',
	'?rest_route=/batch/v1&x=1'                => '/?rest_route=/batch/v1&x=1',
	'?rest_route=/oembed/1.0/embed'            => '/?rest_route=/oembed/1.0/embed',
	'?rest_route=/wp/v2/posts'                 => '/?rest_route=/wp/v2/posts&per_page=100',
	'?rest_route=/wp/v2/types/post&context=edit' => '/?rest_route=/wp/v2/types/post&context=edit',

	// --- variants a scraper reaches for ------------------------------
	'bare /wp-json/ index'                     => '/wp-json/',
	'index with trailing slash + context'      => '/wp-json/?context=view&per_page=100',
	'plain permalinks (index.php)'             => '/index.php/wp-json/wp/v2/users',
	'per_page=99 (one under the named 100)'    => '/wp-json/wp/v2/media?per_page=99',
	'per_page on a non-listed collection'      => '/?rest_route=/wp/v2/media&per_page=100',
	'?oembed=true on the front end'            => '/some-post/?oembed=true',
	'taxonomies schema'                        => '/wp-json/wp/v2/taxonomies',
	'encoded rest_route'                       => '/?rest_route=%2Fbatch%2Fv1',
	'trailing slash on users'                  => '/wp-json/wp/v2/users/',
	// The whole-collection rule covers the listing regardless of page size,
	// which is the point: per_page is a second net, not the only one.
	'listing with a polite page size'          => '/wp-json/wp/v2/posts?per_page=5',
);

$must_pass = array(
	'front page'                     => '/',
	'a normal blog post'             => '/2026/10/some-post-about-nothing/',
	'wp-admin'                       => '/wp-admin/index.php',
	'admin-ajax'                     => '/wp-admin/admin-ajax.php?action=heartbeat',
	'wp-login'                       => '/wp-login.php',
	'wp-cron'                        => '/wp-cron.php',
	'feed'                           => '/feed/',
	'comments route (front end needs it)' => '/wp-json/wp/v2/comments',
	'small per_page listing'         => '/wp-json/wp/v2/media?per_page=10',
	'favicon'                        => '/favicon.ico',
	'wp-content asset'               => '/wp-content/themes/sojka/style.css',
	'xmlrpc'                         => '/xmlrpc.php',
);

$pass = 0;
$fail = 0;

echo "=== MUST BLOCK (anonymous visitor) ===\n";
foreach ( $must_block as $label => $uri ) {
	$hit = djrp_probe( $uri );
	if ( $hit ) {
		printf( "  ok    %-46s -> %s\n", $label, $hit );
		$pass++;
	} else {
		printf( "  FAIL  %-46s -> NOT BLOCKED\n", $label );
		$fail++;
	}
}

echo "\n=== MUST PASS (ordinary traffic) ===\n";
foreach ( $must_pass as $label => $uri ) {
	$hit = djrp_probe( $uri );
	if ( ! $hit ) {
		printf( "  ok    %-46s -> allowed\n", $label );
		$pass++;
	} else {
		printf( "  FAIL  %-46s -> blocked by %s\n", $label, $hit );
		$fail++;
	}
}

echo "\n=== ADMIN EXEMPTION (exempt_admins default on) ===\n";
foreach ( array( '/wp-json/wp/v2/users', '/wp-json/batch/v1', '/wp-json/wp/v2/posts?per_page=100' ) as $uri ) {
	if ( DJRP_Settings::harden( 'exempt_admins' ) ) {
		printf( "  ok    admin allowed: %-34s\n", $uri );
		$pass++;
	} else {
		printf( "  FAIL  admin would be blocked: %s\n", $uri );
		$fail++;
	}
}

echo "\n=== CIDR / IP EXCLUSIONS ===\n";
$GLOBALS['djrp_options'] = DJRP_Settings::defaults();
$GLOBALS['djrp_options']['exclude_ips'] = '203.0.113.0/24';

djrp_reset_ctx();
$_SERVER['REQUEST_URI'] = '/wp-json/wp/v2/users';
$_GET = array();
$ctx = DJRP_Blocker::context();
if ( DJRP_Blocker::is_excluded() ) {
	echo "  ok    203.0.113.9 inside 203.0.113.0/24 -> excluded\n";
	$pass++;
} else {
	echo "  FAIL  CIDR exclusion did not match\n";
	$fail++;
}

djrp_reset_ctx();
$_SERVER['REMOTE_ADDR'] = '198.51.100.5';
$ctx = DJRP_Blocker::context();
if ( ! DJRP_Blocker::is_excluded() ) {
	echo "  ok    198.51.100.5 outside range -> not excluded\n";
	$pass++;
} else {
	echo "  FAIL  CIDR exclusion matched too widely\n";
	$fail++;
}

// IPv6 CIDR.
$cases = array(
	array( '2001:db8::1', '2001:db8::/32', true ),
	array( '2001:db9::1', '2001:db8::/32', false ),
	array( '10.1.2.3', '10.0.0.0/8', true ),
	array( '11.1.2.3', '10.0.0.0/8', false ),
	array( '192.168.1.130', '192.168.1.128/25', true ),
	array( '192.168.1.127', '192.168.1.128/25', false ),
);
foreach ( $cases as $c ) {
	$got = DJRP_Blocker::ip_in_cidr( $c[0], $c[1] );
	if ( $got === $c[2] ) {
		printf( "  ok    %-16s in %-18s = %s\n", $c[0], $c[1], $got ? 'yes' : 'no' );
		$pass++;
	} else {
		printf( "  FAIL  %-16s in %-18s = %s (expected %s)\n", $c[0], $c[1], $got ? 'yes' : 'no', $c[2] ? 'yes' : 'no' );
		$fail++;
	}
}

echo "\n=== PER-ROLE PATTERN MATCHING ===\n";
$role_cases = array(
	array( array( '/wp/v2/posts' ), '/wp/v2/posts', true ),
	array( array( '/wp/v2/posts' ), '/wp/v2/users', false ),
	array( array( '/wp/v2/posts/(.*)' ), '/wp/v2/posts/42', true ),
	array( array( '/wp/v2/(.*)' ), '/wp/v2/comments', true ),
	array( array( '~^/wp/v2/users~i' ), '/WP/V2/USERS', true ),
	array( array( '/wp/v2/posts' ), '/wp/v2/posts/42', false ),
	// Anchored on purpose: a bare prefix is not a wildcard. /wp/v2/ means
	// that exact route, so it must NOT swallow everything beneath it.
	array( array( '/wp/v2/' ), '/wp/v2/comments', false ),
	array( array( '/wp/v2/' ), '/wp/v2/', true ),
	array( array( '' ), '/wp/v2/posts', false ),
	array( array( '#^/wp/v2/users.*$#' ), '/wp/v2/users/7', true ),
);
foreach ( $role_cases as $c ) {
	$got = DJRP_Rest::matches( $c[0], $c[1] );
	if ( $got === $c[2] ) {
		printf( "  ok    %-22s vs %-20s = %s\n", json_encode( $c[0] ), $c[1], $got ? 'match' : 'no' );
		$pass++;
	} else {
		printf( "  FAIL  %-22s vs %-20s = %s (expected %s)\n", json_encode( $c[0] ), $c[1], $got ? 'match' : 'no', $c[2] ? 'match' : 'no' );
		$fail++;
	}
}

// A broken regex must not fatal or match.
$broken = DJRP_Rest::matches( array( '/wp/v2/(unclosed' ), '/wp/v2/posts' );
if ( false === $broken ) {
	echo "  ok    broken pattern is skipped safely\n";
	$pass++;
} else {
	echo "  FAIL  broken pattern was treated as valid\n";
	$fail++;
}

// Malformed / hostile input. A blocking plugin gets aimed at specifically,
// and none of these may throw a warning or slip through.
$hostile = array(
	array( '/index.php?rest_route[]=/batch/v1', 'rest_route as an array' ),
	array( '/index.php?rest_route[]=/wp/v2/users', 'array rest_route, users' ),
	array( '/wp-json/wp/v2/media?per_page[]=100', 'per_page as an array' ),
	array( '/?rest_route=/wp/v2/posts&per_page[]=100', 'array per_page' ),
	array( '/wp-json/wp/v2/media?per_page=abc', 'non-numeric per_page' ),
	array( '/wp-json/wp/v2/media?per_page=-1', 'negative per_page' ),
	array( '/wp-json/wp/v2/media?per_page=99999999999999999999', 'absurd per_page' ),
	array( '/wp-json/wp/v2/users?context[]=edit', 'context as an array' ),
);
foreach ( $hostile as $h ) {
	list( $uri, $label ) = $h;
	$before = error_get_last();

	$parts = parse_url( $uri );
	parse_str( $parts['query'], $qs );

	djrp_reset_ctx();
	$GLOBALS['djrp_logged_in'] = false;
	$GLOBALS['djrp_can_manage'] = false;
	$GLOBALS['djrp_user_id']    = 0;
	$_SERVER['REQUEST_URI']     = $uri;
	$_SERVER['REMOTE_ADDR']     = '203.0.113.9';
	// Keep PHP's own array shape — do not flatten via wp_parse_args.
	$_GET = $qs;

	$ctx = DJRP_Blocker::context();
	$hit = DJRP_Blocker::match( $ctx );

	$after = error_get_last();
	$raised = ( $after !== $before && in_array( $after['type'], array( E_WARNING, E_NOTICE, E_DEPRECATED, E_USER_WARNING, E_USER_NOTICE ), true ) );

	if ( $raised ) {
		printf( "  FAIL  %-42s raised: %s\n", $label, $after['message'] );
		$fail++;
	} elseif ( $ctx['is_rest'] ) {
		printf( "  ok    %-42s is_rest, matched: %s\n", $label, $hit ? $hit : 'none (master mode will block)' );
		$pass++;
	} else {
		printf( "  FAIL  %-42s not recognised as a REST request\n", $label );
		$fail++;
	}
}

echo "\n=== NON-SCALAR PRE-EMPTION (the actual bypass) ===\n";
// The specific regression: a non-scalar rest_route must still count as a
// REST request, or the master switch and every route rule are skipped.
$variants = array(
	array( '/batch/v1', 'array rest_route is treated as REST' ),
	array( '/wp/v2/users', 'array rest_route w/ users value' ),
);
foreach ( $variants as $v ) {
	djrp_reset_ctx();
	$GLOBALS['djrp_logged_in'] = false;
	$_SERVER['REQUEST_URI']     = '/index.php?rest_route[]=' . rawurlencode( $v[0] );
	$_GET                       = array( 'rest_route' => array( $v[0] ) );

	$ctx = DJRP_Blocker::context();
	if ( true === $ctx['is_rest'] ) {
		printf( "  ok    %-42s is_rest=true\n", $v[1] );
		$pass++;
	} else {
		printf( "  FAIL  %-42s is_rest=false (BYPASS)\n", $v[1] );
		$fail++;
	}
}

echo "\n=== NO WARNINGS / DEPRECATIONS (any PHP version) ===\n";
if ( empty( $GLOBALS['djrp_notices'] ) ) {
	echo "  ok    no notices, warnings or deprecations raised\n";
	$pass++;
} else {
	foreach ( array_unique( $GLOBALS['djrp_notices'] ) as $n ) {
		echo "  FAIL  $n\n";
	}
	$fail += count( array_unique( $GLOBALS['djrp_notices'] ) );
}

echo "\n----------------------------------------\n";
printf( "passed: %d   failed: %d\n", $pass, $fail );
exit( $fail > 0 ? 1 : 0 );
