#!/usr/bin/env bash
# End-to-end driver: one process per request, because a block calls exit.
set -uo pipefail

PHP="${PHP:-php}"
HERE="$(cd "$(dirname "$0")" && pwd)"

declare -a CASES=(
  # uri|who|mode|expect_status (0 = expect allowed)
  "/wp-json/wp/v2/users|visitor|visitors|401"
  "/wp-json/batch/v1|visitor|visitors|401"
  "/wp-json/oembed/1.0/embed|visitor|visitors|401"
  "/wp-json/?context=view|visitor|visitors|401"
  "/wp-json/wp/v2/types/post?context=edit|visitor|visitors|401"
  "/wp-json/wp/v2/posts/?per_page=100|visitor|visitors|401"
  "/index.php?rest_route=/batch/v1|visitor|visitors|401"
  "/?rest_route=/wp/v2/users|visitor|visitors|401"
  "/wp-json/|visitor|visitors|401"
  "/?oembed=true|visitor|visitors|401"
  "/wp-json/wp/v2/media?per_page=100|visitor|visitors|401"
  # master mode alone blocks every anonymous REST call...
  "/wp-json/wp/v2/comments|visitor|visitors|401"
  # ...so with the master off, only the rule list speaks, and comments pass.
  "/wp-json/wp/v2/comments|visitor|off|200"
  "/wp-json/wp/v2/users|visitor|off|401"
  "/wp-json/batch/v1|visitor|off|401"
  "/wp-json/wp/v2/posts?per_page=100|visitor|off|401"
  "/wp-json/wp/v2/media?per_page=10|visitor|off|200"
  "/|visitor|visitors|200"
  "/2026/10/hello-world/|visitor|visitors|200"
  "/wp-admin/admin-ajax.php?action=heartbeat|visitor|visitors|200"
  "/wp-cron.php|visitor|visitors|200"
  "/feed/|visitor|visitors|200"
  # admin exemption
  "/wp-json/wp/v2/users|admin|visitors|200"
  "/wp-json/batch/v1|admin|visitors|200"
  "/wp-json/wp/v2/posts?per_page=100|admin|visitors|200"
  # a logged-in non-admin is not exempt, and gets 403 not 401
  "/wp-json/wp/v2/users|editor|visitors|403"
  # mode=everyone reaches admins-in-except only if exemption is off; admins pass
  "/wp-json/wp/v2/users|admin|everyone|200"
)

pass=0; fail=0

for c in "${CASES[@]}"; do
  IFS='|' read -r uri who mode expect <<< "$c"

  out="$("$PHP" "$HERE/probe.php" "$uri" "$who" "$mode" 2>&1 >/dev/null)"
  status="$(printf '%s' "$out" | sed -n 's/^STATUS=\([0-9]*\).*/\1/p' | tail -1)"
  block="$(printf '%s' "$out" | sed -n 's/.*BLOCKED=\(.*\)/\1/p' | tail -1)"

  if [[ "$status" == "$expect" ]]; then
    printf '  ok    %-44s %-8s %-8s -> %s %s\n' "$uri" "$who" "$mode" "$status" "${block:+[$block]}"
    pass=$((pass+1))
  else
    printf '  FAIL  %-44s %-8s %-8s -> %s, expected %s\n' "$uri" "$who" "$mode" "${status:-?}" "$expect"
    fail=$((fail+1))
  fi
done

echo
echo "----------------------------------------"
echo "e2e passed: $pass   failed: $fail"
[[ $fail -eq 0 ]]
