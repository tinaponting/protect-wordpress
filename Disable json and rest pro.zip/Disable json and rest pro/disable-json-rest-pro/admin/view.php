<?php
/**
 * Settings screen markup.
 *
 * @package DisableJsonRestPro
 *
 * @var array  $options Current options.
 * @var array  $rules   Registered block rules.
 * @var array  $stats   Block counters.
 * @var string $role    Role currently being edited.
 * @var string $notice  Notice flag from the redirect.
 */

defined( 'ABSPATH' ) || exit;

$djrp_counts = isset( $stats['counts'] ) && is_array( $stats['counts'] ) ? $stats['counts'] : array();
$djrp_total  = isset( $stats['total'] ) ? (int) $stats['total'] : 0;

	$djrp_role_conf = isset( $options['roles'][ $role ] ) && is_array( $options['roles'][ $role ] )
	? $options['roles'][ $role ]
	: array(
		'default_allow' => ! empty( $options['default_allow'] ),
		'allow_list'    => array(),
		'deny_list'     => array(),
	);

	/*
	 * Cast defensively. The settings page is the one place a malformed option
	 * can take the whole admin down with no way to recover, and it calls
	 * implode() on these. This exact null once fatalled a fresh install.
	 */
	$djrp_allow_list = isset( $djrp_role_conf['allow_list'] ) && is_array( $djrp_role_conf['allow_list'] )
		? $djrp_role_conf['allow_list']
		: array();
	$djrp_deny_list  = isset( $djrp_role_conf['deny_list'] ) && is_array( $djrp_role_conf['deny_list'] )
		? $djrp_role_conf['deny_list']
		: array();
	$djrp_role_default = ! empty( $djrp_role_conf['default_allow'] );
?>
<div class="wrap djrp-wrap">

	<h1><?php esc_html_e( 'Disable JSON and REST Pro', 'disable-json-rest-pro' ); ?></h1>
	<p class="djrp-sub">
		<?php
		printf(
			/* translators: %s: plugin version */
			esc_html__( 'One plugin to close down the WordPress REST API. Version %s.', 'disable-json-rest-pro' ),
			esc_html( DJRP_VERSION )
		);
		?>
	</p>

	<?php if ( 'saved' === $notice ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'disable-json-rest-pro' ); ?></p></div>
	<?php elseif ( 'reset' === $notice ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings reset to defaults.', 'disable-json-rest-pro' ); ?></p></div>
	<?php endif; ?>

	<?php if ( ! empty( self::$report['roles'] ) ) : ?>
		<div class="notice notice-info is-dismissible">
			<p>
				<?php esc_html_e( 'Settings were imported from Disable REST API. The old plugin is now redundant — deactivate and delete it once you are happy.', 'disable-json-rest-pro' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<form method="post" action="options-general.php?page=<?php echo esc_attr( DJRP_Admin::PAGE_SLUG ); ?>">
		<?php wp_nonce_field( DJRP_Admin::NONCE ); ?>
		<input type="hidden" name="djrp_action" value="save">

		<!-- ============================================== master ======= -->
		<div class="djrp-card">
			<h2><?php esc_html_e( 'Master switch', 'disable-json-rest-pro' ); ?></h2>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'REST API', 'disable-json-rest-pro' ); ?></th>
					<td>
						<fieldset>
							<label>
								<input type="radio" name="mode" value="visitors" <?php checked( $options['mode'], 'visitors' ); ?>>
								<?php esc_html_e( 'Block for anonymous visitors only (recommended)', 'disable-json-rest-pro' ); ?>
							</label><br>
							<label>
								<input type="radio" name="mode" value="everyone" <?php checked( $options['mode'], 'everyone' ); ?>>
								<?php esc_html_e( 'Block for everyone, including logged-in users', 'disable-json-rest-pro' ); ?>
							</label><br>
							<label>
								<input type="radio" name="mode" value="off" <?php checked( $options['mode'], 'off' ); ?>>
								<?php esc_html_e( 'No master block — only the block rules below apply', 'disable-json-rest-pro' ); ?>
							</label>
						</fieldset>
						<p class="description">
							<?php esc_html_e( '"Anonymous visitors" means not logged in. Logged-in users are handled by the block rules and the per-role section.', 'disable-json-rest-pro' ); ?>
						</p>
					</td>
				</tr>
			</table>
		</div>

		<!-- ============================================== rules ======== -->
		<div class="djrp-card">
			<h2><?php esc_html_e( 'Block rules', 'disable-json-rest-pro' ); ?></h2>
			<p class="djrp-sub">
				<?php esc_html_e( 'These are matched before any route is dispatched, so they catch the REST route, the full URL and the query string alike. Turning one off lets that endpoint through again.', 'disable-json-rest-pro' ); ?>
			</p>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Applies to', 'disable-json-rest-pro' ); ?></th>
					<td>
						<label>
							<input type="radio" name="block_scope" value="everyone" <?php checked( $options['block_scope'], 'everyone' ); ?>>
							<?php esc_html_e( 'Everyone except administrators', 'disable-json-rest-pro' ); ?>
						</label><br>
						<label>
							<input type="radio" name="block_scope" value="visitors" <?php checked( $options['block_scope'], 'visitors' ); ?>>
							<?php esc_html_e( 'Anonymous visitors only', 'disable-json-rest-pro' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Administrators are always exempt while "exempt admins" is on below — the block editor needs /wp/v2/posts to work at all.', 'disable-json-rest-pro' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<table class="widefat striped djrp-rules">
				<thead>
					<tr>
						<th class="djrp-col-check"><?php esc_html_e( 'On', 'disable-json-rest-pro' ); ?></th>
						<th><?php esc_html_e( 'Rule', 'disable-json-rest-pro' ); ?></th>
						<th class="djrp-col-count"><?php esc_html_e( 'Hits', 'disable-json-rest-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $rules as $djrp_id => $djrp_rule ) : ?>
					<tr>
						<td class="djrp-col-check">
							<input type="checkbox" name="block[<?php echo esc_attr( $djrp_id ); ?>]" value="1" <?php checked( ! empty( $options['block'][ $djrp_id ] ) ); ?>>
						</td>
						<td>
							<strong><?php echo esc_html( $djrp_rule['label'] ); ?></strong>
							<?php if ( ! empty( $djrp_rule['why'] ) ) : ?>
								<p class="description"><?php echo esc_html( $djrp_rule['why'] ); ?></p>
							<?php endif; ?>
						</td>
						<td class="djrp-col-count">
							<?php
							echo isset( $djrp_counts[ $djrp_id ] )
								? esc_html( number_format_i18n( (int) $djrp_counts[ $djrp_id ] ) )
								: '<span aria-hidden="true">&mdash;</span>';
							?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="djrp-max-per-page"><?php esc_html_e( 'Maximum ?per_page', 'disable-json-rest-pro' ); ?></label>
					</th>
					<td>
						<input type="number" id="djrp-max-per-page" name="max_per_page" min="1" max="100"
							value="<?php echo esc_attr( (int) $options['max_per_page'] ); ?>" class="small-text">
						<p class="description">
							<?php esc_html_e( 'Any listing request asking for more than this many items is blocked. WordPress allows up to 100, which is how a whole site gets copied in a handful of requests. Core itself uses 100 for its own lookups, so keep a little headroom if you use the block editor heavily.', 'disable-json-rest-pro' ); ?>
						</p>
					</td>
				</tr>
			</table>
		</div>

		<!-- ============================================== roles ======== -->
		<div class="djrp-card">
			<h2><?php esc_html_e( 'Per-user access', 'disable-json-rest-pro' ); ?></h2>
			<p class="djrp-sub">
				<?php esc_html_e( 'Which REST routes each kind of user may reach. Patterns are matched against the route only, one per line, anchored automatically. Write your own delimiters (e.g. /wp\/v2\/.+/i) if you need regex.', 'disable-json-rest-pro' ); ?>
			</p>

			<p class="djrp-rolepicker">
				<label for="djrp-role"><?php esc_html_e( 'Editing access for:', 'disable-json-rest-pro' ); ?></label>
				<?php
				/*
				 * The picker navigates with GET and carries no name, so switching
				 * roles can never post the previous role's textarea contents
				 * onto the newly selected role. A hidden field below carries the
				 * role that the real save posts.
				 */
				?>
				<select id="djrp-role"
					onchange="window.location.href='<?php echo esc_url( admin_url( 'options-general.php?page=' . DJRP_Admin::PAGE_SLUG ) ); ?>&amp;role='+encodeURIComponent(this.value);">
					<option value="none" <?php selected( $role, 'none' ); ?>>
						<?php esc_html_e( 'Visitor (not logged in)', 'disable-json-rest-pro' ); ?>
					</option>
					<?php foreach ( get_editable_roles() as $djrp_rslug => $djrp_rdef ) : ?>
						<option value="<?php echo esc_attr( $djrp_rslug ); ?>" <?php selected( $role, $djrp_rslug ); ?>>
							<?php echo esc_html( $djrp_rdef['name'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<noscript>
					<button type="submit" formmethod="get" formaction="<?php echo esc_url( admin_url( 'options-general.php' ) ); ?>"
						name="page" value="<?php echo esc_attr( DJRP_Admin::PAGE_SLUG ); ?>" class="button">
						<?php esc_html_e( 'Switch', 'disable-json-rest-pro' ); ?>
					</button>
				</noscript>
				<input type="hidden" name="role" value="<?php echo esc_attr( $role ); ?>">
			</p>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default', 'disable-json-rest-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="role_default_allow" value="1" <?php checked( $djrp_role_default ); ?>>
							<?php esc_html_e( 'Allow this role everything, ignoring the lists below', 'disable-json-rest-pro' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="djrp-role-allow"><?php esc_html_e( 'Allowed routes', 'disable-json-rest-pro' ); ?></label>
					</th>
					<td>
						<textarea id="djrp-role-allow" name="role_allow" rows="6" class="large-text code"
							spellcheck="false"><?php echo esc_textarea( implode( "\n", $djrp_allow_list ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One route pattern per line, e.g. /wp/v2/posts. Leave empty to allow nothing.', 'disable-json-rest-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="djrp-role-deny"><?php esc_html_e( 'Denied routes', 'disable-json-rest-pro' ); ?></label>
					</th>
					<td>
						<textarea id="djrp-role-deny" name="role_deny" rows="4" class="large-text code"
							spellcheck="false"><?php echo esc_textarea( implode( "\n", $djrp_deny_list ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Checked first, so a deny always beats a broader allow.', 'disable-json-rest-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Unlisted roles', 'disable-json-rest-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="default_allow" value="1" <?php checked( ! empty( $options['default_allow'] ) ); ?>>
							<?php esc_html_e( 'Allow roles that have no rule of their own', 'disable-json-rest-pro' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>

		<!-- ============================================ hardening ======= -->
		<div class="djrp-card">
			<h2><?php esc_html_e( 'Hardening', 'disable-json-rest-pro' ); ?></h2>

			<table class="form-table" role="presentation">
				<?php
				$djrp_hardening = array(
					'strip_head_link'   => __( 'Remove the REST <link> tag from page headers', 'disable-json-rest-pro' ),
					'strip_header_link' => __( 'Remove the REST Link response header', 'disable-json-rest-pro' ),
					'strip_rsd'         => __( 'Remove the RSD/API advertisement', 'disable-json-rest-pro' ),
					'strip_oembed_head' => __( 'Remove oEmbed discovery links from the header', 'disable-json-rest-pro' ),
					'disable_jsonp'     => __( 'Disable JSONP responses (cross-origin read)', 'disable-json-rest-pro' ),
					'remove_user_enum'  => __( 'Send ?author=N visitors back to the home page', 'disable-json-rest-pro' ),
					'enforce_ssl'       => __( 'Refuse REST requests over plain HTTP', 'disable-json-rest-pro' ),
					'exempt_admins'     => __( 'Exempt administrators from the block rules', 'disable-json-rest-pro' ),
				);
				?>
				<?php foreach ( $djrp_hardening as $djrp_key => $djrp_label ) : ?>
					<tr>
						<th scope="row">&nbsp;</th>
						<td>
							<label>
								<input type="checkbox" name="harden[<?php echo esc_attr( $djrp_key ); ?>]" value="1"
									<?php checked( ! empty( $options['harden'][ $djrp_key ] ) ); ?>>
								<?php echo esc_html( $djrp_label ); ?>
							</label>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="djrp-message"><?php esc_html_e( 'Error message', 'disable-json-rest-pro' ); ?></label>
					</th>
					<td>
						<input type="text" id="djrp-message" name="error_message" class="large-text"
							maxlength="300" value="<?php echo esc_attr( $options['error_message'] ); ?>">
						<p class="description"><?php esc_html_e( 'Sent to blocked callers. A vague message tells a scraper less than a descriptive one.', 'disable-json-rest-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="djrp-status"><?php esc_html_e( 'Status code', 'disable-json-rest-pro' ); ?></label>
					</th>
					<td>
						<select id="djrp-status" name="status_code">
							<?php
							$djrp_codes = array(
								'default' => __( 'Default (401 anonymous, 403 logged in)', 'disable-json-rest-pro' ),
								'403'     => '403',
								'404'     => __( '404 — pretend it does not exist', 'disable-json-rest-pro' ),
								'405'     => '405',
								'429'     => '429',
							);
							?>
							<?php foreach ( $djrp_codes as $djrp_val => $djrp_lbl ) : ?>
								<option value="<?php echo esc_attr( $djrp_val ); ?>" <?php selected( (string) $options['status_code'], (string) $djrp_val ); ?>>
									<?php echo esc_html( $djrp_lbl ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
			</table>
		</div>

		<!-- ========================================== exclusions ======== -->
		<div class="djrp-card">
			<h2><?php esc_html_e( 'Exclusions', 'disable-json-rest-pro' ); ?></h2>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="djrp-ex-users"><?php esc_html_e( 'User IDs', 'disable-json-rest-pro' ); ?></label>
					</th>
					<td>
						<input type="text" id="djrp-ex-users" name="exclude_users" class="regular-text"
							value="<?php echo esc_attr( $options['exclude_users'] ); ?>" placeholder="1, 4">
						<p class="description"><?php esc_html_e( 'Comma separated. Useful for letting a monitoring service or another bot through.', 'disable-json-rest-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="djrp-ex-ips"><?php esc_html_e( 'IP addresses', 'disable-json-rest-pro' ); ?></label>
					</th>
					<td>
						<input type="text" id="djrp-ex-ips" name="exclude_ips" class="regular-text"
							value="<?php echo esc_attr( $options['exclude_ips'] ); ?>" placeholder="83.186.233.112, 10.0.0.0/8">
						<p class="description">
							<?php esc_html_e( 'Exact addresses or CIDR ranges. Taken from the real connection address only — forwarded headers are ignored, because on a shared host any client can set them.', 'disable-json-rest-pro' ); ?>
						</p>
					</td>
				</tr>
			</table>
		</div>

		<?php submit_button( __( 'Save settings', 'disable-json-rest-pro' ) ); ?>
	</form>

	<!-- ================================================ stats ========= -->
	<div class="djrp-card">
		<h2><?php esc_html_e( 'Blocked requests', 'disable-json-rest-pro' ); ?></h2>
		<?php if ( empty( $djrp_total ) ) : ?>
			<p><?php esc_html_e( 'Nothing recorded yet. Counters start filling once the plugin blocks something.', 'disable-json-rest-pro' ); ?></p>
		<?php else : ?>
			<p>
				<?php
				printf(
					/* translators: 1: total blocks, 2: relative time of last block */
					esc_html__( '%1$s recorded in total, most recently %2$s.', 'disable-json-rest-pro' ),
					esc_html( number_format_i18n( $djrp_total ) ),
					esc_html(
						sprintf(
							/* translators: %s: human readable time difference */
							__( '%s ago', 'disable-json-rest-pro' ),
							human_time_diff( (int) $stats['last_hit'], time() )
						)
					)
				);
				?>
			</p>
			<p class="description">
				<?php esc_html_e( 'Counting is throttled to one write every few seconds, so under a heavy scrape wave these read as a lower bound rather than an exact number. That keeps a blocked request from becoming the most expensive request on the site.', 'disable-json-rest-pro' ); ?>
			</p>
		<?php endif; ?>
	</div>

	<!-- ================================================ reset ========= -->
	<form method="post" action="options-general.php?page=<?php echo esc_attr( DJRP_Admin::PAGE_SLUG ); ?>"
		onsubmit="return confirm('<?php echo esc_js( __( 'Reset every setting back to the defaults? This cannot be undone.', 'disable-json-rest-pro' ) ); ?>');">
		<?php wp_nonce_field( DJRP_Admin::NONCE ); ?>
		<input type="hidden" name="djrp_action" value="reset">
		<p class="djrp-danger">
			<button type="submit" class="button button-secondary">
				<?php esc_html_e( 'Reset all settings', 'disable-json-rest-pro' ); ?>
			</button>
		</p>
	</form>
</div>
