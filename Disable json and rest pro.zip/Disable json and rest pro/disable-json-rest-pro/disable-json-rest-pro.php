<?php
/**
 * Plugin Name: Disable JSON and REST Pro
 * Plugin URI:  https://example.invalid/disable-json-rest-pro
 * Made by URI:  https://teskedsgumman.se
 * Description: One plugin to shut down the WordPress REST API. Per-role allowlists, hard block rules for harvest/abuse endpoints, IP + user exclusions, and REST hardening — merged into a single plugin.
 * Version:     1.0.2
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Tested up to: 7.1
 * Author:      Kristina Ponting
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: disable-json-rest-pro
 * Domain Path: /languages
 *
 * @package DisableJsonRestPro
 */

defined( 'ABSPATH' ) || exit;

define( 'DJRP_VERSION', '1.0.2' );
define( 'DJRP_FILE', __FILE__ );
define( 'DJRP_DIR', plugin_dir_path( __FILE__ ) );
define( 'DJRP_URL', plugin_dir_url( __FILE__ ) );
define( 'DJRP_BASENAME', plugin_basename( __FILE__ ) );
define( 'DJRP_PAGE_SLUG', 'disable-json-rest-pro' );

/**
 * Main plugin class.
 */
class DJRP_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var DJRP_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Whether the admin half has been booted.
	 *
	 * @var bool
	 */
	private $admin_booted = false;

	/**
	 * Retrieve the singleton.
	 *
	 * @return DJRP_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Wire everything up.
	 */
	private function __construct() {
		$this->includes();
		$this->hooks();
	}

	/**
	 * Load the always-needed class files.
	 *
	 * The admin classes are deliberately not loaded here. They are pulled in
	 * on admin_init so that a front-end page view does no admin work at all.
	 */
	private function includes() {
		require_once DJRP_DIR . 'includes/settings.php';
		require_once DJRP_DIR . 'includes/rules.php';
		require_once DJRP_DIR . 'includes/blocker.php';
		require_once DJRP_DIR . 'includes/rest.php';
	}

	/**
	 * Register hooks.
	 *
	 * The blocker runs at wp_loaded. That is late enough that pluggable
	 * functions (is_user_logged_in) and the current user are available, and
	 * early enough that wp() has not run yet, so no route has been dispatched
	 * and no query parsed.
	 *
	 * The admin half boots on `init`, NOT on `admin_init`. wp-admin/admin.php
	 * requires menu.php (which fires admin_menu) at line 163 and only then
	 * fires admin_init at line 180 — so anything registering a menu from
	 * inside admin_init is already too late, and the settings page 403s with
	 * "not allowed to access this page". init runs before both.
	 */
	private function hooks() {
		add_action( 'wp_loaded', array( 'DJRP_Blocker', 'run' ), 0 );
		add_filter( 'rest_authentication_errors', array( 'DJRP_Rest', 'filter_auth' ), 20 );
		add_action( 'init', array( 'DJRP_Rest', 'harden' ), 1 );
		add_action( 'init', array( $this, 'maybe_admin' ), 2 );
		add_filter( 'plugin_action_links_' . DJRP_BASENAME, array( $this, 'action_links' ) );
	}

	/**
	 * Boot the admin half, on admin requests only.
	 *
	 * @return void
	 */
	public function maybe_admin() {
		if ( $this->admin_booted ) {
			return;
		}
		$this->admin_booted = true;

		require_once DJRP_DIR . 'includes/admin.php';

		DJRP_Admin::init();
	}

	/**
	 * Add a Settings link on the plugins screen.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'options-general.php?page=' . DJRP_PAGE_SLUG ) ) . '">' . esc_html__( 'Settings', 'disable-json-rest-pro' ) . '</a>'
		);
		return $links;
	}
}

/**
 * Shortcut to the singleton.
 *
 * @return DJRP_Plugin
 */
function djrp() {
	return DJRP_Plugin::instance();
}

djrp();
