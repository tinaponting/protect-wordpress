/**
 * Disable JSON and REST Pro — admin behaviour.
 *
 * Currently only one nicety: warn before a save that would leave a visitor
 * allowed to do nothing, which is almost always a mistake on a public blog.
 */
( function () {
	'use strict';

	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	ready( function () {
		var form = document.querySelector( '.djrp-wrap form[action*="djrp_action"]' );

		if ( ! form ) {
			return;
		}

		form.addEventListener( 'submit', function ( event ) {
			var mode = form.querySelector( 'input[name="mode"]:checked' );
			var role = form.querySelector( 'input[name="role"]' );

			// Only warn for the visitor role, where an empty allowlist with
			// "default allow" off means the front end loses API access.
			if ( ! role || role.value !== 'none' || ! mode ) {
				return;
			}

			if ( mode.value !== 'off' ) {
				return;
			}

			var allow = form.querySelector( '#djrp-role-allow' );
			var whole = form.querySelector( 'input[name="role_default_allow"]' );

			if ( whole && whole.checked ) {
				return;
			}

			if ( allow && allow.value.trim() === '' && ! window.confirm(
				'Visitor has no allowed routes, no default access, and the master switch is off.\n\n' +
				'That blocks the REST API for every anonymous visitor. Continue?'
			) ) {
				event.preventDefault();
			}
		} );
	} );
}() );
