=== Disable JSON and REST Pro ===
* Made by URI:  https://teskedsgumman.se
Contributors: siteowner
Tags: rest, rest-api, json, api, disable rest, security, block
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

One plugin to shut down the WordPress REST API: per-role allowlists, hard block rules for harvest endpoints, IP and user exclusions, and REST hardening.

== Description ==

This is a merge of two plugins into one:

* **Disable REST API** — the per-user-role route allow/deny engine. Its settings
  are imported automatically on first run.
* **REST Pro Tools** — the parts that were actually worth keeping: the master
  switch, user and IP exclusions, the error message and status code controls,
  and the header-stripping set. Those are now built in, and its "Manage Access"
  screen is gone because it duplicated the per-role engine.

Only the PHP behaviour was taken. No stylesheets, scripts, fonts or images from
either parent are included, and nothing phones home.

= What it blocks out of the box =

Every rule below is a separate switch you can turn off individually.

* **`/wp/v2/users`** — author names, IDs, slugs and avatars. The single most
  useful feed for brute-forcing `wp-login.php`.
* **`/batch/v1`** — bundles many REST calls into one request, including writes.
  Nothing on the front end needs it.
* **oEmbed** — `/oembed/1.0/embed` and `/oembed/1.0/proxy`, plus the
  `?oembed=true` front-end variant that hands over raw post content.
* **The API index** — a bare `/wp-json/`, with or without `?context=view`,
  returns every namespace and route on the site.
* **`?context=edit`** — the editor-context field schema, including custom fields.
* **`/wp/v2/posts`, `/wp/v2/pages`, `/wp/v2/users` listings** — the whole-content
  collection endpoints.
* **`?per_page=N`** above a configurable ceiling (default 20) — bulk grabs. This
  is a limit rather than an exact match on `per_page=100`, because a scraper
  that finds 100 blocked simply asks for 99.
* **`/wp/v2/types` and `/wp/v2/taxonomies`** — the post type schema.

= Why it is not a single regex =

WordPress hands `rest_authentication_errors` a *route* with no query string, so
a route-only plugin cannot see `?per_page=100`, `?context=edit`, or the
`?rest_route=` form of any URL. Each rule here therefore matches on up to three
things — the REST route, the full decoded URI, and the query string — and a
request is blocked if any of them hits. Rules also run on `wp_loaded`, before
`wp()` and therefore before any route is dispatched, so a blocked request never
reaches your theme, your plugins, or the database.

Both URL forms are covered: `/wp-json/wp/v2/users` and
`?rest_route=/wp/v2/users`.

= Administrators =

Administrators are exempt from the block rules by default. The block editor
calls `/wp/v2/posts` and `/wp/v2/types` on every keystroke, so locking
administrators out would break the site while doing nothing to stop a scraper.
Turn "Exempt administrators" off in Hardening if you want the rules to apply to
you as well.

== Installation ==

1. Upload the `disable-json-rest-pro` folder to `/wp-content/plugins/`.
2. Activate it from the Plugins screen.
3. Open **Settings → Disable JSON+REST**.
4. Confirm the master switch and the block rules, then hit Save.

On first run the plugin looks for settings from the two parent plugins and
imports what it recognises. Check the settings before you delete either of them.

== Frequently Asked Questions ==

= What if I lock myself out? =

Three ways out, in order of preference:

1. Rename the folder to `disable-json-rest-pro.disabled` in HostPapa's File
   Manager or over FTP. WordPress stops loading it immediately, with no database
   access needed. Rename it back to re-enable.
2. Add `define( 'DJRP_OFF', true );` to `wp-config.php`.
3. The plugin never blocks `wp-admin`, `admin-ajax` or cron, so the settings
   screen stays reachable either way.

= Does this block the REST API completely? =

No, and it should not. The master switch blocks the REST API for anonymous
visitors, which is where scrapers live. Logged-in users keep the access they
need, governed by the per-role section. Set the master switch to "Block for
everyone" if you want a hard stop, but the block editor will not work.

= Why do the hit counters look low? =

Counting is deliberately throttled to one write every few seconds. Under a
scrape wave with thousands of requests a minute, writing on each one would make
a blocked request the most expensive request on the site — exactly the wrong
trade on shared hosting. Treat the numbers as a lower bound.

= Can I trust the IP exclusion list? =

It reads the real connection address only. Forwarded headers such as
`X-Forwarded-For` are ignored on purpose: on a shared host any client can set
them, so trusting them would let a scraper exempt itself.

= Is this compatible with the block editor? =

Yes, with administrators exempt, which is the default. The editor uses the REST
API heavily for previews and pre-publish checks.

== Changelog ==

= 1.0.2 =
* Fixed a bypass. A request carrying `?rest_route[]=/batch/v1` sends an ARRAY,
  not a string. Casting that to a string produced "Array", which made the
  request look like it was not a REST call at all — so the master switch and
  every route rule were skipped and the request fell through. Any non-scalar
  `rest_route`, `per_page` or `author` is now treated as a REST attempt
  instead of being cast. Regression tests added.
* The settings form now reads every field through a scalar guard, so a stray
  array in a form field cannot fatal the save handler on PHP 8.

= 1.0.1 =
* Fixed: the settings page was registering its menu from `admin_init`, which
  WordPress fires *after* `admin_menu` (wp-admin/admin.php requires menu.php
  at line 163 and fires admin_init at line 180). The menu never appeared and
  the settings page returned 403. Found by booting real WordPress 7.1.3.
* Fixed: a fresh install had no `deny_list` key in the default role config,
  which fatalled the options page on `implode()`. Option arrays are now
  normalised on read, and the view casts defensively.
* Verified against WordPress 7.1.3 on PHP 8.4 with zero notices, warnings or
  deprecations from this plugin.

= 1.0.0 =
* First release: merged per-role engine, master switch, eight block rules,
  per_page ceiling, user and IP exclusions with CIDR, hardening toggles,
  configurable error message and status code, and throttled hit counters.
