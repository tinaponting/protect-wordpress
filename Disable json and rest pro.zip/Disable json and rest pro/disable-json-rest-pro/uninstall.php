<?php
/**
 * Uninstall: remove this plugin's own options, and only its own.
 * Made by URI:  https://teskedsgumman.se
 * The parent plugins' options are deliberately left alone. Removing someone
 * else's data on our say-so is not ours to do — the owner can delete them
 * from the database or by deactivating the parents first.
 *
 * @package DisableJsonRestPro
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'djrp_options' );
delete_option( 'djrp_stats' );
delete_option( 'djrp_import_done' );

// Multisite: clear the option on every site in the network.
if ( is_multisite() ) {
	global $wpdb;

	$blog_ids = $wpdb->get_col( "SELECT blog_id FROM {$wpdb->blogs}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

	foreach ( $blog_ids as $blog_id ) {
		switch_to_blog( (int) $blog_id );
		delete_option( 'djrp_options' );
		delete_option( 'djrp_stats' );
		delete_option( 'djrp_import_done' );
		restore_current_blog();
	}
}
