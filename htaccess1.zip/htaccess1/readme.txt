Read me:

I some cases: you need to save your cocke! Js folders protection maybe not allow you to write!


If you have fonts you do not want anyone to se:

edirectMatch 403 view\folder/fonts
