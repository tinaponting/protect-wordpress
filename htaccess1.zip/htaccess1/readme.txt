Read me:

I some cases: you need to save your cocke! Js folders protection maybe not allow you to write!

