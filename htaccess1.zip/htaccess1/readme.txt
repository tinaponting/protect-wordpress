Read me:
I some cases: you need to save your cocke! Js folders protection maybe not allow you to write!


* If you have fonts you do not want anyone to se:

RedirectMatch 403 view\folder/fonts


Want some more?  See: Maybe.txt in protect wordpress.


* IF Needed:  In some cases:

php_value upload_max_filesize 64M       //Uploads max.

OR:

php_value memory_limit 256M
php_value upload_max_filesize 64M
php_value post_max_size 64M
php_value max_execution_time 300
php_value max_input_time 1000

..........................................

* Limit the file size of uploads
Many websites and maybe also yours offer the possibility of uploading files through e.g. a contact form, which is often a necessary function.

This is frequently an invitation to hackers who want to easily paralyze your site.
In order to do that, they just have to upload monstrous files and your server could be down for a certain time.

* You can limit this possibility by using this line of code:

LimitRequestBody 10240000        * //// in on all firewalls!


..........................................