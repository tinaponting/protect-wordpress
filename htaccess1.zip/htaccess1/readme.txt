### Read me:  ### IMPRTANT:

I some cases: you need to save your cocke! Js folders protection maybe not allow you to write!


* If you have fonts you do not want anyone to se:

RedirectMatch 403 view\folder/fonts


Want some more?  See: Maybe.txt in protect wordpress.

* IF Needed:  In some cases:

php_value upload_max_filesize 64M       //Uploads max.

OR:
php_value memory_limit 256M
php_value upload_max_filesize 64M
php_value post_max_size 64M
php_value max_execution_time 300
php_value max_input_time 1000

..........................................

* Limit the file size of uploads
Many websites and maybe also yours offer the possibility of uploading files through e.g. a contact form, which is often a necessary function.

This is frequently an invitation to hackers who want to easily paralyze your site.
In order to do that, they just have to upload monstrous files and your server could be down for a certain time.

* You can limit this possibility by using this line of code:

LimitRequestBody 10240000        * //// in on all firewalls!


..........................................
.........................................

If needed:

# Address harvesters
RewriteCond %{HTTP_USER_AGENT} ^(autoemailspider¦ExtractorPro) [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^E?Mail.?(Collect¦Harvest¦Magnet¦Reaper¦Siphon¦Sweeper¦Wolf) [NC,OR]
RewriteCond %{HTTP_USER_AGENT} (DTS.?Agent¦Email.?Extrac) [NC,OR]
RewriteCond %{HTTP_REFERER} iaea\.org [NC,OR]

#Download managers
RewriteCond %{HTTP_USER_AGENT} ^(Alligator¦DA.?[0-9]¦DC\-Sakura¦Download.?(Demon¦Express¦Master¦Wonder)¦FileHound) [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^(Flash¦Leech)Get [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^(Fresh¦Lightning¦Mass¦Real¦Smart¦Speed¦Star).?Download(er)? [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^(Gamespy¦Go!Zilla¦iGetter¦JetCar¦Net(Ants¦Pumper)¦SiteSnagger¦Teleport.?Pro¦WebReaper) [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^(My)?GetRight [NC,OR]
#
 Image-grabbers
RewriteCond %{HTTP_USER_AGENT} ^(AcoiRobot¦FlickBot¦webcollage) [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^(Express¦Mister¦Web).?(Web¦Pix¦Image).?(Pictures¦Collector)? [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^Image.?(fetch¦Stripper¦Sucker) [NC,OR]

# "Gray-hats"
RewriteCond %{HTTP_USER_AGENT} ^(Atomz¦BlackWidow¦BlogBot¦EasyDL¦Marketwave¦Sqworm¦SurveyBot¦Webclipping\.com) [NC,OR]
RewriteCond %{HTTP_USER_AGENT} (girafa\.com¦gossamer\-threads\.com¦grub\-client¦Netcraft¦Nutch) [NC,OR]

# Site-grabbers
RewriteCond %{HTTP_USER_AGENT} ^(eCatch¦(Get¦Super)Bot¦Kapere¦HTTrack¦JOC¦Offline¦UtilMind¦Xaldon) [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^Web.?(Auto¦Cop¦dup¦Fetch¦Filter¦Gather¦Go¦Leach¦Mine¦Mirror¦Pix¦QL¦RACE¦Sauger) [NC,OR]
RewriteCond %{HTTP_USER_AGENT} ^Web.?(site.?(eXtractor¦Quester)¦Snake¦ster¦Strip¦Suck¦vac¦walk¦Whacker¦ZIP) [NC,OR]
RewriteCond %{HTTP_USER_AGENT}  WebCapture [NC,OR]

......................................................................................

MAYBE: 

TraceEnable Off


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

One alternative is to explicitly state what domains have access to the content of your site. 
In the example below, we restrict access to a subdomain of our main site (example.com). 
This is more secure and, likely, what you intended to do.

APACHECONF
Copy to Clipboard

<IfModule mod_headers.c>
Header set Access-Control-Allow-Origin "subdomain.example.com"
</IfModule>

From: https://developer.mozilla.org/


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Hongkong - makes you crazy!!!

RewriteCond%{HTTP_USER_AGENT}^.(Bytedance|Bytespider|Petalbot).$[NC]

Very dangerous, download all in your site.

RewriteCond %{HTTP_USER_AGENT}"^Maxthon$"[NC,OR]


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

VERY IMPORTANT:

Changethis:
<IfModule mod_php8.c>
before:
ServerSignature Off

If you do not have: php 8 to:

<IfModule mod_php7.c>


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Hate comments?  Add this:

<IfModule mod_rewrite.c>
RewriteCond%{REQUEST_METHOD}POST 
RewriteCond%{REQUEST_URI}.wp-comments-post\.php*
RewriteCond%{HTTP_REFERER}!.* OR
]RewriteCond%{HTTP_USER_AGENT}^$ 
RewriteRule^(.*)$^https//://www.%{HTTP_HOST}/$[R=301,L]
</IfModule>

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
If needed:


RewriteEngine On RewriteCond %{HTTP_USER_AGENT Gecko/20100101 [NC]RewriteRule ^ - [F,L]


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
IF Needed:

RewriteEngine on RewriteCond%{QUERY_STRING}"script"RewriteRule .* - [F]

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

IF NEEDED:

RewriteCond%{HTTP_USER_AGENT}^HTTP/1.1" curl/7.30.0 [NC,OR]
RewriteCond%{HTTP_USER_AGENT}^HTTP/1.1" 200 [NC,OR] 
RewriteCond%{HTTP_USER_AGENT}^HTTP/1.1" 301 [NC,OR]
RewriteCond%{HTTP_USER_AGENT}^HTTP/1.0" 401 [NC,OR]
RewriteCond%{HTTP_USER_AGENT}^HTTP/1.1" 404 [NC,OR]
RewriteCond%{HTTP_USER_AGENT}^GET / HTTP/1.1 [NC,OR]
RewriteCond%{HTTP_USER_AGENT}^GET / HTTP/1.1 400 [NC,OR]
RewriteCond%{HTTP_USER_AGENT}^HTTP/1.1 GET request [NC,OR]
RewriteCond%{HTTP_USER_AGENT}^GET /login.php HTTP/1.1 [NC,OR]
RewriteCond%{HTTP_USER_AGENT}^GET clientRequestHTTPProtocol: HTTP/1.1 [NC,OR]

RewriteCond%{HTTP_USER_AGENT}^HEAD /wordpress HTTP/1.1 
RewriteCond%{HTTP_USER_AGENT}^HEAD /wordpress HTTP/1.1" 403
RewriteCond%{HTTP_USER_AGENT}^RewriteCond%{HTTP_USER_AGENT}^HEAD /wordpress HTTP/1.1" 404
RewriteCond%{HTTP_USER_AGENT}^HEAD /wp HTTP/1.1" 301
RewriteCond%{HTTP_USER_AGENT}^HEAD /wp HTTP/1.1" 404
RewriteCond%{HTTP_USER_AGENT}^HEAD /HTTP/1.1" 301
RewriteCond%{HTTP_USER_AGENT}^HEAD /HTTP/1.1" 200
RewriteCond%{HTTP_USER_AGENT}^HTTP/1.1" curl/7.30.0  


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

# STOP IE/Bing download:

Header always set X-Download-Options "noopen"

#  Moved off These, ig needed: (add them if needed.

RewriteCond%{HTTP_USER_AGENT}(A1 Website Download[NC] 
RewriteCond%{HTTP_USER_AGENT}(A1 Website Scraper[NC]


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

2024 ai useragents moved to, htaccess2 (perrishpress) firewall!