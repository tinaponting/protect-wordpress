Read me:
I some cases: you need to save your cocke! Js folders protection maybe not allow you to write!


If you have fonts you do not want anyone to se:

RedirectMatch 403 view\folder/fonts


Want some more?  See: Maybe.txt in protect wordpress.


IF Needed:  In some cases:

php_value post_max_size 64M             // Post size, not always needed!
php_value upload_max_filesize 64M       //Uploads max.



..........................................