Read me:

I some cases: you need to save your cocke! Js folders protection maybe not allow you to write!


If you have fonts you do not want anyone to se:

RedirectMatch 403 view\folder/fonts


Want some more?  See: Maybe.txt in protect wordpress.
