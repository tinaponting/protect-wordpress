BLANK Firewall to make your own.

* Take what you want from my firewalls, add it,
use what you want from 8G From https://perishablepress.com/.  and there it lots of useful thing on his website to use.

Check your htaccess here:    http://www.htaccesscheck.com
OR At: https://www.lyxx.com/freestuff/002.html



You can find more att: Maybe txt.

And ofcos: Google  search: Safety, htaccess and you find at lots,
Deny,  what you search for  .htaccess.

You can also rename it if you want.


Happy Safety blogging   // Kristina Ponting sweden

If you miss something mail me: tinadotpontingatgmaildotcom