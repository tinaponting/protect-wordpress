<?php
// (No dots needed unless you _specifically_ want ".bot" in the UA)
$blockList = ['bot', 'domain'];

$userAgent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

foreach ($blockList as $needle) {
    if ($needle !== '' && strpos($userAgent, $needle) !== false) {
        header('HTTP/1.1 403 Forbidden');
        exit;
    }
}