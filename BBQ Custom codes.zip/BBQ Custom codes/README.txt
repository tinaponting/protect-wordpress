READ ME:
to add cutom codes protection, look in mysql,find: 	
bbq_patterns

Copy file and set in!

Extra to add in BBQ if needed:

/comments/feed/   If needed!

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Important:
/wp-content/uploads/2021
/wp-content/uploads/2020  (For example, add your images folders)

* Makes it harder to check the code, but doesn't stop chrome tools for webmasters or other of these, make it harder to view code:)

https://example.se/?act=view-source
https://example.se/wp-login.php?action=lostpassword
view-source:https://example.com


Sometimes hackers tries to come in, by emoji js files,add them! But rembember; they change version nummer now and then.
Or set therights 444! 

BBQ PRO Is needed for this:)


ADD: 
All yours themes folder 
and all .js files, very atackts by hackers!

add: your theme
Add: your sensitive plugins

LOVE From sweden Karlshamn // KP






