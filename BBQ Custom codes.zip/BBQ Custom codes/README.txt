READ ME:
to add cutom codes protection, look in mysql,find: 	
bbq_patterns

Copy file and set in!

Extra to add in BBQ if needed:

/comments/feed/

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Important:
/wp-content/uploads/2021
/wp-content/uploads/2020  (For example, add your images folders)

https://example.se/?act=view-source
https://example.se/wp-login.php?action=lostpassword




