<?php
add_filter(
	'all_wp-includes',
	function ( $wp-includes ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-includes= [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenwp-includes $hiddenwp-includes ) {
				unset( $includes[ $hiddenwp-includes ] );
			}
		}
		return $wp-includes;
	}
);
add_filter(
	'all_wp-includes/css',
	function ( $css ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-includes/css = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenwp-includes/css as $hiddenwp-includes/css ) {
				unset( $css[ $hiddenwp-includes/css ] );
			}

		}
		return $wp-includes/css;
	}
);
add_filter(
	'all_wp-includes/js',
	function ( $wp-includes/js ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenwp-includes/js = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenwp-includes/js as $hiddenwp-includes/js ) {
				unset( $js[ $hiddenwp-includes/js ] );
			}

		}
		return $wp-includes/js;
	}
);