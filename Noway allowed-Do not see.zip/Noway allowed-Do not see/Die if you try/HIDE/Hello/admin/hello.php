<?php
add_filter(
	'all_admin',
	function ( $admin ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenadmin = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenAdmin as $hiddenAdmin ) {
				unset( $Admins[ $hiddenAdmin ] );
			}
		}
		return $admin;
	}
);