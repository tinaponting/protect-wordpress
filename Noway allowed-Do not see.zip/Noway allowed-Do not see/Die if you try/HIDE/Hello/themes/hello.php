<?php
add_filter(
	'all_themes',
	function ( themes ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenThemes = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenthemes as $hiddenthemes) {
				unset( $themes[ $hiddenthemes ] );
			}
		}
		return $themes;
	}
);