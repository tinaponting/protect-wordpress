<?php
add_filter(
	'all_uploads',
	function ( $uploads ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenuploads = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenuploads as $hiddenuploads ) {
				unset( $uploads[ $hiddenuploads ] );
			}
		}
		return $uploads;
	}
);