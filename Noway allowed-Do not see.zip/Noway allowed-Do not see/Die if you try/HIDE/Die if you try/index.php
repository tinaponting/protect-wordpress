<?php
if(! defined('WPINC')){die;
}
#Silence is golden.
?>