console._log = console.log 
console.log = function (log) { 
  return console._log(`%c ${log}`, 'color:rgba(255,255,255,0)'); 
} 