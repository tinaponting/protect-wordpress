<?php
if(! defined('YORNAMEHERE')){die;
}