<?php
if(! defined('WP-folderherehide')){die;
}