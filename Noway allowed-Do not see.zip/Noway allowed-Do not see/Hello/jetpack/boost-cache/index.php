<?php
if(! defined('wp-content/boost-cache')){die;
}