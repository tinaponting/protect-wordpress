<?php
add_filter(
	'all_jetpack-waf',
	function ( $jetpack-waf) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenJetpack-waf = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenJetpack-waf as $hiddenjJetpack-waf) {
				unset( $Jetpack-waf[ $hiddenJetpack-waf] );
			}
		}
		return $jetpack-waf;
	}
);