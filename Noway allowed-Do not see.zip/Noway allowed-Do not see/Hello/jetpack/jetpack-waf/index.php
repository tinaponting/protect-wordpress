<?php
if(! defined('wp-content/jetpack-waf')){die;
}