<?php
/**
 * @package Hello_Dolly
 */
/**
Plugin Name: Hello Dolly
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up.
*/
function hello_dolly_get_lyric() {
	/** These are the lyrics to Hello Dolly */
	$lyrics = "What is this that stands before me?
Figure in black which points at me
Turn 'round quick and start to run
Find out I'm the chosen one
Oh, no!
Big black shape with eyes of fire
Tellin' people their desire
Satan's sittin' there, he's smilin'
Watches those flames get higher and higher
Oh, no! No! Please, God, help me!
Is it the end, my friend?
Satan's comin' 'round the bend
People runnin' 'cause they're scared
The people better go and beware
No! No! Please, no!";
	$lyrics = explode( "\n", $lyrics );
	return wptexturize( $lyrics[ mt_rand( 0, count( $lyrics ) - 1 ) ] );
}
function hello_dolly() {
	$chosen = hello_dolly_get_lyric();
	echo "<p id='dolly'>$chosen</p>";
}
add_action( 'admin_notices', 'hello_dolly' );
function dolly_css() {
	$x = is_rtl() ? 'left' : 'right';
	echo "
	<style type='text/css'>
	#dolly {
		float: $x;
		padding-$x: 15px;
		padding-top: 5px;		
		margin: 0;
		font-size: 11px;
	}
	</style>
	";
}
add_action( 'admin_head', 'dolly_css' );?>
