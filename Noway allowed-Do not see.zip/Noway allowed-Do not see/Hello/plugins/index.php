<?php
if(! defined('wp-content/plugins')){die;
}