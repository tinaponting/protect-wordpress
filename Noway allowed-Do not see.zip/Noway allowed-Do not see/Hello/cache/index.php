<?php
if(! defined('wp-content/cache')){die;
}