<?php
add_filter(
	'all_cache',
	function ( $cache) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenCache = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenCache as $hiddenCache ) {
				unset( $cache[ $hiddenCache] );
			}
		}
		return $cache;
	}
);