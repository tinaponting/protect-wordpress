<?php
add_filter(
	'all_public_html',
	function ( $public_html ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenpublic_html = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenpublic_html as $hiddenpublic_html) {
				unset( $public_htmls[ $hiddenpublic_html ] );
			}
		}
		return $public_html;
	}
);