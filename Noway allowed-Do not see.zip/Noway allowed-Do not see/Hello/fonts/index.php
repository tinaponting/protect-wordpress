<?php
if(! defined('wp-content/fonts')){die;
}