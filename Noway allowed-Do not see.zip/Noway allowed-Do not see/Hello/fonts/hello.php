<?php
add_filter(
	'all_fonts',
	function ( $fonts ) {
		$shouldHide = ! array_key_exists( 'show_all', $_GET );
		if ( $shouldHide ) {
			$hiddenFonts = [
				'hello-dolly/hello.php',
				'hello.php',
			];
			foreach ( $hiddenFonts as $hiddenFonts ) {
				unset( $fonts[ $hiddenFonts] );
			}
		}
		return $fonts;
	}
);