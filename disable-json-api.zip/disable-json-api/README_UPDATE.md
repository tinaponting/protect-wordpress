# Disable REST API - PHP 8 Update

## Summary

This WordPress plugin has been successfully updated to be fully compatible with PHP 8.x.

## What Was Fixed?

The main issue preventing PHP 8 compatibility was the use of **deprecated pass-by-reference syntax** in callback functions.

### The Problem:

In older PHP versions (5.x), it was common to use `&$this` when passing object methods as callbacks:

```php
add_action( 'some_hook', array( &$this, 'method_name' ) );
```

This syntax was:
- Deprecated in PHP 7.0
- Generates warnings in PHP 7.x
- Causes errors in PHP 8.0+

### The Solution:

All instances of `array( &$this, 'method_name' )` have been changed to `array( $this, 'method_name' )`.

The ampersand (`&`) is no longer needed because:
- Objects are passed by reference automatically in PHP 5.0+
- The `&` symbol is now meaningless and causes errors

## Files Modified:

1. **disable-json-api.php**
   - Updated plugin version to 1.9
   - Updated minimum PHP requirement to 7.0

2. **classes/disable-rest-api.php**
   - Removed `&$this` from 5 callback declarations
   - Updated VERSION constant to 1.9

## Installation:

1. **Backup your current plugin** and database
2. Deactivate the old version
3. Delete the old plugin files
4. Upload the updated plugin
5. Activate the plugin
6. Verify your settings are intact

## Compatibility:

- **PHP**: 7.0, 7.1, 7.2, 7.3, 7.4, 8.0, 8.1, 8.2, 8.3
- **WordPress**: 4.9+

## Testing:

All core functionality has been preserved:
- ✅ REST API blocking for unauthenticated users
- ✅ Role-based access control
- ✅ Route allowlisting
- ✅ Admin settings interface
- ✅ Plugin activation/deactivation

## No Breaking Changes:

- All existing settings are preserved
- No database changes required
- Backward compatible with your current configuration

---

**Updated by**: Kristina Ponting 
**Date**: October 21, 2025  
**Original Author**: Dave McHale
**FORK OFF URL: https//teskedsgumman.se   
**Original Plugin URI**: http://www.binarytemplar.com/disable-json-api

*** OLD STUFF:
# Disable REST API

** This is the public repository for the latest DEVELOPMENT copy of the plugin. There is absolutely no guarantee, 
express or implied, that the code you find here is a stable build. For official releases, please see the 
**
  
Disable the use of the REST API on your website to unauthenticated users, with the freedom to enable individual
routes as desired. Manage route access for logged-in users based on their User Role.

## Installation
 1. Install to WordPress plugins as normal and activate.
## Usage
 1. Basic usage of the plugin requires no configuration.
 2. Optionally, you may use the Settings page to whitelist individual routes inside the REST API based on User Role (Unauthenticated Users as well as any logged-in user)
## History
 1. Initial versions of this plugin simply used the existing filters of the REST API to disable it entirely.
 2. As of WordPress 4.7 and version 1.3 of this plugin, the plugin would forcibly throw an authentication error for unauthenticated users.
 3. In version 1.4 we introduced the Settings screen and allow site admins to whitelist routes  they wish to allow for unauthenticated users.
 4. In version 1.5 we added minimum requirements checks for WordPress and PHP. Fixed minor bug to prevent unintended empty routes. Minor text & text-domain updates.
 5. In version 1.6 we added support for per-role rules and did a number of other housekeeping updates in the code.
 6. In version 1.7 we changed how we cache-bust static file enqueues, and repaired a logic bug in the role-based default_allow checks.
 7. In version 1.8 we provided a new filter so devs can customize the error message sent back if you fail the authentication check; updated minimum requirements to PHP 5.6 (up from 5.3) and WordPress 4.9 (up from WP 4.4); patched a Fatal Error when activating plugin on installations running LearnDash.
## Credits
Authored by Dave McHale. Contributed to by Tang Rufus.
## License
As with all WordPress projects, this plugin is released under the GPL 

