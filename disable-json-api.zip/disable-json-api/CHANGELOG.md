# Changelog - Disable REST API Plugin

## Version 1.9 - PHP 8 Compatibility Update (2025-10-21)

### Changes Made for PHP 8 Compatibility:

#### 1. **Removed deprecated pass-by-reference syntax**
   - **Issue**: Using `&$this` in callback arrays (`array( &$this, 'method_name' )`) was deprecated in PHP 7.0 and removed in PHP 8.0
   - **Fix**: Changed all instances to `array( $this, 'method_name' )` throughout the codebase
   - **Files affected**: 
     - `classes/disable-rest-api.php` (5 instances fixed)

#### 2. **Updated version requirements**
   - **Plugin Version**: Updated from 1.8 to 1.9
   - **Requires PHP**: Updated from 5.6 to 7.0
   - **Files affected**:
     - `disable-json-api.php` (plugin header and requirements check)
     - `classes/disable-rest-api.php` (VERSION constant)

### Technical Details:

**Before (PHP 5.x style - DEPRECATED):**
```php
add_action( 'wp_loaded', array( &$this, 'option_check' ) );
add_action( 'admin_menu', array( &$this, 'define_admin_link' ) );
add_filter( 'rest_authentication_errors', array( &$this, 'you_shall_not_pass' ), 20 );
```

**After (PHP 7.0+ / PHP 8 compatible):**
```php
add_action( 'wp_loaded', array( $this, 'option_check' ) );
add_action( 'admin_menu', array( $this, 'define_admin_link' ) );
add_filter( 'rest_authentication_errors', array( $this, 'you_shall_not_pass' ), 20 );
```

### Compatibility:

- ✅ **PHP 7.0+** - Fully compatible
- ✅ **PHP 7.4** - Fully compatible
- ✅ **PHP 8.0** - Fully compatible
- ✅ **PHP 8.1** - Fully compatible
- ✅ **PHP 8.2** - Fully compatible
- ✅ **PHP 8.3** - Fully compatible
- ✅ **WordPress 4.9+** - Fully compatible

### Testing Recommendations:

1. **Backup your database** before updating
2. Test in a staging environment first
3. Verify that your REST API access rules still work as expected
4. Check plugin settings page for proper functionality

### No Breaking Changes:

- All existing settings and configurations are preserved
- No database schema changes
- No changes to plugin functionality or user interface
- Backward compatible with previous plugin versions
